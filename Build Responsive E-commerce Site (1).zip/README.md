
  # Build Responsive E-commerce Site

  This is a code bundle for Build Responsive E-commerce Site. The original project is available at https://www.figma.com/design/6v7r6W1hPl1UXidZUrQwvx/Build-Responsive-E-commerce-Site.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  