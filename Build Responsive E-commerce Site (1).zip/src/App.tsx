import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/home/Hero';
import { ProductGrid } from './components/products/ProductGrid';
import { ProductCategoryModal } from './components/products/ProductCategoryModal';
import { ProductDetailPage } from './components/products/ProductDetailPage';
import { ArticleGrid } from './components/articles/ArticleGrid';
import { AuthModal } from './components/auth/AuthModal';
import { ShoppingCart } from './components/cart/ShoppingCart';
import { UserDashboard } from './components/dashboard/UserDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { SurveyForm } from './components/contact/SurveyForm';
import { ProjectGrid } from './components/projects/ProjectGrid';
import { CompanyInfoCard } from './components/company/CompanyInfoCard';
import { ServicePage } from './components/services/ServicePage';
import { ArticleDetailModal } from './components/articles/ArticleDetailModal';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Input } from './components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { toast, Toaster } from 'sonner@2.0.3';
import { productCategories, CategoryItem, getBreadcrumbPath } from './utils/productCategories';
import { projectsData } from './utils/projectData';
import { equipmentData, achievementsData, clientsData, companyOverviewText, companyHistoryText, orgChartText, activityFieldsText, catalogText } from './utils/companyData';
import { articlesData } from './utils/articlesData';
import { 
  Star,
  Filter,
  SortAsc,
  Grid3X3,
  List,
  ChevronLeft,
  ChevronRight,
  Search,
  Smartphone,
  Headphones,
  Settings,
  Users,
  Phone,
  Shield,
  Award,
  Truck,
  Heart,
  MessageCircle,
  Eye,
  Calculator,
  CheckCircle,
  ShoppingCart as ShoppingCartIcon,
  MapPin,
  Clock,
  Building,
  Calendar
} from 'lucide-react';
import { 
  supabase, 
  authService, 
  productService, 
  cartService, 
  orderService, 
  articleService, 
  adminService,
  seedData
} from './utils/supabase/client';

interface Product {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image?: string;
  rating?: number;
  reviewCount?: number;
  discount?: number;
  isNew?: boolean;
  isFavorite?: boolean;
  category: string;
}

interface Article {
  id: string;
  title: string;
  excerpt: string;
  image?: string;
  author: string;
  publishDate: string;
  readTime: number;
  tags: string[];
  likes: number;
  comments: number;
  views: number;
  isLiked?: boolean;
}

interface CartItem {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image?: string;
  quantity: number;
  discount?: number;
}

interface User {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  memberSince: string;
}

type PageType = 'home' | 'products' | 'phones' | 'accessories' | 'repairs' | 'articles' | 'support' | 'about' | 'dashboard' | 'admin' | 'orders' | 'wishlist' | 'contact-us' | 'free-consultation' | 'job-request' | 'faq' | 'customer-voice' | 'survey-form' | 
  'communications' | 'network' | 'audio' | 'camera' | 'power' | 'video' | 'office' | 'power-systems' |
  'communication-services' | 'it-services' | 'av-services' | 'surveillance-services' | 'power-services' | 'alarm-services' | 'after-sales' | 'maintenance' | 'activity-areas' |
  'project-list' | 'resume' |
  'company-overview' | 'company-history' | 'equipment' | 'org-chart' | 'activity-fields' | 'smart-resume' | 'main-clients' | 'certificates' | 'achievements' | 'catalog';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [initialized, setInitialized] = useState(false);
  
  // Product category navigation state
  const [isProductCategoryModalOpen, setIsProductCategoryModalOpen] = useState(false);
  const [currentCategoryPath, setCurrentCategoryPath] = useState<CategoryItem[]>([]);
  const [selectedProductCategory, setSelectedProductCategory] = useState<CategoryItem | null>(null);
  
  // Articles pagination
  const [currentArticlePage, setCurrentArticlePage] = useState(1);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const articlesPerPage = 20;

  // Set page title and meta tags
  React.useEffect(() => {
    document.title = 'نصب انواع مرکز تلفن دیجیتال و IP | نصب سانترال، مرکز تلفن، تلفن ip، voip';
    
    // Remove existing meta tags
    const existingMetas = document.querySelectorAll('meta[name="description"], meta[name="keywords"], meta[property*="og:"]');
    existingMetas.forEach(meta => meta.remove());
    
    // Add SEO meta tags
    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = 'نصب، راه‌اندازی و فروش انواع مرکز تلفن دیجیتال، سانترال، تلفن IP و سیستم‌های VoIP. بهترین خدمات تلفنی با ضمانت و پشتیبانی ۲۴ ساعته';
    document.head.appendChild(metaDescription);

    const metaKeywords = document.createElement('meta');
    metaKeywords.name = 'keywords';
    metaKeywords.content = 'نصب سانترال، مرکز تلفن، تلفن ip، voip، نصب مرکز تلفن دیجیتال، سیستم تلفنی، پاناسونیک، زیمنس';
    document.head.appendChild(metaKeywords);

    // Open Graph tags
    const ogTitle = document.createElement('meta');
    ogTitle.setAttribute('property', 'og:title');
    ogTitle.content = 'نصب انواع مرکز تلفن دیجیتال و IP';
    document.head.appendChild(ogTitle);

    const ogDescription = document.createElement('meta');
    ogDescription.setAttribute('property', 'og:description');
    ogDescription.content = 'نصب، راه‌اندازی و فروش انواع مرکز تلفن دیجیتال، سانترال، تلفن IP و سیستم‌های VoIP';
    document.head.appendChild(ogDescription);

    const ogType = document.createElement('meta');
    ogType.setAttribute('property', 'og:type');
    ogType.content = 'website';
    document.head.appendChild(ogType);
  }, []);

  // Initialize app with backend data
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Seed data first
        await seedData()
        
        // Check for existing session
        const { data: { session } } = await supabase.auth.getSession()
        if (session?.user) {
          try {
            const profileResponse = await authService.getProfile()
            setUser(profileResponse.profile)
            setIsLoggedIn(true)
            if (profileResponse.profile?.role === 'admin') {
              setIsAdmin(true)
            }
          } catch (error) {
            console.log('Profile fetch error:', error)
          }
        }

        // Load initial data
        await loadProducts()
        await loadArticles()
        
        setInitialized(true)
      } catch (error) {
        console.error('Initialization error:', error)
        toast.error('خطا در بارگذاری اولیه')
      }
    }

    initializeApp()
  }, [])

  // Listen for auth state changes
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          try {
            const profileResponse = await authService.getProfile()
            setUser(profileResponse.profile)
            setIsLoggedIn(true)
            if (profileResponse.profile?.role === 'admin') {
              setIsAdmin(true)
            }
            toast.success('با موفقیت وارد شدید')
          } catch (error) {
            console.error('Profile fetch error:', error)
          }
        } else if (event === 'SIGNED_OUT') {
          setUser(null)
          setIsLoggedIn(false)
          setIsAdmin(false)
          setCartItems([])
          toast.success('با موفقیت خارج شدید')
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const loadProducts = async () => {
    try {
      setLoading(true)
      let category = selectedCategory;
      
      // Map page-specific categories
      if (currentPage === 'phones') category = 'سیستم‌های تلفنی';
      if (currentPage === 'accessories') category = 'لوازم جانبی';
      
      const response = await productService.getProducts({
        category: category === 'all' ? undefined : category,
        search: searchQuery,
        sortBy,
        limit: 20
      })
      setProducts(response.products || [])
    } catch (error) {
      console.error('Load products error:', error)
      toast.error('خطا در بارگذاری محصولات')
    } finally {
      setLoading(false)
    }
  }

  const loadArticles = async () => {
    try {
      const response = await articleService.getArticles({ limit: 20 })
      setArticles(response.articles || [])
    } catch (error) {
      console.error('Load articles error:', error)
      toast.error('خطا در بارگذاری مقالات')
    }
  }

  const loadCart = async () => {
    if (!isLoggedIn) return
    
    try {
      const response = await cartService.getCart()
      // Convert backend cart format to frontend format
      const cartItems: CartItem[] = []
      for (const item of response.cart.items || []) {
        try {
          const productResponse = await productService.getProduct(item.productId)
          if (productResponse.product) {
            cartItems.push({
              id: productResponse.product.id,
              title: productResponse.product.title,
              price: productResponse.product.price,
              originalPrice: productResponse.product.originalPrice,
              quantity: item.quantity,
              discount: productResponse.product.discount
            })
          }
        } catch (error) {
          console.error('Error loading cart item:', error)
        }
      }
      setCartItems(cartItems)
    } catch (error) {
      console.error('Load cart error:', error)
    }
  }

  // Load products when filters change
  useEffect(() => {
    if (initialized) {
      loadProducts()
    }
  }, [selectedCategory, searchQuery, sortBy, currentPage, initialized])

  // Load cart when user logs in
  useEffect(() => {
    if (isLoggedIn) {
      loadCart()
    }
  }, [isLoggedIn])

  const categories = [
    { value: 'all', label: 'همه دسته‌ها' },
    { value: 'سیستم‌های تلفنی', label: 'سیستم‌های تلفنی' },
    { value: 'لوازم جانبی', label: 'لوازم جانبی' },
  ];

  const sortOptions = [
    { value: 'newest', label: 'جدیدترین' },
    { value: 'price_low', label: 'ارزان‌ترین' },
    { value: 'price_high', label: 'گران‌ترین' },
    { value: 'popular', label: 'محبوب‌ترین' },
  ];

  const handleNavigation = (page: string) => {
    setCurrentPage(page as PageType);
    // Reset filters when navigating to different sections
    if (['phones', 'accessories', 'repairs'].includes(page)) {
      setSelectedCategory('all');
    }
    
    // Open product category modal if navigating to 'products'
    if (page === 'products') {
      setIsProductCategoryModalOpen(true);
      setCurrentCategoryPath([]);
      setSelectedProductCategory(null);
    }
  };

  const handleOpenProductCategoryModal = () => {
    setIsProductCategoryModalOpen(true);
    setCurrentCategoryPath([]);
    setSelectedProductCategory(null);
  };

  const handleSelectProductCategory = (category: CategoryItem) => {
    if (category.isEndpoint) {
      // Show product detail page
      setSelectedProductCategory(category);
      setIsProductCategoryModalOpen(false);
    } else if (category.children && category.children.length > 0) {
      // Navigate deeper into categories
      setCurrentCategoryPath([...currentCategoryPath, category]);
    }
  };

  const handleBreadcrumbClick = (category: CategoryItem) => {
    const index = currentCategoryPath.findIndex(c => c.id === category.id);
    if (index >= 0) {
      setCurrentCategoryPath(currentCategoryPath.slice(0, index + 1));
    } else {
      // Clicked on root, go back to first level
      setCurrentCategoryPath([]);
    }
  };

  const handleCloseProductCategoryModal = () => {
    setIsProductCategoryModalOpen(false);
  };

  const handleBackFromProductDetail = () => {
    setSelectedProductCategory(null);
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const response = await authService.signIn(email, password)
      setIsAuthModalOpen(false)
    } catch (error: any) {
      console.error('Login error:', error)
      toast.error(`خطا در ورود: ${error.message}`)
    }
  };

  const handleRegister = async (data: any) => {
    try {
      const response = await authService.signUp(data)
      toast.success('حساب کاربری شما با موفقیت ایجاد شد')
      // Auto login after registration
      setTimeout(async () => {
        await handleLogin(data.email, data.password)
      }, 1000)
    } catch (error: any) {
      console.error('Register error:', error)
      toast.error(`خطا در ثبت نام: ${error.message}`)
    }
  };

  const handleLogout = async () => {
    try {
      await authService.signOut()
      setCurrentPage('home')
    } catch (error: any) {
      console.error('Logout error:', error)
      toast.error('خطا در خروج')
    }
  };

  const handleAddToCart = async (productId: string) => {
    if (!isLoggedIn) {
      toast.error('لطفا ابتدا وارد حساب کاربری خود شوید')
      setIsAuthModalOpen(true)
      return
    }

    try {
      await cartService.addToCart(productId, 1)
      await loadCart() // Reload cart
      toast.success('محصول به سبد خرید اضافه شد')
    } catch (error: any) {
      console.error('Add to cart error:', error)
      toast.error(`خطا در افزودن به سبد خرید: ${error.message}`)
    }
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCartItems(cartItems.map(item =>
      item.id === productId ? { ...item, quantity } : item
    ));
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems(cartItems.filter(item => item.id !== productId));
    toast.success('محصول از سبد خرید حذف شد');
  };

  const handleToggleFavorite = (productId: string) => {
    if (!isLoggedIn) {
      toast.error('لطفا ابتدا وارد حساب کاربری خود شوید')
      setIsAuthModalOpen(true)
      return
    }
    toast.success('به علاقه‌مندی‌ها اضافه شد');
  };

  const handleViewProduct = (productId: string) => {
    toast.info('جزئیات محصول');
  };

  const handleLikeArticle = async (articleId: string) => {
    if (!isLoggedIn) {
      toast.error('لطفا ابتدا وارد حساب کاربری خود شوید')
      setIsAuthModalOpen(true)
      return
    }

    try {
      const response = await articleService.likeArticle(articleId)
      toast.success(response.message)
      await loadArticles() // Reload articles to update like count
    } catch (error: any) {
      console.error('Like article error:', error)
      toast.error(`خطا در پسندیدن مقاله: ${error.message}`)
    }
  };

  const handleShareArticle = (articleId: string) => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('لینک کپی شد');
  };

  const handleReadMore = (articleId: string) => {
    toast.info('مطالعه کامل مقاله');
  };

  const getCartItemsCount = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  const getPageTitle = () => {
    switch (currentPage) {
      case 'phones': return 'سیستم‌های تلفنی';
      case 'accessories': return 'لوازم جانبی';
      case 'products': return 'تمام محصولات';
      case 'articles': return 'مقالات و راهنماها';
      case 'support': return 'خدمات فنی';
      case 'about': return 'درباره ما';
      case 'dashboard': return 'داشبورد کاربری';
      case 'admin': return 'پنل مدیریت';
      case 'orders': return 'سفارشات من';
      case 'wishlist': return 'علاقه‌مندی‌ها';
      default: return '';
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
  };

  const renderContent = () => {
    switch (currentPage) {
      case 'home':
        return (
          <div className="space-y-20">
            <Hero onNavigate={handleNavigation} />
            
            {/* Featured Products */}
            <section className="container mx-auto px-4">
              <div className="text-center mb-16">
                <h2 className="text-4xl font-bold text-gray-800 mb-6">محصولات ویژه</h2>
                <p className="text-xl text-gray-600">جدیدترین و پرفروش‌ترین محصولات ما</p>
              </div>
              <ProductGrid
                products={products.slice(0, 6)}
                loading={loading}
                onAddToCart={handleAddToCart}
                onToggleFavorite={handleToggleFavorite}
                onViewProduct={handleViewProduct}
              />
              <div className="text-center mt-16">
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => handleNavigation('products')}
                  className="px-12 py-4 text-lg rounded-2xl border-2 border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white"
                >
                  مشاهده همه محصولات
                  <ChevronLeft className="mr-3 w-5 h-5" />
                </Button>
              </div>
            </section>

            {/* Categories Section */}
            <section className="bg-gradient-to-l from-gray-50 to-white py-20">
              <div className="container mx-auto px-4">
                <div className="text-center mb-16">
                  <h2 className="text-4xl font-bold text-gray-800 mb-6">دسته‌بندی محصولات</h2>
                  <p className="text-xl text-gray-600">انتخاب کنید و خرید کنید</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  <Card className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group border-0 shadow-lg" onClick={() => handleNavigation('phones')}>
                    <CardContent className="p-10 text-center">
                      <div className="bg-gradient-to-br from-blue-100 to-blue-200 w-24 h-24 rounded-2xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                        <Phone className="w-12 h-12 text-blue-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-800 mb-4">سیستم‌های تلفنی</h3>
                      <p className="text-gray-600 text-lg">سنترال، VoIP و تلفن‌های آی‌پی</p>
                      <Badge className="mt-4 bg-blue-100 text-blue-600">{products.filter(p => p.category === 'سیستم‌های تلفنی').length} محصول</Badge>
                    </CardContent>
                  </Card>

                  <Card className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group border-0 shadow-lg" onClick={() => handleNavigation('accessories')}>
                    <CardContent className="p-10 text-center">
                      <div className="bg-gradient-to-br from-green-100 to-green-200 w-24 h-24 rounded-2xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                        <Headphones className="w-12 h-12 text-green-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-800 mb-4">لوازم جانبی</h3>
                      <p className="text-gray-600 text-lg">هدست، آداپتور، کابل و تجهیزات شبکه</p>
                      <Badge className="mt-4 bg-green-100 text-green-600">{products.filter(p => p.category === 'لوازم جانبی').length} محصول</Badge>
                    </CardContent>
                  </Card>

                  <Card className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group border-0 shadow-lg" onClick={() => handleNavigation('support')}>
                    <CardContent className="p-10 text-center">
                      <div className="bg-gradient-to-br from-purple-100 to-purple-200 w-24 h-24 rounded-2xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                        <Settings className="w-12 h-12 text-purple-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-800 mb-4">خدمات فنی</h3>
                      <p className="text-gray-600 text-lg">نصب، راه‌اندازی و پشتیبانی</p>
                      <Badge className="mt-4 bg-purple-100 text-purple-600">خدمات ۲۴/۷</Badge>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </section>

            {/* Articles Section */}
            <section className="container mx-auto px-4">
              <div className="text-center mb-16">
                <h2 className="text-4xl font-bold text-gray-800 mb-6">مقالات و راهنماها</h2>
                <p className="text-xl text-gray-600 text-center">مطالب آموزشی و اخبار تکنولوژی</p>
              </div>
              <ArticleGrid
                articles={articles.slice(0, 4)}
                onLike={handleLikeArticle}
                onShare={handleShareArticle}
                onReadMore={handleReadMore}
              />
              <div className="text-center mt-16">
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => handleNavigation('articles')}
                  className="px-12 py-4 text-lg rounded-2xl border-2 border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white"
                >
                  مشاهده همه مقالات
                  <ChevronLeft className="mr-3 w-5 h-5" />
                </Button>
              </div>
            </section>
          </div>
        );

      case 'products':
      case 'phones':
      case 'accessories':
      case 'repairs':
        return (
          <div className="container mx-auto px-4 py-12">
            <div className="mb-12">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">{getPageTitle()}</h1>
              <p className="text-xl text-gray-600">بهترین محصولات با قیمت مناسب و کیفیت بالا</p>
              
              {/* Filters and Search */}
              <div className="flex flex-col lg:flex-row gap-6 mt-10 bg-white p-6 rounded-2xl shadow-lg">
                <div className="flex-1">
                  <div className="relative">
                    <Input
                      placeholder="جستجو در محصولات..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="h-12 pr-4 pl-12 rounded-xl border-2 border-gray-200 focus:border-orange-500 text-right"
                    />
                    <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>
                
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full lg:w-56 h-12 rounded-xl">
                    <SelectValue placeholder="دسته‌بندی" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full lg:w-56 h-12 rounded-xl">
                    <SelectValue placeholder="مرتب‌سازی" />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex gap-3">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'outline'}
                    size="icon"
                    onClick={() => setViewMode('grid')}
                    className="h-12 w-12 rounded-xl"
                  >
                    <Grid3X3 className="w-5 h-5" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="icon"
                    onClick={() => setViewMode('list')}
                    className="h-12 w-12 rounded-xl"
                  >
                    <List className="w-5 h-5" />
                  </Button>
                </div>
              </div>

              {/* Results Count */}
              <div className="flex justify-between items-center mt-8">
                <p className="text-lg text-gray-600">
                  {products.length} محصول یافت شد
                </p>
                {!loading && products.length === 0 && (
                  <p className="text-gray-500">هیچ محصولی یافت نشد</p>
                )}
              </div>
            </div>

            <ProductGrid
              products={products}
              loading={loading}
              onAddToCart={handleAddToCart}
              onToggleFavorite={handleToggleFavorite}
              onViewProduct={handleViewProduct}
            />
          </div>
        );

      case 'articles':
        const totalArticles = articlesData.length;
        const totalPages = Math.ceil(totalArticles / articlesPerPage);
        const startIndex = (currentArticlePage - 1) * articlesPerPage;
        const endIndex = startIndex + articlesPerPage;
        const currentArticles = articlesData.slice(startIndex, endIndex);
        
        return (
          <>
            <div className="container mx-auto px-4 py-12">
              <div className="mb-12">
                <h1 className="text-4xl font-bold text-gray-800 mb-4 text-center">مقالات و راهنماها</h1>
                <p className="text-xl text-gray-600 text-center">مطالب آموزشی و اخبار تکنولوژی</p>
                
                <div className="flex justify-between items-center mt-8">
                  <p className="text-lg text-gray-600">
                    {totalArticles.toLocaleString('fa-IR')} مقاله منتشر شده
                  </p>
                  <p className="text-lg text-gray-600">
                    صفحه {currentArticlePage.toLocaleString('fa-IR')} از {totalPages.toLocaleString('fa-IR')}
                  </p>
                </div>
              </div>

              <ArticleGrid
                articles={currentArticles}
                loading={loading}
                onLike={handleLikeArticle}
                onShare={handleShareArticle}
                onReadMore={(articleId) => {
                  const article = articlesData.find(a => a.id === articleId);
                  setSelectedArticle(article || null);
                }}
              />
              
              {/* Pagination */}
              <div className="mt-12 flex flex-wrap justify-center items-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => setCurrentArticlePage(1)}
                  disabled={currentArticlePage === 1}
                  className="rounded-xl"
                >
                  اولین صفحه
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => setCurrentArticlePage(Math.max(1, currentArticlePage - 1))}
                  disabled={currentArticlePage === 1}
                  className="rounded-xl"
                >
                  قبلی
                </Button>
                
                {[...Array(Math.min(10, totalPages))].map((_, i) => {
                  const pageNum = Math.max(1, currentArticlePage - 5) + i;
                  if (pageNum > totalPages) return null;
                  return (
                    <Button
                      key={pageNum}
                      variant={currentArticlePage === pageNum ? 'default' : 'outline'}
                      onClick={() => setCurrentArticlePage(pageNum)}
                      className="rounded-xl w-12"
                    >
                      {pageNum.toLocaleString('fa-IR')}
                    </Button>
                  );
                })}
                
                <Button
                  variant="outline"
                  onClick={() => setCurrentArticlePage(Math.min(totalPages, currentArticlePage + 1))}
                  disabled={currentArticlePage === totalPages}
                  className="rounded-xl"
                >
                  بعدی
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => setCurrentArticlePage(totalPages)}
                  disabled={currentArticlePage === totalPages}
                  className="rounded-xl"
                >
                  آخرین صفحه
                </Button>
              </div>
            </div>
            
            <ArticleDetailModal
              article={selectedArticle}
              open={selectedArticle !== null}
              onClose={() => setSelectedArticle(null)}
              onLike={handleLikeArticle}
              onShare={handleShareArticle}
            />
          </>
        );

      case 'support':
        return (
          <div className="container mx-auto px-4 py-12">
            <div className="mb-12">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">خدمات فنی</h1>
              <p className="text-xl text-gray-600">نصب، راه‌اندازی و پشتیبانی سیستم‌های تلفنی</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <div className="bg-blue-100 p-3 rounded-xl">
                      <Phone className="w-6 h-6 text-blue-600" />
                    </div>
                    نصب سنترال تلفنی
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">نصب و راه‌اندازی انواع سنترال‌های تلفنی و سیستم‌های VoIP</p>
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>ضمانت یک ساله</span>
                  </div>
                  <Button className="w-full mt-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl shadow-md" onClick={() => toast.info('تماس با کارشناس نصب')}>
                    درخواست نصب
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <div className="bg-green-100 p-3 rounded-xl">
                      <Settings className="w-6 h-6 text-green-600" />
                    </div>
                    پیکربندی سیستم
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">تنظیم و پیکربندی سیستم‌های تلفنی، برنامه‌ریزی و بهینه‌سازی</p>
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>مشاوره رایگان</span>
                  </div>
                  <Button className="w-full mt-4 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-xl shadow-md" onClick={() => toast.info('تماس با کارشناس پیکربندی')}>
                    درخواست پیکربندی
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <div className="bg-purple-100 p-3 rounded-xl">
                      <Shield className="w-6 h-6 text-purple-600" />
                    </div>
                    پشتیبانی ۲۴/۷
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">پشتیبانی مستمر، نگهداری دوره‌ای و رفع سریع مشکلات</p>
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>پاسخگویی فوری</span>
                  </div>
                  <Button variant="outline" className="w-full mt-4 border-purple-200 text-purple-600 hover:bg-purple-50 rounded-xl" onClick={() => toast.info('تماس با پشتیبانی')}>
                    تماس با پشتیبانی
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 'about':
        return (
          <div className="container mx-auto px-4 py-12">
            <div className="max-w-5xl mx-auto">
              <h1 className="text-4xl font-bold text-center text-gray-800 mb-12">درباره تله‌کام سنتر</h1>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-16">
                <div className="space-y-8">
                  <h2 className="text-3xl font-bold text-gray-800 text-center">داستان ما</h2>
                  <p className="text-lg text-gray-600 leading-relaxed text-right">
                    تله‌کام سنتر با بیش از ۱۰ سال تجربه در زمینه فروش و نصب سیستم‌های تلفنی، 
                    یکی از معتبرترین مراکز در حوزه ارتباطات و تله‌کام محسوب می‌شود. ما همواره در تلاش برای ارائه 
                    بهترین راه‌حل‌های ارتباطی و سیستم‌های تلفنی به مشتریان عزیزمان هستیم.
                  </p>
                </div>
                
                <div className="space-y-8">
                  <h2 className="text-3xl font-bold text-gray-800 text-center">ماموریت ما</h2>
                  <p className="text-lg text-gray-600 leading-relaxed text-right">
                    هدف ما ارائه بهترین سیستم‌های تلفنی و ارتباطی، خدمات فنی متخصص و پشتیبانی مستمر 
                    برای شرکت‌ها و سازمان‌ها است. تیم ما متشکل از متخصصان مجرب در زمینه سیستم‌های VoIP و تله‌کام است.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
                <div className="text-center bg-white p-8 rounded-2xl shadow-lg">
                  <div className="bg-gradient-to-br from-blue-100 to-blue-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Users className="w-10 h-10 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">+۱۰ هزار</h3>
                  <p className="text-gray-600">مشتری راضی از خدمات ما</p>
                </div>

                <div className="text-center bg-white p-8 rounded-2xl shadow-lg">
                  <div className="bg-gradient-to-br from-green-100 to-green-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Award className="w-10 h-10 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">۱۰ سال</h3>
                  <p className="text-gray-600">تجربه در سیستم‌های تلفنی</p>
                </div>

                <div className="text-center bg-white p-8 rounded-2xl shadow-lg">
                  <div className="bg-gradient-to-br from-orange-100 to-orange-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Shield className="w-10 h-10 text-orange-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">۱۰۰٪</h3>
                  <p className="text-gray-600">ضمانت اصالت محصولات</p>
                </div>

                <div className="text-center bg-white p-8 rounded-2xl shadow-lg">
                  <div className="bg-gradient-to-br from-purple-100 to-purple-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Truck className="w-10 h-10 text-purple-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">۲۴/۷</h3>
                  <p className="text-gray-600">پشتیبانی فنی</p>
                </div>
              </div>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-center">تماس با ما</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex items-center gap-4">
                      <div className="bg-orange-100 p-3 rounded-lg">
                        <Phone className="w-6 h-6 text-orange-600" />
                      </div>
                      <div className="text-center flex-1">
                        <p className="font-semibold text-gray-800">تلفن</p>
                        <p className="text-gray-600">۰۲۱-۱۲۳۴۵۶۷۸</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <Truck className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="text-center flex-1">
                        <p className="font-semibold text-gray-800">آدرس</p>
                        <p className="text-gray-600">تهران، خیابان انقلاب، پلاک ۱۲۳</p>
                      </div>
                    </div>
                  </div>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600 rounded-xl" onClick={() => toast.info('تماس با ما')}>
                    تماس با ما
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 'dashboard':
        return (
          <UserDashboard user={user || undefined} />
        );

      case 'orders':
        return (
          <div className="container mx-auto px-4 py-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-12">سفارشات من</h1>
            <Card className="border-0 shadow-lg">
              <CardContent className="p-12 text-center">
                <div className="bg-gray-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <ShoppingCartIcon className="w-10 h-10 text-gray-400" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">هنوز سفارشی ثبت نکرده‌اید</h3>
                <p className="text-gray-600 mb-8">برای مشاهده سفارشات، ابتدا خریدی انجام دهید</p>
                <Button className="bg-orange-500 hover:bg-orange-600 rounded-xl px-8 py-3" onClick={() => handleNavigation('products')}>
                  شروع خرید
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      case 'wishlist':
        return (
          <div className="container mx-auto px-4 py-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-12">علاقه‌مندی‌ها</h1>
            <Card className="border-0 shadow-lg">
              <CardContent className="p-12 text-center">
                <div className="bg-red-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="w-10 h-10 text-red-500" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">لیست علاقه‌مندی‌ها خالی است</h3>
                <p className="text-gray-600 mb-8">محصولات مورد علاقه خود را به این لیست اضافه کنید</p>
                <Button className="bg-orange-500 hover:bg-orange-600 rounded-xl px-8 py-3" onClick={() => handleNavigation('products')}>
                  مشاهده محصولات
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      case 'admin':
        return (
          <AdminDashboard
            onAddProduct={() => toast.info('افزودن محصول جدید')}
            onEditProduct={(id) => toast.info(`ویرایش محصول ${id}`)}
            onDeleteProduct={(id) => toast.info(`حذف محصول ${id}`)}
            onAddArticle={() => toast.info('نوشتن مقاله جدید')}
            onEditArticle={(id) => toast.info(`ویرایش مقاله ${id}`)}
          />
        );

      case 'survey-form':
        return <SurveyForm />;

      case 'contact-us':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-6xl mx-auto">
                <div className="text-center mb-12">
                  <h1 className="text-4xl font-bold text-gray-800 mb-4">تماس با ما</h1>
                  <p className="text-xl text-gray-600">
                    ما آماده پاسخگویی به سوالات شما هستیم
                  </p>
                </div>
                
                {/* Tehran Office */}
                <Card className="border-0 shadow-xl mb-8 bg-gradient-to-br from-blue-50 to-white">
                  <CardHeader>
                    <CardTitle className="text-2xl text-center text-blue-800">دفتر تهران</CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <MapPin className="w-5 h-5 text-blue-600" />
                          آدرس
                        </h3>
                        <p className="text-gray-700 leading-relaxed mb-2">
                          جمال زاده شمالی، نبش قدر، پلاک 301.1، طبقه سوم، واحد12
                        </p>
                        <p className="text-gray-600 text-sm">کد پستی: 1418893137</p>
                      </div>
                      
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <Phone className="w-5 h-5 text-blue-600" />
                          تلفن تماس
                        </h3>
                        <p className="text-gray-700 mb-1">۰۲۱-۴۶۰۵۴۷۵۴</p>
                        <p className="text-gray-700 mb-1">۰۲۱-۶۵۰۱۴۰۰۵</p>
                        <p className="text-gray-700 mb-1">۰۲۱-۶۵۰۲۴۰۳۶</p>
                        <p className="text-gray-700 mb-3 mt-3">
                          <span className="font-bold">موبایل:</span> ۰۹۱۲۰۲۸۲۸۴۵
                        </p>
                        <p className="text-gray-700">
                          <span className="font-bold">نمابر:</span> ۰۲۱-۴۶۰۵۴۸۵۴
                        </p>
                      </div>
                    </div>
                    <div className="mt-6 pt-6 border-t">
                      <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
                        <MessageCircle className="w-5 h-5 text-blue-600" />
                        پست الکترونیک
                      </h3>
                      <p className="text-gray-700">hzpirco@yahoo.com , info@hzp.ir</p>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Isfahan Office */}
                <Card className="border-0 shadow-xl mb-8 bg-gradient-to-br from-green-50 to-white">
                  <CardHeader>
                    <CardTitle className="text-2xl text-center text-green-800">دفتر اصفهان</CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <MapPin className="w-5 h-5 text-green-600" />
                          آدرس
                        </h3>
                        <p className="text-gray-700 leading-relaxed mb-2">
                          کیلومتر 15 اتوبان نجف آباد به تیران، ناحیه صنعتی نهضت آباد
                        </p>
                        <p className="text-gray-600 text-sm">کد پستی: 8359189496</p>
                      </div>
                      
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <Phone className="w-5 h-5 text-green-600" />
                          تلفن تماس
                        </h3>
                        <p className="text-gray-700 mb-3">۰۳۱-۴۲۵۵۶۰۰۵</p>
                        <p className="text-gray-700 mb-3">
                          <span className="font-bold">موبایل:</span> ۰۹۱۲۰۲۸۱۳۷۸
                        </p>
                        <p className="text-gray-700">
                          <span className="font-bold">نمابر:</span> ۰۳۱-۴۲۵۵۶۰۰۵
                        </p>
                      </div>
                    </div>
                    <div className="mt-6 pt-6 border-t">
                      <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
                        <MessageCircle className="w-5 h-5 text-green-600" />
                        پست الکترونیک
                      </h3>
                      <p className="text-gray-700">hzpirco@yahoo.com , info@hzp.ir</p>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Ahvaz Office */}
                <Card className="border-0 shadow-xl mb-8 bg-gradient-to-br from-orange-50 to-white">
                  <CardHeader>
                    <CardTitle className="text-2xl text-center text-orange-800">دفتر اهواز</CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <MapPin className="w-5 h-5 text-orange-600" />
                          آدرس
                        </h3>
                        <p className="text-gray-700 leading-relaxed mb-2">
                          کوی ملت، نبش خیابان 8 اقبال، مجتمع ایرانیان، طبقه دوم، واحد 6
                        </p>
                        <p className="text-gray-600 text-sm">کد پستی: 6164735466</p>
                      </div>
                      
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <Phone className="w-5 h-5 text-orange-600" />
                          تلفن تماس
                        </h3>
                        <p className="text-gray-700 mb-3">۰۶۱-۳۴۴۸۲۶۰۱-۳</p>
                        <p className="text-gray-700 mb-3">
                          <span className="font-bold">موبایل:</span> ۰۹۱۶۱۱۱۳۴۴۸
                        </p>
                        <p className="text-gray-700">
                          <span className="font-bold">نمابر:</span> ۰۶۱-۳۴۴۷۸۲۶۲
                        </p>
                      </div>
                    </div>
                    <div className="mt-6 pt-6 border-t">
                      <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
                        <Clock className="w-5 h-5 text-orange-600" />
                        ساعات کاری
                      </h3>
                      <p className="text-gray-700">شنبه تا پنجشنبه ساعت 7:30 الی 16</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'free-consultation':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-3xl mx-auto">
                <div className="text-center mb-12">
                  <h1 className="text-4xl font-bold text-gray-800 mb-4">درخواست مشاوره رایگان</h1>
                  <p className="text-xl text-gray-600">
                    کارشناسان ما آماده ارائه مشاوره رایگان برای انتخاب بهترین محصول هستند
                  </p>
                </div>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-8">
                    <div className="text-center mb-8">
                      <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Phone className="w-10 h-10 text-green-600" />
                      </div>
                      <h2 className="text-2xl font-bold text-gray-800 mb-4">
                        برای دریافت مشاوره رایگان تماس بگیرید
                      </h2>
                      <div className="space-y-4">
                        <Button
                          size="lg"
                          className="w-full bg-orange-500 hover:bg-orange-600 rounded-xl py-6"
                          onClick={() => window.location.href = 'tel:09120282845'}
                        >
                          <Phone className="w-5 h-5 ml-2" />
                          موبایل: ۰۹۱۲۰۲۸۲۸۴۵
                        </Button>
                        <Button
                          size="lg"
                          className="w-full bg-blue-500 hover:bg-blue-600 rounded-xl py-6"
                          onClick={() => window.location.href = 'tel:02146054754'}
                        >
                          <Phone className="w-5 h-5 ml-2" />
                          تلفن: ۰۲۱۴۶۰۵۴۷۵۴
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'job-request':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                  <h1 className="text-4xl font-bold text-gray-800 mb-4">درخواست استخدام</h1>
                  <p className="text-xl text-gray-600">
                    به تیم هوشمند زمان پارت بپیوندید
                  </p>
                </div>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-8">
                    <div className="prose max-w-none text-right">
                      <h3 className="text-2xl font-bold text-gray-800 mb-4">فرصت های شغلی</h3>
                      <p className="text-gray-600 mb-6 leading-relaxed">
                        شرکت هوشمند زمان پارت به دنبال جذب نیروهای متخصص و با انگیزه در زمینه های مختلف می باشد.
                        برای ارسال رزومه و اطلاعات بیشتر با ما تماس بگیرید.
                      </p>
                      <div className="bg-blue-50 p-6 rounded-xl mb-6">
                        <h4 className="text-xl font-bold text-gray-800 mb-3">موقعیت های شغلی مورد نیاز:</h4>
                        <ul className="space-y-2 text-gray-600">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>متخصص نصب و راه اندازی مراکز تلفن</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>کارشناس فروش تجهیزات شبکه</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>تکنسین تعمیرات</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>کارشناس پشتیبانی فنی</span>
                          </li>
                        </ul>
                      </div>
                      <Button
                        size="lg"
                        className="w-full bg-orange-500 hover:bg-orange-600 rounded-xl"
                        onClick={() => window.location.href = 'tel:09120282845'}
                      >
                        <Phone className="w-5 h-5 ml-2" />
                        تماس برای ارسال رزومه
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'faq':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                  <h1 className="text-4xl font-bold text-gray-800 mb-4">پرسش های متداول</h1>
                  <p className="text-xl text-gray-600">
                    پاسخ سوالات رایج شما در اینجا
                  </p>
                </div>
                <div className="space-y-6">
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <h3 className="text-xl font-bold text-gray-800 mb-3">
                        آیا محصولات شما اصل و دارای گارانتی هستند؟
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        بله، تمامی محصولات ما اصل و دارای گارانتی معتبر از شرکت های پاناسونیک، زیمنس و سایر برندهای معتبر می باشند.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <h3 className="text-xl font-bold text-gray-800 mb-3">
                        آیا خدمات نصب و راه اندازی ارائه می دهید؟
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        بله، ما خدمات کامل نصب، راه اندازی و پشتیبانی مراکز تلفن را در تهران و اهواز ارائه می دهیم.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <h3 className="text-xl font-bold text-gray-800 mb-3">
                        چگونه می توانم قیمت محصولات را مشاهده کنم؟
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        برای دریافت قیمت به روز محصولات لطفا با شماره های ۰۹۱۲۰۲۸۲۸۴۵ یا ۰۲۱۴۶۰۵۴۷۵۴ تماس بگیرید.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <h3 className="text-xl font-bold text-gray-800 mb-3">
                        آیا ارسال به شهرستان دارید؟
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        بله، ما محصولات را به سراسر کشور ارسال می کنیم.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        );

      case 'customer-voice':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                  <h1 className="text-4xl font-bold text-gray-800 mb-4">صدای مشتری</h1>
                  <p className="text-xl text-gray-600">
                    نظرات مشتریان ما
                  </p>
                </div>
                <div className="space-y-6">
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center">
                          <Users className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-800">شرکت صنایع الکترونیک</h3>
                          <div className="flex gap-1 mt-1">
                            {[1, 2, 3, 4, 5].map((i) => (
                              <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-600 leading-relaxed">
                        خدمات عالی و محصولات با کیفیت. نصب سانترال پاناسونیک با بهترین کیفیت انجام شد.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center">
                          <Users className="w-6 h-6 text-green-600" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-800">شرکت ساختمانی مهر</h3>
                          <div className="flex gap-1 mt-1">
                            {[1, 2, 3, 4, 5].map((i) => (
                              <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-600 leading-relaxed">
                        تیم فنی بسیار حرفه ای و پشتیبانی عالی. از خدمات نصب مرکز تلفن بسیار راضی هستیم.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        );

      // Project pages
      case 'project-list':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-gray-800 mb-4">لیست پروژه ها</h1>
                <p className="text-xl text-gray-600">
                  نمونه پروژه‌های اجرا شده توسط هوشمند زمان پارت
                </p>
              </div>
              <ProjectGrid
                projects={projectsData}
                onViewDetails={(id) => toast.info('جزئیات پروژه')}
              />
            </div>
          </div>
        );
        
      case 'resume':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-gray-800 mb-4">رزومه پروژه‌ها</h1>
                <p className="text-xl text-gray-600">
                  خلاصه‌ای از پروژه‌های انجام شده
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {projectsData.slice(0, 50).map((project) => (
                  <Card key={project.id} className="border-0 shadow-lg hover:shadow-xl transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="bg-blue-100 p-3 rounded-xl flex-shrink-0">
                          <CheckCircle className="w-6 h-6 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-gray-800 mb-2">{project.title}</h3>
                          <div className="space-y-1 text-sm text-gray-600">
                            <p><span className="font-semibold">کارفرما:</span> {project.client}</p>
                            <p><span className="font-semibold">موقعیت:</span> {project.location}</p>
                            <p><span className="font-semibold">تاریخ:</span> {project.date}</p>
                            <p><span className="font-semibold">دسته‌بندی:</span> {project.category}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );
      
      // Service pages
      case 'communication-services':
        return (
          <ServicePage
            title="خدمات فناوری ارتباطات"
            description="ارائه خدمات جامع در زمینه سیستم‌های ارتباطی شامل طراحی، نصب، راه‌اندازی و پشتیبانی انواع سیستم‌های تلفنی دیجیتال و VoIP"
            features={[
              'طراحی و پیاده‌سازی سیستم‌های مرکز تلفن',
              'نصب و راه‌اندازی سانترال‌های دیجیتال',
              'پیکربندی سیستم‌های VoIP',
              'یکپارچه‌سازی با سیستم‌های موجود',
              'مشاوره تخصصی و ارائه راهکار',
              'پشتیبانی ۲۴ ساعته'
            ]}
            benefits={[
              'کاهش هزینه‌های ارتباطی تا ۵۰ درصد',
              'افزایش کیفیت و کارایی ارتباطات',
              'دسترسی به گزارشات دقیق و جامع'
            ]}
          />
        );
        
      case 'it-services':
        return (
          <ServicePage
            title="خدمات فناوری اطلاعات"
            description="ارائه خدمات IT شامل طراحی و پیاده‌سازی شبکه، نصب سرور، امنیت شبکه و پشتیبانی فنی"
            features={[
              'طراحی و پیاده‌سازی شبکه‌های کامپیوتری',
              'نصب و پیکربندی سرورها',
              'خدمات امنیت شبکه',
              'مدیریت و نگهداری سیستم‌ها',
              'پشتیبانی فنی و عیب‌یابی',
              'راه‌اندازی مراکز داده'
            ]}
            benefits={[
              'افزایش امنیت اطلاعات',
              'بهبود عملکرد سیستم‌ها',
              'کاهش زمان از کارافتادگی'
            ]}
          />
        );
        
      case 'av-services':
        return (
          <ServicePage
            title="خدمات سیستم های صوت و تصویر"
            description="طراحی و نصب سیستم‌های صوتی و تصویری حرفه‌ای برای سالن‌های کنفرانس، آمفی‌تئاترها و فضاهای عمومی"
            features={[
              'طراحی سیستم‌های صوتی',
              'نصب پروژکتور و صفحه نمایش',
              'سیستم‌های کنفرانس',
              'سیستم‌های پیجینگ',
              'تجهیزات ویدئو کنفرانس',
              'صوتی سازی فضاهای باز و بسته'
            ]}
            benefits={[
              'کیفیت صدا و تصویر بی‌نظیر',
              'راحتی در استفاده',
              'قابلیت کنترل هوشمند'
            ]}
          />
        );
        
      case 'surveillance-services':
        return (
          <ServicePage
            title="خدمات سیستم های نظارت تصویری"
            description="نصب و راه‌اندازی دوربین‌های مداربسته و سیستم‌های کنترل تردد با جدیدترین تکنولوژی"
            features={[
              'نصب دوربین‌های مداربسته',
              'سیستم‌های کنترل تردد',
              'تشخیص چهره و پلاک',
              'ضبط و ذخیره‌سازی تصاویر',
              'دسترسی از راه دور',
              'هشدارهای هوشمند'
            ]}
            benefits={[
              'افزایش امنیت محیط',
              'کنترل دقیق تردد',
              'گزارش‌گیری جامع'
            ]}
          />
        );
        
      case 'power-services':
        return (
          <ServicePage
            title="سیستم های منابع تغذیه"
            description="ارائه راهکارهای منبع تغذیه اضطراری شامل UPS، استابلایزر و ژنراتور"
            features={[
              'نصب سیستم‌های UPS',
              'استابلایزرهای ولتاژ',
              'ژنراتورهای برق اضطراری',
              'سیستم‌های انرژی خورشیدی',
              'باتری‌های صنعتی',
              'نگهداری و سرویس دوره‌ای'
            ]}
            benefits={[
              'تامین برق بدون وقفه',
              'حفاظت از تجهیزات',
              'صرفه‌جویی در هزینه‌ها'
            ]}
          />
        );
        
      case 'alarm-services':
        return (
          <ServicePage
            title="سیستم های هشدار دهنده"
            description="طراحی و نصب سیستم‌های اعلام حریق، دزدگیر و هشدار اضطراری"
            features={[
              'سیستم اعلام حریق',
              'دزدگیر اماکن',
              'سیستم هشدار اضطراری',
              'اطفاء حریق اتوماتیک',
              'سنسورهای هوشمند',
              'اتصال به مراکز کنترل'
            ]}
            benefits={[
              'حفاظت از جان و مال',
              'هشدار به موقع',
              'کاهش خسارات'
            ]}
          />
        );
        
      case 'after-sales':
        return (
          <ServicePage
            title="خدمات پس از فروش"
            description="پشتیبانی جامع و خدمات پس از فروش شامل گارانتی، تعمیرات و ارتقا سیستم‌ها"
            features={[
              'گارانتی کامل محصولات',
              'پشتیبانی ۲۴/۷',
              'تعمیرات تخصصی',
              'ارتقا و به‌روزرسانی',
              'قطعات یدکی اصل',
              'آموزش کاربران'
            ]}
            benefits={[
              'اطمینان از عملکرد سیستم',
              'حل سریع مشکلات',
              'افزایش عمر تجهیزات'
            ]}
          />
        );
        
      case 'maintenance':
        return (
          <ServicePage
            title="سرویس و تعمیرات"
            description="ارائه خدمات سرویس دوره‌ای، تعمیرات و نگهداری تجهیزات"
            features={[
              'سرویس دوره‌ای تجهیزات',
              'تعمیرات تخصصی',
              'عیب‌یابی و رفع مشکل',
              'تست و کالیبراسیون',
              'تعویض قطعات',
              'بازسازی و نوسازی'
            ]}
            benefits={[
              'افزایش عمر تجهیزات',
              'کاهش هزینه‌های تعمیر',
              'جلوگیری از خرابی‌های جدی'
            ]}
          />
        );
        
      case 'activity-areas':
        return (
          <ServicePage
            title="حوزه های فعالیت"
            description="شرکت هوشمند زمان پارت در حوزه‌های مختلف فعالیت دارد"
            features={[
              'سیستم‌های تلفنی و ارتباطی',
              'شبکه‌های کامپیوتری',
              'سیستم‌های امنیتی',
              'تجهیزات صوتی و تصویری',
              'منابع تغذیه',
              'اتوماسیون صنعتی',
              'سیستم‌های هوشمند',
              'مشاوره و طراحی'
            ]}
            benefits={[
              'تجربه گسترده در صنایع مختلف',
              'راهکارهای یکپارچه',
              'خدمات جامع و کامل'
            ]}
          />
        );
        
      // Product category pages
      case 'communications':
      case 'network':
      case 'audio':
      case 'camera':
      case 'power':
      case 'video':
      case 'office':
      case 'power-systems':
        const categoryNames: Record<string, string> = {
          'communications': 'مخابرات',
          'network': 'شبکه',
          'audio': 'صوت',
          'camera': 'دوربین',
          'power': 'منابع تغذیه',
          'video': 'تصویر',
          'office': 'ماشین های اداری',
          'power-systems': 'سیستم های تغذیه'
        };
        return (
          <div className="container mx-auto px-4 py-12">
            <div className="mb-12">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">{categoryNames[currentPage]}</h1>
              <p className="text-xl text-gray-600">محصولات {categoryNames[currentPage]}</p>
            </div>
            <ProductGrid
              products={products.filter(p => p.category.includes(categoryNames[currentPage]))}
              loading={loading}
              onAddToCart={handleAddToCart}
              onToggleFavorite={handleToggleFavorite}
              onViewProduct={handleViewProduct}
            />
          </div>
        );
        
      // Company pages
      case 'company-overview':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">آشنایی کلی با شرکت</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <div className="prose prose-lg max-w-none text-right leading-relaxed" style={{ direction: 'rtl' }}>
                      {companyOverviewText.split('\n\n').map((paragraph, index) => (
                        <p key={index} className="mb-6 text-gray-700">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      case 'company-history':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">تاریخچه تاسیس</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <div className="prose prose-lg max-w-none text-right leading-relaxed" style={{ direction: 'rtl' }}>
                      {companyHistoryText.split('\n\n').map((paragraph, index) => (
                        <p key={index} className="mb-6 text-gray-700">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      case 'equipment':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-gray-800 mb-4">تجهیزات و ماشین آلات</h1>
                <p className="text-xl text-gray-600">
                  تجهیزات پیشرفته برای ارائه بهترین خدمات
                </p>
              </div>
              <CompanyInfoCard items={equipmentData} showImages={true} />
            </div>
          </div>
        );
        
      case 'org-chart':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">چارت سازمانی</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <div className="prose prose-lg max-w-none text-right leading-relaxed" style={{ direction: 'rtl' }}>
                      {orgChartText.split('\n').map((line, index) => (
                        <p key={index} className="mb-3 text-gray-700">
                          {line}
                        </p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      case 'activity-fields':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">حوزه های فعالیت</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <div className="prose prose-lg max-w-none text-right leading-relaxed" style={{ direction: 'rtl' }}>
                      {activityFieldsText.split('\n\n').map((paragraph, index) => (
                        <p key={index} className="mb-6 text-gray-700">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      case 'smart-resume':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">رزومه هوشمند زمان پارت</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <div className="space-y-8">
                      <div>
                        <h2 className="text-2xl font-bold text-gray-800 mb-4">درباره شرکت</h2>
                        <p className="text-gray-700 leading-relaxed">
                          شرکت هوشمند زمان پارت با بیش از ۱۵ سال سابقه درخشان، یکی از پیشگامان صنعت سیستم‌های ارتباطی در کشور است.
                        </p>
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-gray-800 mb-4">تعداد پروژه‌ها</h2>
                        <p className="text-gray-700 leading-relaxed">
                          بیش از {projectsData.length} پروژه موفق در سراسر کشور
                        </p>
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-gray-800 mb-4">مشتریان</h2>
                        <p className="text-gray-700 leading-relaxed">
                          همکاری با بیش از ۱۰۰۰ شرکت و سازمان معتبر
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      case 'main-clients':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-5xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">اهم مشتریان ما</h1>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                  {clientsData.map((client, index) => (
                    <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all">
                      <CardContent className="p-8 text-center">
                        <h3 className="text-lg font-bold text-gray-800">{client.name}</h3>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
        
      case 'certificates':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">گواهی حسن انجام کار</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <p className="text-gray-700 leading-relaxed text-center mb-8">
                      شرکت هوشمند زمان پارت دارای گواهی‌های متعدد حسن انجام کار از سازمان‌ها و شرکت‌های معتبر می‌باشد.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {[1, 2, 3, 4, 5, 6].map((i) => (
                        <div key={i} className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl">
                          <div className="flex items-center gap-3 mb-3">
                            <Award className="w-6 h-6 text-blue-600" />
                            <h3 className="font-bold text-gray-800">گواهینامه {i}</h3>
                          </div>
                          <p className="text-sm text-gray-600">گواهی حسن انجام کار پروژه شماره {i}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      case 'achievements':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-gray-800 mb-4">دستاوردها و افتخارات</h1>
                <p className="text-xl text-gray-600">
                  جوایز و افتخارات کسب شده توسط شرکت
                </p>
              </div>
              <CompanyInfoCard items={achievementsData} showImages={true} />
            </div>
          </div>
        );
        
      case 'catalog':
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">کاتالوگ شرکت</h1>
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-12">
                    <div className="prose prose-lg max-w-none text-right leading-relaxed" style={{ direction: 'rtl' }}>
                      {catalogText.split('\n\n').map((paragraph, index) => (
                        <p key={index} className="mb-6 text-gray-700">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                    <div className="mt-8 text-center">
                      <Button
                        size="lg"
                        className="bg-orange-500 hover:bg-orange-600 rounded-xl"
                        onClick={() => toast.info('دانلود کاتالوگ')}
                      >
                        دانلود کاتالوگ PDF
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="container mx-auto px-4 py-12 text-center">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">صفحه یافت نشد</h1>
            <p className="text-xl text-gray-600 mb-8">صفحه مورد نظر شما وجود ندارد</p>
            <Button className="bg-orange-500 hover:bg-orange-600 rounded-xl px-8 py-3" onClick={() => handleNavigation('home')}>
              بازگشت به خانه
            </Button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      <Header
        cartItemsCount={getCartItemsCount()}
        isLoggedIn={isLoggedIn}
        user={user}
        onLogin={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
        onCartClick={() => setIsCartOpen(true)}
        onNavigate={handleNavigation}
        onOpenProductModal={handleOpenProductCategoryModal}
      />

      <main>
        {selectedProductCategory ? (
          <ProductDetailPage
            title={selectedProductCategory.label}
            categoryId={selectedProductCategory.id}
            onBack={handleBackFromProductDetail}
            onAddToCart={() => toast.info('افزودن به سبد خرید')}
          />
        ) : (
          renderContent()
        )}
      </main>

      <Footer />

      {/* Modals */}
      <AuthModal
        open={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      <ShoppingCart
        open={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
        onCheckout={() => {
          setIsCartOpen(false);
          toast.success('هدایت به صفحه پرداخت');
        }}
      />

      {/* Product Category Navigation Modal */}
      <ProductCategoryModal
        open={isProductCategoryModalOpen}
        onClose={handleCloseProductCategoryModal}
        categories={
          currentCategoryPath.length > 0
            ? currentCategoryPath[currentCategoryPath.length - 1].children || []
            : productCategories
        }
        title={
          currentCategoryPath.length > 0
            ? currentCategoryPath[currentCategoryPath.length - 1].label
            : 'محصولات'
        }
        onSelectCategory={handleSelectProductCategory}
        breadcrumbs={currentCategoryPath}
        onBreadcrumbClick={handleBreadcrumbClick}
      />

      <Toaster 
        position="top-center"
        richColors
        dir="rtl"
        toastOptions={{
          duration: 4000,
          style: {
            fontFamily: 'Vazirmatn',
          },
        }}
      />
    </div>
  );
}