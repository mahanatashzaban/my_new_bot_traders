// Product data generator for different categories
export interface ProductItem {
  id: string;
  title: string;
  description: string;
  features: string[];
  price: string;
  image?: string;
}

// Generate products for each category
export function generateProductsForCategory(categoryId: string, categoryLabel: string): ProductItem[] {
  const products: ProductItem[] = [];
  
  // Product templates based on category
  const productTemplates: Record<string, { prefix: string; items: string[]; features: string[][] }> = {
    'phone-desk': {
      prefix: 'تلفن رومیزی',
      items: [
        'پاناسونیک KX-TS500',
        'پاناسونیک KX-TS880',
        'زیمنس Gigaset DA210',
        'زیمنس Euroset 5020',
        'آلکاتل T26',
        'آلکاتل T56',
        'بیتل مدل 050',
        'بیتل مدل 070',
      ],
      features: [
        ['شماره گیر دکمه ای', 'نمایشگر LCD', 'حافظه شماره', 'قابلیت دیواری'],
        ['شماره گیر دکمه ای', 'بدون نیاز به برق', 'مقاوم و بادوام', 'صدای واضح'],
        ['نمایشگر LED', 'کیفیت ساخت بالا', 'قابلیت نگه داشتن مکالمه', 'حجم و وزن کم'],
      ]
    },
    'phone-wireless': {
      prefix: 'تلفن بی سیم',
      items: [
        'پاناسونیک KX-TG1611',
        'پاناسونیک KX-TG6811',
        'زیمنس Gigaset A120',
        'زیمنس Gigaset C430',
        'فیلیپس D1301',
        'موتورولا C1001',
      ],
      features: [
        ['برد تا 50 متر', 'شناسایی تماس گیرنده', 'مکالمه تا 10 ساعت', 'آماده به کار تا 100 ساعت'],
        ['بلوتوث', 'بلندگوی قدرتمند', 'دفترچه تلفن 100 شماره', 'نمایشگر رنگی'],
      ]
    },
    'phone-pbx': {
      prefix: 'تلفن سانترال',
      items: [
        'پاناسونیک KX-DT333',
        'پاناسونیک KX-NT136',
        'زیمنس OpenStage 15',
        'سیسکو 7841',
        'Yealink SIP-T21P',
        'Grandstream GXP1620',
      ],
      features: [
        ['نمایشگر LCD', '24 کلید عملکردی', 'قابلیت نصب دیواری', 'کیفیت صدای HD'],
        ['پورت شبکه Gigabit', 'POE', 'بلندگوی قدرتمند', '4 خط SIP'],
      ]
    },
    'phone-network': {
      prefix: 'تلفن شبکه IP',
      items: [
        'پاناسونیک KX-HDV130',
        'یالینک SIP-T46S',
        'سیسکو IP Phone 8841',
        'Grandstream GXP2140',
        'Fanvil X4',
        'Akuvox SP-R50P',
      ],
      features: [
        ['پشتیبانی از SIP', 'کیفیت صدای HD', 'نمایشگر رنگی', 'قابلیت POE'],
        ['پورت Gigabit', 'بلوتوث', 'WiFi', 'نمایشگر لمسی'],
      ]
    },
    'pbx-low': {
      prefix: 'سانترال کم ظرفیت',
      items: [
        'پاناسونیک KX-TES824',
        'پاناسونیک KX-TDA100',
        'زیمنس HiPath 1120',
        'آلکاتل OmniPCX Office',
      ],
      features: [
        ['ظرفیت 8 خط شهری', '24 داخلی', 'قابلیت ارتقاء', 'صدای دیجیتال'],
        ['پشتیبانی از VoIP', 'سیستم صوتی', 'موزیک انتظار', 'ضبط مکالمه'],
      ]
    },
    'pbx-high': {
      prefix: 'سانترال پر ظرفیت',
      items: [
        'پاناسونیک KX-TDA600',
        'پاناسونیک KX-NS1000',
        'زیمنس HiPath 4000',
        'آلکاتل OmniPCX Enterprise',
      ],
      features: [
        ['ظرفیت 256 خط', 'قابلیت توسعه', 'سیستم یکپارچه', 'پشتیبانی IP و TDM'],
        ['مدیریت هوشمند', 'یکپارچه سازی', 'امنیت بالا', 'گزارشات کامل'],
      ]
    },
  };

  // Get template or use default
  const template = productTemplates[categoryId] || {
    prefix: categoryLabel,
    items: Array(8).fill('محصول'),
    features: [['ویژگی 1', 'ویژگی 2', 'ویژگی 3', 'ویژگی 4']]
  };

  // Generate 50+ products
  for (let i = 1; i <= 60; i++) {
    const itemIndex = (i - 1) % template.items.length;
    const featureIndex = (i - 1) % template.features.length;
    
    products.push({
      id: `${categoryId}-${i}`,
      title: `${template.prefix} ${template.items[itemIndex]} - مدل ${i}`,
      description: `این محصول یکی از بهترین و با کیفیت ترین محصولات ${categoryLabel} موجود در بازار است. با طراحی مدرن و کارایی بالا، این محصول برای استفاده در محیط های مختلف اداری، تجاری و صنعتی مناسب می باشد. ساخت کشور اصلی با گارانتی معتبر و خدمات پس از فروش.`,
      features: template.features[featureIndex],
      price: 'تماس بگیرید',
    });
  }

  return products;
}

// Contact phone numbers
export const contactPhones = {
  mobile: '09120282845',
  phone: '02146054754',
  display: '۰۹۱۲۰۲۸۲۸۴۵ - ۰۲۱۴۶۰۵۴۷۵۴'
};
