// Sample project data - 50 projects for each category
export const generateProjects = (count: number = 50) => {
  const clients = [
    'بانک ملی ایران', 'بانک صادرات', 'شرکت ملی نفت', 'سازمان تامین اجتماعی',
    'شرکت مخابرات', 'بیمارستان شریعتی', 'بیمارستان امام خمینی', 'دانشگاه تهران',
    'شرکت ساخت و ساز مهر', 'شرکت صنایع الکترونیک', 'هتل پارسیان آزادی',
    'فرودگاه امام خمینی', 'شرکت پتروشیمی', 'سازمان برنامه و بودجه',
    'وزارت ارتباطات', 'شهرداری تهران', 'شرکت فولاد', 'پالایشگاه نفت',
    'بانک رفاه', 'بانک سپه', 'شرکت خودروسازی', 'دانشگاه صنعتی شریف',
    'مجتمع تجاری ایران مال', 'شرکت بیمه ایران', 'سازمان انرژی اتمی'
  ];

  const locations = [
    'تهران', 'اصفهان', 'شیراز', 'مشهد', 'تبریز', 'اهواز', 'کرج', 'قم',
    'رشت', 'کرمان', 'یزد', 'ارومیه', 'همدان', 'کرمانشاه', 'زاهدان'
  ];

  const categories = [
    'سانترال دیجیتال', 'سیستم VoIP', 'شبکه تلفن', 'مرکز تماس',
    'سیستم اعلام حریق', 'دوربین مداربسته', 'سیستم صوتی', 'شبکه کامپیوتری'
  ];

  const projects = [];
  for (let i = 0; i < count; i++) {
    const client = clients[i % clients.length];
    const location = locations[i % locations.length];
    const category = categories[i % categories.length];
    const year = 1398 + Math.floor(i / 10);
    
    projects.push({
      id: `project-${i + 1}`,
      title: `پروژه ${client}`,
      client: client,
      location: location,
      date: `سال ${year}`,
      category: category,
      image: `https://images.unsplash.com/photo-${1500000000000 + i * 100000}?w=800&h=600&fit=crop`,
      description: `نصب و راه‌اندازی ${category} برای ${client} در ${location}. این پروژه شامل طراحی، نصب، تست و راه‌اندازی کامل سیستم می‌باشد.`
    });
  }
  
  return projects;
};

export const projectsData = generateProjects(50);
