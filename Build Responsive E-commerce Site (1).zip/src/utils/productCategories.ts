// Product category navigation structure
export interface CategoryItem {
  id: string;
  label: string;
  children?: CategoryItem[];
  isEndpoint?: boolean;
}

export const productCategories: CategoryItem[] = [
  {
    id: 'telecom',
    label: 'مخابرات',
    children: [
      {
        id: 'phone',
        label: 'تلفن',
        children: [
          { id: 'phone-desk', label: 'تلفن رومیزی', isEndpoint: true },
          { id: 'phone-wireless', label: 'تلفن بی سیم', isEndpoint: true },
          { id: 'phone-pbx', label: 'تلفن سانترال', isEndpoint: true },
          { id: 'phone-network', label: 'تلفن شبکه', isEndpoint: true },
          { id: 'phone-tower', label: 'تلفن دکل', isEndpoint: true },
          { id: 'phone-explosion', label: 'تلفن ضد انفجار', isEndpoint: true },
          { id: 'phone-kiosk', label: 'کیوسک ضد انفجار', isEndpoint: true },
          { id: 'phone-accessories', label: 'تجهیزات جانبی', isEndpoint: true },
        ],
      },
      {
        id: 'pbx',
        label: 'مرکز تلفن',
        children: [
          { id: 'pbx-low', label: 'سانترال کم ظرفیت', isEndpoint: true },
          { id: 'pbx-high', label: 'سانترال پر ظرفیت', isEndpoint: true },
          { id: 'pbx-voip', label: 'سانترال تحت شبکه (VOIP)', isEndpoint: true },
          { id: 'pbx-fxo-fxs', label: 'FXO & FXS', isEndpoint: true },
          { id: 'pbx-internal', label: 'کارت خطوط داخلی', isEndpoint: true },
          { id: 'pbx-external', label: 'کارت خطوط شهری', isEndpoint: true },
          { id: 'pbx-side-cards', label: 'کارت های جانبی', isEndpoint: true },
          { id: 'pbx-equipment', label: 'تجهیزات و لوازم جانبی', isEndpoint: true },
          { id: 'pbx-license', label: 'لایسنس مراکز', isEndpoint: true },
        ],
      },
      {
        id: 'mdf',
        label: 'تجهیزات MDF',
        children: [
          { id: 'mdf-terminal', label: 'ترمینال و تجهیزات جانبی', isEndpoint: true },
          { id: 'mdf-wire', label: 'سیم رانژه', isEndpoint: true },
          { id: 'mdf-rack', label: 'راک MDF,DDF', isEndpoint: true },
          { id: 'mdf-box', label: 'کافو و باکس های مخابراتی', isEndpoint: true },
          { id: 'mdf-ladder', label: 'لدر واتصالات', isEndpoint: true },
          { id: 'mdf-joint', label: 'مفصل مخابراتی', isEndpoint: true },
          { id: 'mdf-connector', label: 'کانکتور وتجهیزات جانبی', isEndpoint: true },
        ],
      },
      {
        id: 'fiber',
        label: 'تجهیزات فیبر نوری',
        children: [
          { id: 'fiber-cable', label: 'کابل فیبر نوری', isEndpoint: true },
          { id: 'fiber-rack', label: 'راک های فیبر نوری', isEndpoint: true },
          { id: 'fiber-accessories', label: 'متعلقات فیبر نوری', isEndpoint: true },
          { id: 'fiber-patch', label: 'پچ پنل فیبر نوری', isEndpoint: true },
          { id: 'fiber-box', label: 'کافو و باکس های فیبر نوری', isEndpoint: true },
          { id: 'fiber-joint', label: 'مفصل و یراق آلات فیبرنوری', isEndpoint: true },
        ],
      },
      {
        id: 'copper-cable',
        label: 'کابل های مخابرات مسی',
        children: [
          { id: 'copper-jelly-underground', label: 'کابل ژله فیلد خاکی', isEndpoint: true },
          { id: 'copper-jelly-channel', label: 'کابل ژله فیلد کانالی', isEndpoint: true },
          { id: 'copper-aerial', label: 'کابل هوایی مهاردار', isEndpoint: true },
          { id: 'copper-indoor', label: 'کابل مخابراتی Indoor', isEndpoint: true },
          { id: 'copper-outdoor', label: 'کابل مخابراتی Outdoor', isEndpoint: true },
        ],
      },
      {
        id: 'radio-max',
        label: 'رادیو و ماکس',
        children: [
          { id: 'radio-equipment', label: 'تجهیزات رادیویی', isEndpoint: true },
          { id: 'radio-antenna', label: 'آنتن های رادیویی', isEndpoint: true },
          { id: 'radio-accessories', label: 'متعلقات رادیو', isEndpoint: true },
          { id: 'radio-wireless', label: 'تجهیزات بی سیم', isEndpoint: true },
        ],
      },
      {
        id: 'systems',
        label: 'سامانه ها',
        children: [
          { id: 'systems-recording', label: 'سیستم های ضبط مکالمه', isEndpoint: true },
          { id: 'systems-queue', label: 'سیستم صف انتظار', isEndpoint: true },
          { id: 'systems-ivr', label: 'سیستم IVR', isEndpoint: true },
          { id: 'systems-paging', label: 'سیستم پیجینگ', isEndpoint: true },
        ],
      },
      {
        id: 'grounding',
        label: 'ارتینگ',
        children: [
          { id: 'grounding-rod', label: 'میله ارت', isEndpoint: true },
          { id: 'grounding-cable', label: 'کابل ارت', isEndpoint: true },
          { id: 'grounding-clamp', label: 'گیره ارت', isEndpoint: true },
          { id: 'grounding-accessories', label: 'متعلقات ارتینگ', isEndpoint: true },
        ],
      },
      {
        id: 'tower-lightning',
        label: 'دکل و صاعقه گیر',
        children: [
          { id: 'tower-types', label: 'انواع دکل', isEndpoint: true },
          { id: 'tower-lightning-rod', label: 'صاعقه گیر', isEndpoint: true },
          { id: 'tower-accessories', label: 'متعلقات دکل', isEndpoint: true },
          { id: 'tower-installation', label: 'تجهیزات نصب', isEndpoint: true },
        ],
      },
      {
        id: 'tools',
        label: 'ابزار و تستر ها',
        children: [
          { id: 'tools-tester', label: 'تستر های مخابراتی', isEndpoint: true },
          { id: 'tools-fiber', label: 'ابزار فیبر نوری', isEndpoint: true },
          { id: 'tools-cable', label: 'ابزار کابل کشی', isEndpoint: true },
          { id: 'tools-measuring', label: 'تجهیزات اندازه گیری', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'network',
    label: 'شبکه',
    children: [
      {
        id: 'network-switch',
        label: 'سوئیچ',
        children: [
          { id: 'network-switch-managed', label: 'سوئیچ مدیریت شده', isEndpoint: true },
          { id: 'network-switch-unmanaged', label: 'سوئیچ مدیریت نشده', isEndpoint: true },
          { id: 'network-switch-poe', label: 'سوئیچ POE', isEndpoint: true },
          { id: 'network-switch-industrial', label: 'سوئیچ صنعتی', isEndpoint: true },
        ],
      },
      {
        id: 'network-router',
        label: 'روتر',
        children: [
          { id: 'network-router-home', label: 'روتر خانگی', isEndpoint: true },
          { id: 'network-router-enterprise', label: 'روتر سازمانی', isEndpoint: true },
          { id: 'network-router-wireless', label: 'روتر بی سیم', isEndpoint: true },
          { id: 'network-router-4g', label: 'روتر 4G/5G', isEndpoint: true },
        ],
      },
      {
        id: 'network-cable',
        label: 'کابل شبکه',
        children: [
          { id: 'network-cable-cat5', label: 'کابل Cat5e', isEndpoint: true },
          { id: 'network-cable-cat6', label: 'کابل Cat6', isEndpoint: true },
          { id: 'network-cable-cat6a', label: 'کابل Cat6a', isEndpoint: true },
          { id: 'network-cable-cat7', label: 'کابل Cat7', isEndpoint: true },
        ],
      },
      {
        id: 'network-accessories',
        label: 'متعلقات شبکه',
        children: [
          { id: 'network-acc-patch', label: 'پچ پنل', isEndpoint: true },
          { id: 'network-acc-rack', label: 'راک شبکه', isEndpoint: true },
          { id: 'network-acc-connector', label: 'کانکتور و سوکت', isEndpoint: true },
          { id: 'network-acc-tools', label: 'ابزار شبکه', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'audio',
    label: 'صوت',
    children: [
      {
        id: 'audio-speaker',
        label: 'بلندگو',
        children: [
          { id: 'audio-speaker-ceiling', label: 'بلندگوی سقفی', isEndpoint: true },
          { id: 'audio-speaker-wall', label: 'بلندگوی دیواری', isEndpoint: true },
          { id: 'audio-speaker-horn', label: 'بلندگوی هورنی', isEndpoint: true },
          { id: 'audio-speaker-column', label: 'بلندگوی ستونی', isEndpoint: true },
        ],
      },
      {
        id: 'audio-amplifier',
        label: 'آمپلی فایر',
        children: [
          { id: 'audio-amp-mixer', label: 'میکسر آمپلی فایر', isEndpoint: true },
          { id: 'audio-amp-power', label: 'آمپلی فایر قدرت', isEndpoint: true },
          { id: 'audio-amp-zone', label: 'آمپلی فایر چند زونه', isEndpoint: true },
        ],
      },
      {
        id: 'audio-mic',
        label: 'میکروفون',
        children: [
          { id: 'audio-mic-wireless', label: 'میکروفون بی سیم', isEndpoint: true },
          { id: 'audio-mic-wired', label: 'میکروفون سیمی', isEndpoint: true },
          { id: 'audio-mic-conference', label: 'میکروفون کنفرانس', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'camera',
    label: 'دوربین',
    children: [
      {
        id: 'camera-analog',
        label: 'دوربین آنالوگ',
        children: [
          { id: 'camera-analog-ahd', label: 'دوربین AHD', isEndpoint: true },
          { id: 'camera-analog-tvi', label: 'دوربین TVI', isEndpoint: true },
          { id: 'camera-analog-cvi', label: 'دوربین CVI', isEndpoint: true },
        ],
      },
      {
        id: 'camera-ip',
        label: 'دوربین IP',
        children: [
          { id: 'camera-ip-bullet', label: 'دوربین بولت', isEndpoint: true },
          { id: 'camera-ip-dome', label: 'دوربین دام', isEndpoint: true },
          { id: 'camera-ip-ptz', label: 'دوربین PTZ', isEndpoint: true },
          { id: 'camera-ip-fisheye', label: 'دوربین فیش آی', isEndpoint: true },
        ],
      },
      {
        id: 'camera-dvr',
        label: 'دستگاه ضبط',
        children: [
          { id: 'camera-dvr-analog', label: 'DVR آنالوگ', isEndpoint: true },
          { id: 'camera-dvr-nvr', label: 'NVR تحت شبکه', isEndpoint: true },
          { id: 'camera-dvr-hybrid', label: 'دستگاه هیبرید', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'power',
    label: 'منابع تغذیه',
    children: [
      {
        id: 'power-ups',
        label: 'UPS',
        children: [
          { id: 'power-ups-online', label: 'UPS آنلاین', isEndpoint: true },
          { id: 'power-ups-offline', label: 'UPS آفلاین', isEndpoint: true },
          { id: 'power-ups-line', label: 'UPS Line Interactive', isEndpoint: true },
        ],
      },
      {
        id: 'power-adapter',
        label: 'آداپتور',
        children: [
          { id: 'power-adapter-12v', label: 'آداپتور 12 ولت', isEndpoint: true },
          { id: 'power-adapter-24v', label: 'آداپتور 24 ولت', isEndpoint: true },
          { id: 'power-adapter-48v', label: 'آداپتور 48 ولت', isEndpoint: true },
        ],
      },
      {
        id: 'power-battery',
        label: 'باتری',
        children: [
          { id: 'power-battery-sealed', label: 'باتری سیلد اسید', isEndpoint: true },
          { id: 'power-battery-lithium', label: 'باتری لیتیوم', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'video',
    label: 'تصویر',
    children: [
      {
        id: 'video-display',
        label: 'نمایشگر',
        children: [
          { id: 'video-display-led', label: 'نمایشگر LED', isEndpoint: true },
          { id: 'video-display-lcd', label: 'نمایشگر LCD', isEndpoint: true },
          { id: 'video-display-video-wall', label: 'ویدئو وال', isEndpoint: true },
        ],
      },
      {
        id: 'video-projector',
        label: 'پروژکتور',
        children: [
          { id: 'video-projector-short', label: 'پروژکتور فاصله کوتاه', isEndpoint: true },
          { id: 'video-projector-long', label: 'پروژکتور فاصله بلند', isEndpoint: true },
          { id: 'video-projector-interactive', label: 'پروژکتور تعاملی', isEndpoint: true },
        ],
      },
      {
        id: 'video-conference',
        label: 'ویدئو کنفرانس',
        children: [
          { id: 'video-conference-system', label: 'سیستم ویدئو کنفرانس', isEndpoint: true },
          { id: 'video-conference-camera', label: 'دوربین کنفرانس', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'office',
    label: 'ماشین های اداری',
    children: [
      {
        id: 'office-printer',
        label: 'چاپگر',
        children: [
          { id: 'office-printer-laser', label: 'چاپگر لیزری', isEndpoint: true },
          { id: 'office-printer-inkjet', label: 'چاپگر جوهر افشان', isEndpoint: true },
          { id: 'office-printer-multi', label: 'چاپگر چندکاره', isEndpoint: true },
        ],
      },
      {
        id: 'office-scanner',
        label: 'اسکنر',
        children: [
          { id: 'office-scanner-flatbed', label: 'اسکنر تخت', isEndpoint: true },
          { id: 'office-scanner-sheet', label: 'اسکنر اسناد', isEndpoint: true },
        ],
      },
      {
        id: 'office-shredder',
        label: 'کاغذ خردکن',
        children: [
          { id: 'office-shredder-strip', label: 'خردکن نواری', isEndpoint: true },
          { id: 'office-shredder-cross', label: 'خردکن متقاطع', isEndpoint: true },
        ],
      },
    ],
  },
  {
    id: 'alarm',
    label: 'سیستم های هشدار دهنده',
    children: [
      {
        id: 'alarm-fire',
        label: 'اعلام حریق',
        children: [
          { id: 'alarm-fire-panel', label: 'پنل اعلام حریق', isEndpoint: true },
          { id: 'alarm-fire-detector', label: 'دتکتور دود', isEndpoint: true },
          { id: 'alarm-fire-heat', label: 'دتکتور حرارت', isEndpoint: true },
          { id: 'alarm-fire-manual', label: 'دکمه دستی', isEndpoint: true },
        ],
      },
      {
        id: 'alarm-security',
        label: 'دزدگیر',
        children: [
          { id: 'alarm-security-panel', label: 'پنل دزدگیر', isEndpoint: true },
          { id: 'alarm-security-motion', label: 'سنسور حرکتی', isEndpoint: true },
          { id: 'alarm-security-door', label: 'سنسور درب و پنجره', isEndpoint: true },
          { id: 'alarm-security-siren', label: 'آژیر هشدار', isEndpoint: true },
        ],
      },
      {
        id: 'alarm-gas',
        label: 'اعلام گاز',
        children: [
          { id: 'alarm-gas-detector', label: 'دتکتور گاز', isEndpoint: true },
          { id: 'alarm-gas-valve', label: 'شیر برقی گاز', isEndpoint: true },
        ],
      },
    ],
  },
];

// Helper function to find a category by ID
export function findCategoryById(
  categories: CategoryItem[],
  id: string
): CategoryItem | null {
  for (const category of categories) {
    if (category.id === id) {
      return category;
    }
    if (category.children) {
      const found = findCategoryById(category.children, id);
      if (found) return found;
    }
  }
  return null;
}

// Helper function to get breadcrumb path
export function getBreadcrumbPath(
  categories: CategoryItem[],
  targetId: string,
  path: CategoryItem[] = []
): CategoryItem[] | null {
  for (const category of categories) {
    const newPath = [...path, category];
    if (category.id === targetId) {
      return newPath;
    }
    if (category.children) {
      const found = getBreadcrumbPath(category.children, targetId, newPath);
      if (found) return found;
    }
  }
  return null;
}
