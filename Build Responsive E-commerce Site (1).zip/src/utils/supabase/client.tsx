import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from './info'

export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
)

// API base URL
export const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-29ea8665`

// Helper function to make API calls
export const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  const url = `${API_BASE_URL}${endpoint}`
  
  const defaultHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
  }

  // If user is authenticated, use their access token
  const { data: { session } } = await supabase.auth.getSession()
  if (session?.access_token) {
    defaultHeaders.Authorization = `Bearer ${session.access_token}`
  }

  const response = await fetch(url, {
    ...options,
    headers: {
      ...defaultHeaders,
      ...options.headers,
    },
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Network error' }))
    throw new Error(errorData.error || `HTTP ${response.status}`)
  }

  return response.json()
}

// Auth functions
export const authService = {
  async signUp(userData: {
    firstName: string
    lastName: string
    email: string
    phone: string
    password: string
  }) {
    return apiCall('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(userData),
    })
  },

  async signIn(email: string, password: string) {
    const response = await apiCall('/auth/signin', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    })
    
    // Update Supabase session
    if (response.session) {
      await supabase.auth.setSession(response.session)
    }
    
    return response
  },

  async signOut() {
    await supabase.auth.signOut()
  },

  async getProfile() {
    return apiCall('/user/profile')
  }
}

// Product functions
export const productService = {
  async getProducts(params: {
    category?: string
    search?: string
    sortBy?: string
    page?: number
    limit?: number
  } = {}) {
    const queryParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value) queryParams.append(key, value.toString())
    })
    
    return apiCall(`/products?${queryParams}`)
  },

  async getProduct(id: string) {
    return apiCall(`/products/${id}`)
  },

  async createProduct(productData: any) {
    return apiCall('/products', {
      method: 'POST',
      body: JSON.stringify(productData),
    })
  }
}

// Cart functions
export const cartService = {
  async getCart() {
    return apiCall('/cart')
  },

  async addToCart(productId: string, quantity: number = 1) {
    return apiCall('/cart/add', {
      method: 'POST',
      body: JSON.stringify({ productId, quantity }),
    })
  }
}

// Order functions
export const orderService = {
  async createOrder(orderData: any) {
    return apiCall('/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    })
  },

  async getOrders() {
    return apiCall('/orders')
  }
}

// Article functions
export const articleService = {
  async getArticles(params: {
    search?: string
    tag?: string
    page?: number
    limit?: number
  } = {}) {
    const queryParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value) queryParams.append(key, value.toString())
    })
    
    return apiCall(`/articles?${queryParams}`)
  },

  async getArticle(id: string) {
    return apiCall(`/articles/${id}`)
  },

  async createArticle(articleData: any) {
    return apiCall('/articles', {
      method: 'POST',
      body: JSON.stringify(articleData),
    })
  },

  async likeArticle(id: string) {
    return apiCall(`/articles/${id}/like`, {
      method: 'POST',
    })
  }
}

// Admin functions
export const adminService = {
  async getStats() {
    return apiCall('/admin/stats')
  }
}

// Utility function to seed initial data
export const seedData = async () => {
  return apiCall('/seed', { method: 'POST' })
}