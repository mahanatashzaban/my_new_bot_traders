// Generate 1000 articles for the website
export const generateArticles = (count: number = 1000) => {
  const titles = [
    'راهنمای خرید سانترال تلفنی',
    'مزایای استفاده از سیستم VoIP',
    'نحوه نصب مرکز تلفن دیجیتال',
    'بررسی برندهای معتبر سانترال',
    'آشنایی با تلفن‌های IP',
    'راهکارهای کاهش هزینه تماس',
    'سیستم‌های تلفنی ابری',
    'مقایسه سانترال دیجیتال و آنالوگ',
    'پیکربندی مرکز تماس',
    'ویژگی‌های تلفن‌های تحت شبکه',
    'نگهداری و سرویس سانترال',
    'امنیت در سیستم‌های VoIP',
    'آموزش راه‌اندازی سانترال',
    'اتصال سانترال به شبکه',
    'مشکلات رایج سیستم‌های تلفنی',
    'بهینه‌سازی کیفیت صدا',
    'انتخاب هدست مناسب',
    'راهنمای خرید کابل شبکه',
    'سیستم‌های پیام‌گیر',
    'مدیریت تماس‌های ورودی'
  ];

  const authors = [
    'احمد محمدی', 'مهندس رضایی', 'دکتر کریمی', 'سارا احمدی',
    'علی نوری', 'فاطمه حسینی', 'مهندس علوی', 'حسین صادقی'
  ];

  const tags = [
    ['سانترال', 'تلفن', 'دیجیتال'],
    ['VoIP', 'شبکه', 'اینترنت'],
    ['نصب', 'راه‌اندازی', 'آموزش'],
    ['مرکز تماس', 'CRM', 'مدیریت'],
    ['امنیت', 'رمزنگاری', 'حفاظت'],
    ['بهینه‌سازی', 'کیفیت', 'صدا'],
    ['لوازم جانبی', 'هدست', 'کابل'],
    ['پشتیبانی', 'نگهداری', 'تعمیر']
  ];

  const excerpts = [
    'در این مقاله به بررسی نکات کلیدی و مهم در انتخاب و خرید تجهیزات تلفنی می‌پردازیم.',
    'سیستم‌های تلفنی مدرن امکانات فراوانی را برای کسب و کارها فراهم می‌کنند.',
    'با مطالعه این راهنما می‌توانید بهترین تصمیم را برای سازمان خود بگیرید.',
    'یادگیری نکات فنی و تخصصی می‌تواند به شما در بهره‌برداری بهتر کمک کند.',
    'در این مطلب تجربیات عملی و کاربردی را با شما به اشتراک می‌گذاریم.',
    'راهکارهای موثر و کاربردی برای بهبود عملکرد سیستم‌های ارتباطی شما.',
    'آشنایی با آخرین تکنولوژی‌ها و نوآوری‌ها در صنعت تلفن و ارتباطات.',
    'نکات مهم و کلیدی که باید قبل از تصمیم‌گیری بدانید.'
  ];

  const articles = [];
  for (let i = 0; i < count; i++) {
    const titleIndex = i % titles.length;
    const title = `${titles[titleIndex]} ${i > titles.length ? `- قسمت ${Math.floor(i / titles.length) + 1}` : ''}`;
    const author = authors[i % authors.length];
    const tagSet = tags[i % tags.length];
    const excerpt = excerpts[i % excerpts.length];
    
    // Calculate dates for the last 2 years
    const daysAgo = Math.floor(i / 2);
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    const persianDate = `${date.getDate()} ${['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'][date.getMonth()]} ${1400 + Math.floor(daysAgo / 365)}`;
    
    articles.push({
      id: `article-${i + 1}`,
      title: title,
      excerpt: excerpt,
      image: `https://images.unsplash.com/photo-${1560000000000 + (i * 17000)}?w=800&h=500&fit=crop`,
      author: author,
      publishDate: persianDate,
      readTime: 3 + (i % 10),
      tags: tagSet,
      likes: Math.floor(Math.random() * 500) + 50,
      comments: Math.floor(Math.random() * 100) + 10,
      views: Math.floor(Math.random() * 5000) + 500,
      isLiked: false
    });
  }
  
  return articles;
};

export const articlesData = generateArticles(1000);
