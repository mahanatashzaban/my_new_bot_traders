import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

// CORS configuration
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}))

app.use('*', logger(console.log))

// Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Initialize storage buckets
const initializeStorage = async () => {
  try {
    const { data: buckets } = await supabase.storage.listBuckets()
    
    const bucketNames = ['make-29ea8665-products', 'make-29ea8665-articles']
    
    for (const bucketName of bucketNames) {
      const bucketExists = buckets?.some(bucket => bucket.name === bucketName)
      if (!bucketExists) {
        const { error } = await supabase.storage.createBucket(bucketName, {
          public: false,
          allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
          fileSizeLimit: 5 * 1024 * 1024 // 5MB
        })
        if (error) {
          console.log(`Error creating bucket ${bucketName}:`, error)
        } else {
          console.log(`Created bucket: ${bucketName}`)
        }
      }
    }
  } catch (error) {
    console.log('Storage initialization error:', error)
  }
}

// Initialize storage on startup
initializeStorage()

// Auth Routes
app.post('/make-server-29ea8665/auth/signup', async (c) => {
  try {
    const { firstName, lastName, email, phone, password } = await c.req.json()
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        firstName, 
        lastName, 
        phone,
        memberSince: new Date().toISOString()
      },
      email_confirm: true // Auto-confirm since email server not configured
    })

    if (error) {
      console.log('Signup error:', error)
      return c.json({ error: `خطا در ثبت نام: ${error.message}` }, 400)
    }

    // Save user profile
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      firstName,
      lastName,
      email,
      phone,
      memberSince: new Date().toISOString(),
      role: 'user'
    })

    return c.json({ 
      message: 'حساب کاربری با موفقیت ایجاد شد',
      user: data.user 
    })
  } catch (error) {
    console.log('Signup error:', error)
    return c.json({ error: 'خطا در ثبت نام کاربر' }, 500)
  }
})

app.post('/make-server-29ea8665/auth/signin', async (c) => {
  try {
    const { email, password } = await c.req.json()
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
    )

    const { data, error } = await supabaseClient.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      console.log('Signin error:', error)
      return c.json({ error: `خطا در ورود: ${error.message}` }, 400)
    }

    // Get user profile
    const userProfile = await kv.get(`user:${data.user.id}`)
    
    return c.json({ 
      message: 'با موفقیت وارد شدید',
      session: data.session,
      user: userProfile
    })
  } catch (error) {
    console.log('Signin error:', error)
    return c.json({ error: 'خطا در ورود کاربر' }, 500)
  }
})

// User Profile Routes
app.get('/make-server-29ea8665/user/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    const profile = await kv.get(`user:${user.id}`)
    return c.json({ profile })
  } catch (error) {
    console.log('Get profile error:', error)
    return c.json({ error: 'خطا در دریافت پروفایل کاربر' }, 500)
  }
})

// Product Routes
app.get('/make-server-29ea8665/products', async (c) => {
  try {
    const category = c.req.query('category')
    const search = c.req.query('search')
    const sortBy = c.req.query('sortBy') || 'newest'
    const page = parseInt(c.req.query('page') || '1')
    const limit = parseInt(c.req.query('limit') || '20')

    let products = await kv.getByPrefix('product:')
    
    // Filter by category
    if (category && category !== 'all') {
      products = products.filter(p => p.category === category)
    }
    
    // Search
    if (search) {
      products = products.filter(p => 
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        p.description?.toLowerCase().includes(search.toLowerCase())
      )
    }
    
    // Sort
    switch (sortBy) {
      case 'price_low':
        products.sort((a, b) => a.price - b.price)
        break
      case 'price_high':
        products.sort((a, b) => b.price - a.price)
        break
      case 'popular':
        products.sort((a, b) => (b.rating || 0) - (a.rating || 0))
        break
      default:
        products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    }
    
    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedProducts = products.slice(startIndex, endIndex)
    
    return c.json({
      products: paginatedProducts,
      total: products.length,
      page,
      limit,
      totalPages: Math.ceil(products.length / limit)
    })
  } catch (error) {
    console.log('Get products error:', error)
    return c.json({ error: 'خطا در دریافت محصولات' }, 500)
  }
})

app.get('/make-server-29ea8665/products/:id', async (c) => {
  try {
    const id = c.req.param('id')
    const product = await kv.get(`product:${id}`)
    
    if (!product) {
      return c.json({ error: 'محصول یافت نشد' }, 404)
    }
    
    return c.json({ product })
  } catch (error) {
    console.log('Get product error:', error)
    return c.json({ error: 'خطا در دریافت محصول' }, 500)
  }
})

app.post('/make-server-29ea8665/products', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    // Check if user is admin
    const userProfile = await kv.get(`user:${user.id}`)
    if (!userProfile || userProfile.role !== 'admin') {
      return c.json({ error: 'دسترسی غیرمجاز' }, 403)
    }

    const productData = await c.req.json()
    const productId = crypto.randomUUID()
    
    const product = {
      id: productId,
      ...productData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`product:${productId}`, product)
    
    return c.json({ 
      message: 'محصول با موفقیت اضافه شد',
      product 
    })
  } catch (error) {
    console.log('Create product error:', error)
    return c.json({ error: 'خطا در ایجاد محصول' }, 500)
  }
})

// Shopping Cart Routes
app.get('/make-server-29ea8665/cart', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    const cart = await kv.get(`cart:${user.id}`) || { items: [] }
    return c.json({ cart })
  } catch (error) {
    console.log('Get cart error:', error)
    return c.json({ error: 'خطا در دریافت سبد خرید' }, 500)
  }
})

app.post('/make-server-29ea8665/cart/add', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    const { productId, quantity = 1 } = await c.req.json()
    
    // Get product details
    const product = await kv.get(`product:${productId}`)
    if (!product) {
      return c.json({ error: 'محصول یافت نشد' }, 404)
    }
    
    // Get current cart
    let cart = await kv.get(`cart:${user.id}`) || { items: [] }
    
    // Check if product already in cart
    const existingItemIndex = cart.items.findIndex(item => item.productId === productId)
    
    if (existingItemIndex >= 0) {
      cart.items[existingItemIndex].quantity += quantity
    } else {
      cart.items.push({
        productId,
        quantity,
        addedAt: new Date().toISOString()
      })
    }
    
    cart.updatedAt = new Date().toISOString()
    await kv.set(`cart:${user.id}`, cart)
    
    return c.json({ 
      message: 'محصول به سبد خرید اضافه شد',
      cart 
    })
  } catch (error) {
    console.log('Add to cart error:', error)
    return c.json({ error: 'خطا در افزودن به سبد خرید' }, 500)
  }
})

// Order Routes
app.post('/make-server-29ea8665/orders', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    const orderData = await c.req.json()
    const orderId = crypto.randomUUID()
    
    // Get cart
    const cart = await kv.get(`cart:${user.id}`)
    if (!cart || !cart.items || cart.items.length === 0) {
      return c.json({ error: 'سبد خرید خالی است' }, 400)
    }
    
    // Calculate total
    let total = 0
    const orderItems = []
    
    for (const cartItem of cart.items) {
      const product = await kv.get(`product:${cartItem.productId}`)
      if (product) {
        const itemTotal = product.price * cartItem.quantity
        total += itemTotal
        orderItems.push({
          productId: cartItem.productId,
          title: product.title,
          price: product.price,
          quantity: cartItem.quantity,
          total: itemTotal
        })
      }
    }
    
    const order = {
      id: orderId,
      userId: user.id,
      items: orderItems,
      total,
      status: 'pending',
      ...orderData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`order:${orderId}`, order)
    
    // Clear cart
    await kv.set(`cart:${user.id}`, { items: [] })
    
    return c.json({ 
      message: 'سفارش با موفقیت ثبت شد',
      order 
    })
  } catch (error) {
    console.log('Create order error:', error)
    return c.json({ error: 'خطا در ثبت سفارش' }, 500)
  }
})

app.get('/make-server-29ea8665/orders', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    const allOrders = await kv.getByPrefix('order:')
    const userOrders = allOrders.filter(order => order.userId === user.id)
    
    // Sort by creation date (newest first)
    userOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    
    return c.json({ orders: userOrders })
  } catch (error) {
    console.log('Get orders error:', error)
    return c.json({ error: 'خطا در دریافت سفارشات' }, 500)
  }
})

// Article Routes
app.get('/make-server-29ea8665/articles', async (c) => {
  try {
    const page = parseInt(c.req.query('page') || '1')
    const limit = parseInt(c.req.query('limit') || '10')
    const search = c.req.query('search')
    const tag = c.req.query('tag')

    let articles = await kv.getByPrefix('article:')
    
    // Filter published articles only (unless admin)
    articles = articles.filter(article => article.status === 'published')
    
    // Search
    if (search) {
      articles = articles.filter(article => 
        article.title.toLowerCase().includes(search.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(search.toLowerCase())
      )
    }
    
    // Filter by tag
    if (tag) {
      articles = articles.filter(article => 
        article.tags && article.tags.includes(tag)
      )
    }
    
    // Sort by publication date (newest first)
    articles.sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime())
    
    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedArticles = articles.slice(startIndex, endIndex)
    
    return c.json({
      articles: paginatedArticles,
      total: articles.length,
      page,
      limit,
      totalPages: Math.ceil(articles.length / limit)
    })
  } catch (error) {
    console.log('Get articles error:', error)
    return c.json({ error: 'خطا در دریافت مقالات' }, 500)
  }
})

app.get('/make-server-29ea8665/articles/:id', async (c) => {
  try {
    const id = c.req.param('id')
    const article = await kv.get(`article:${id}`)
    
    if (!article) {
      return c.json({ error: 'مقاله یافت نشد' }, 404)
    }
    
    // Increment view count
    article.views = (article.views || 0) + 1
    await kv.set(`article:${id}`, article)
    
    return c.json({ article })
  } catch (error) {
    console.log('Get article error:', error)
    return c.json({ error: 'خطا در دریافت مقاله' }, 500)
  }
})

app.post('/make-server-29ea8665/articles', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    // Check if user is admin
    const userProfile = await kv.get(`user:${user.id}`)
    if (!userProfile || userProfile.role !== 'admin') {
      return c.json({ error: 'دسترسی غیرمجاز' }, 403)
    }

    const articleData = await c.req.json()
    const articleId = crypto.randomUUID()
    
    const article = {
      id: articleId,
      ...articleData,
      author: `${userProfile.firstName} ${userProfile.lastName}`,
      authorId: user.id,
      likes: 0,
      comments: 0,
      views: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`article:${articleId}`, article)
    
    return c.json({ 
      message: 'مقاله با موفقیت ایجاد شد',
      article 
    })
  } catch (error) {
    console.log('Create article error:', error)
    return c.json({ error: 'خطا در ایجاد مقاله' }, 500)
  }
})

// Like Article
app.post('/make-server-29ea8665/articles/:id/like', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    const articleId = c.req.param('id')
    const article = await kv.get(`article:${articleId}`)
    
    if (!article) {
      return c.json({ error: 'مقاله یافت نشد' }, 404)
    }
    
    // Check if user already liked
    const likeKey = `like:${articleId}:${user.id}`
    const existingLike = await kv.get(likeKey)
    
    if (existingLike) {
      // Unlike
      await kv.del(likeKey)
      article.likes = Math.max(0, (article.likes || 0) - 1)
      await kv.set(`article:${articleId}`, article)
      return c.json({ message: 'لایک حذف شد', liked: false, likes: article.likes })
    } else {
      // Like
      await kv.set(likeKey, { articleId, userId: user.id, createdAt: new Date().toISOString() })
      article.likes = (article.likes || 0) + 1
      await kv.set(`article:${articleId}`, article)
      return c.json({ message: 'مقاله پسندیده شد', liked: true, likes: article.likes })
    }
  } catch (error) {
    console.log('Like article error:', error)
    return c.json({ error: 'خطا در پسندیدن مقاله' }, 500)
  }
})

// Admin Routes
app.get('/make-server-29ea8665/admin/stats', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'توکن احراز هویت ارسال نشده' }, 401)
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    if (error || !user) {
      return c.json({ error: 'کاربر معتبر نیست' }, 401)
    }

    // Check if user is admin
    const userProfile = await kv.get(`user:${user.id}`)
    if (!userProfile || userProfile.role !== 'admin') {
      return c.json({ error: 'دسترسی غیرمجاز' }, 403)
    }

    const products = await kv.getByPrefix('product:')
    const users = await kv.getByPrefix('user:')
    const orders = await kv.getByPrefix('order:')
    const articles = await kv.getByPrefix('article:')
    
    const totalRevenue = orders.reduce((sum, order) => sum + (order.total || 0), 0)
    
    const stats = {
      totalProducts: products.length,
      totalUsers: users.length,
      totalOrders: orders.length,
      totalArticles: articles.length,
      totalRevenue,
      recentOrders: orders
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5)
    }
    
    return c.json({ stats })
  } catch (error) {
    console.log('Get admin stats error:', error)
    return c.json({ error: 'خطا در دریافت آمار' }, 500)
  }
})

// Seed initial data
app.post('/make-server-29ea8665/seed', async (c) => {
  try {
    // Check if data already exists
    const existingProducts = await kv.getByPrefix('product:')
    if (existingProducts.length > 0) {
      return c.json({ message: 'داده‌ها قبلاً ایجاد شده‌اند' })
    }

    // Create admin user
    const adminUserId = 'admin-user-id'
    await kv.set(`user:${adminUserId}`, {
      id: adminUserId,
      firstName: 'مدیر',
      lastName: 'تله‌کام سنتر',
      email: 'admin@telecomcenter.com',
      phone: '۰۹۱۲۳۴۵۶۷۸۹',
      memberSince: new Date().toISOString(),
      role: 'admin'
    })

    // Seed 20 phone center products
    const phoneSystemsProducts = [
      'سیستم تلفنی پاناسونیک KX-TGF370', 'سنترال پاناسونیک KX-TDA100', 'تلفن آی پی زیمنز OpenStage 60',
      'سیستم VoIP Cisco SPA525G2', 'تلفن بی‌سیم پاناسونیک KX-TG6821', 'سنترال زیمنز HiPath 3300',
      'تلفن آی پی یالینک T46U', 'سیستم کنفرانس پاناسونیک KX-HDV330', 'سنترال آوایا IP Office 500',
      'تلفن VoIP گرنداستریم GXP2170', 'سیستم PBX پاناسونیک KX-NS500', 'تلفن زیمنز OptiPoint 420',
      'سنترال NEC SL2100', 'تلفن بی‌سیم یالینک W52P', 'سیستم DECT پاناسونیک KX-TDA30',
      'تلفن آی پی فن ویل X6U', 'سنترال دیجیتال پاناسونیک KX-TDE100', 'سیستم VoIP سیسکو 7841',
      'تلفن کنفرانس یالینک CP930', 'سنترال آنالوگ پاناسونیک KX-TES824'
    ]

    const accessories = [
      'هدست تلفنی پلنترونیکز', 'آداپتور PoE سیسکو', 'کابل شبکه Cat6', 'سوئیچ شبکه ۸ پورت',
      'باتری یوپی‌اس تلفنی', 'میکروفون کنفرانس', 'اسپیکر تلفنی بلوتوثی', 'نگهدارنده گوشی تلفن',
      'کارت خط تلفن', 'ماژول افزونه سنترال', 'کابل تلفن RJ11', 'آنتن بی‌سیم تلفن',
      'شارژر تلفن بی‌سیم', 'فیلتر خط تلفن', 'تقسیم‌کننده خط تلفن', 'محافظ ولتاژ تلفنی',
      'کیس محافظ تلفن', 'پایه رومیزی تلفن', 'کابل هندزفری', 'برد الکترونیکی تلفن'
    ]

    const categories = ['سیستم‌های تلفنی', 'لوازم جانبی']
    
    const products = []
    let productId = 1

    // Generate 20 products total
    for (let i = 0; i < 20; i++) {
      let title, description, category, basePrice
      
      if (i < 12) {
        // Phone systems (60% of products)
        title = phoneSystemsProducts[i]
        description = `${title} - سیستم تلفنی حرفه‌ای با قابلیت‌های پیشرفته برای مراکز تماس و دفاتر`
        category = 'سیستم‌های تلفنی'
        basePrice = Math.floor(Math.random() * 15000000) + 2000000
      } else {
        // Accessories (40% of products)
        const accessoryIndex = i - 12
        title = accessories[accessoryIndex % accessories.length]
        description = `${title} - لوازم جانبی باکیفیت برای سیستم‌های تلفنی و ارتباطی`
        category = 'لوازم جانبی'
        basePrice = Math.floor(Math.random() * 1000000) + 100000
      }
      
      const discount = Math.random() > 0.7 ? Math.floor(Math.random() * 25) + 5 : 0
      const originalPrice = discount > 0 ? Math.floor(basePrice / (1 - discount / 100)) : undefined
      
      products.push({
        id: productId.toString(),
        title,
        description,
        price: basePrice,
        originalPrice,
        category,
        stock: Math.floor(Math.random() * 30) + 5,
        rating: (Math.random() * 1.5 + 3.5).toFixed(1),
        reviewCount: Math.floor(Math.random() * 100) + 10,
        discount,
        isNew: Math.random() > 0.8,
        status: 'active',
        createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      })
      productId++
    }

    // Save all products
    for (const product of products) {
      await kv.set(`product:${product.id}`, product)
    }

    // Seed 20 phone center articles
    const articleTitles = [
      'راهنمای انتخاب سنترال تلفنی مناسب برای شرکت',
      'مقایسه سیستم‌های VoIP پاناسونیک و زیمنز',
      'نصب و راه‌اندازی سیستم تلفنی IP Office',
      'مزایای استفاده از تلفن‌های آی‌پی در دفاتر',
      'راهنمای تعمیر و نگهداری سنترال‌های تلفنی',
      'بهترین سیستم‌های کنفرانس تلفنی در بازار',
      'آموزش پیکربندی سیستم DECT پاناسونیک',
      'مقایسه سنترال‌های آنالوگ و دیجیتال',
      'راهکارهای ارتباطی برای مراکز تماس',
      'انتخاب هدست مناسب برای مشاوران تلفنی',
      'بررسی قابلیت‌های سیستم‌های VoIP مدرن',
      'راهنمای خرید تلفن بی‌سیم دفتری',
      'نکات مهم در نصب شبکه تلفنی ساختمان',
      'مزایای سیستم‌های تلفنی ابری',
      'آموزش استفاده از کارت‌های خط تلفن',
      'بهترین سوئیچ‌های شبکه برای سیستم‌های VoIP',
      'راهنمای انتخاب میکروفون کنفرانس',
      'مقایسه برندهای مختلف سیستم‌های تلفنی',
      'نکات امنیتی در سیستم‌های VoIP',
      'راهکارهای پشتیبان‌گیری از تنظیمات سنترال'
    ]

    const articles = []
    for (let i = 0; i < 20; i++) {
      const title = articleTitles[i]
      const publishDate = new Date(Date.now() - Math.random() * 60 * 24 * 60 * 60 * 1000)
      
      articles.push({
        id: (i + 1).toString(),
        title,
        excerpt: `راهنمای جامع ${title} با نکات کاربردی و حرفه‌ای برای مراکز تلفنی.`,
        content: `محتوای کامل مقاله ${title} شامل توضیحات تخصصی و راهکارهای عملی...`,
        author: 'تیم فنی تله‌کام سنتر',
        authorId: adminUserId,
        publishDate: publishDate.toISOString(),
        readTime: Math.floor(Math.random() * 12) + 5,
        tags: ['سیستم تلفنی', 'VoIP', 'سنترال', 'ارتباطات'].slice(0, Math.floor(Math.random() * 3) + 2),
        likes: Math.floor(Math.random() * 150) + 15,
        comments: Math.floor(Math.random() * 30) + 3,
        views: Math.floor(Math.random() * 1500) + 200,
        status: 'published',
        createdAt: publishDate.toISOString(),
        updatedAt: publishDate.toISOString()
      })
    }

    // Save all articles
    for (const article of articles) {
      await kv.set(`article:${article.id}`, article)
    }

    return c.json({ 
      message: `داده‌های اولیه با موفقیت ایجاد شد - ${products.length} محصول و ${articles.length} مقاله` 
    })
  } catch (error) {
    console.log('Seed data error:', error)
    return c.json({ error: 'خطا در ایجاد داده‌های اولیه' }, 500)
  }
})

app.get('/make-server-29ea8665/health', (c) => {
  return c.json({ 
    status: 'ok', 
    message: 'سرور تله‌کام سنتر فعال است',
    timestamp: new Date().toISOString() 
  })
})

Deno.serve(app.fetch)