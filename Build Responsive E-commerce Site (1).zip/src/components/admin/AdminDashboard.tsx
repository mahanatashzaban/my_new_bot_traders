import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Package, 
  Users, 
  ShoppingCart, 
  TrendingUp,
  Plus,
  Edit,
  Trash2,
  Eye,
  FileText,
  Settings,
  BarChart3
} from 'lucide-react';

interface AdminDashboardProps {
  onAddProduct?: () => void;
  onEditProduct?: (id: string) => void;
  onDeleteProduct?: (id: string) => void;
  onAddArticle?: () => void;
  onEditArticle?: (id: string) => void;
}

export function AdminDashboard({
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onAddArticle,
  onEditArticle
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data
  const stats = {
    totalProducts: 5000,
    totalUsers: 12450,
    totalOrders: 3280,
    revenue: 45600000
  };

  const recentOrders = [
    { id: '1001', customer: 'احمد محمدی', total: 450000, status: 'delivered', date: '۱۴۰۳/۰۸/۱۵' },
    { id: '1002', customer: 'فاطمه احمدی', total: 780000, status: 'shipped', date: '۱۴۰۳/۰۸/۱۴' },
    { id: '1003', customer: 'علی رضایی', total: 320000, status: 'processing', date: '۱۴۰۳/۰۸/۱۳' },
  ];

  const recentProducts = [
    { id: '1', name: 'گوشی هوشمند سامسونگ', price: 15000000, stock: 25, status: 'active' },
    { id: '2', name: 'لپ تاپ ایسوس', price: 35000000, stock: 10, status: 'active' },
    { id: '3', name: 'هدفون بلوتوثی', price: 850000, stock: 0, status: 'out_of_stock' },
  ];

  const recentArticles = [
    { id: '1', title: 'راهنمای خرید گوشی هوشمند', author: 'مدیر سایت', status: 'published', date: '۱۴۰۳/۰۸/۱۰' },
    { id: '2', title: 'مقایسه لپ تاپ‌های گیمینگ', author: 'مدیر سایت', status: 'draft', date: '۱۴۰۳/۰۸/۰۸' },
    { id: '3', title: 'نکات مهم خرید آنلاین', author: 'مدیر سایت', status: 'published', date: '۱۴۰۳/۰۸/۰۵' },
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
  };

  const getStatusBadge = (status: string) => {
    const statusMap: { [key: string]: { label: string; variant: any } } = {
      active: { label: 'فعال', variant: 'default' },
      out_of_stock: { label: 'ناموجود', variant: 'destructive' },
      published: { label: 'منتشر شده', variant: 'default' },
      draft: { label: 'پیش‌نویس', variant: 'secondary' },
      delivered: { label: 'تحویل شده', variant: 'default' },
      shipped: { label: 'ارسال شده', variant: 'secondary' },
      processing: { label: 'در حال پردازش', variant: 'outline' },
    };
    return statusMap[status] || { label: status, variant: 'outline' };
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">پنل مدیریت</h1>
        <p className="text-gray-600">مدیریت فروشگاه آنلاین</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">داشبورد</TabsTrigger>
          <TabsTrigger value="products">محصولات</TabsTrigger>
          <TabsTrigger value="orders">سفارشات</TabsTrigger>
          <TabsTrigger value="articles">مقالات</TabsTrigger>
          <TabsTrigger value="settings">تنظیمات</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">کل محصولات</p>
                    <p className="text-3xl">{new Intl.NumberFormat('fa-IR').format(stats.totalProducts)}</p>
                  </div>
                  <Package className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">کل کاربران</p>
                    <p className="text-3xl">{new Intl.NumberFormat('fa-IR').format(stats.totalUsers)}</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">کل سفارشات</p>
                    <p className="text-3xl">{new Intl.NumberFormat('fa-IR').format(stats.totalOrders)}</p>
                  </div>
                  <ShoppingCart className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">درآمد کل</p>
                    <p className="text-3xl">{formatPrice(stats.revenue)}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Orders */}
          <Card>
            <CardHeader>
              <CardTitle>آخرین سفارشات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">سفارش #{order.id}</p>
                      <p className="text-sm text-gray-600">{order.customer}</p>
                      <p className="text-sm text-gray-500">{order.date}</p>
                    </div>
                    <div className="text-left">
                      <Badge {...getStatusBadge(order.status)}>
                        {getStatusBadge(order.status).label}
                      </Badge>
                      <p className="text-lg mt-1">{formatPrice(order.total)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Products Tab */}
        <TabsContent value="products" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl">مدیریت محصولات</h2>
            <Button onClick={onAddProduct}>
              <Plus className="w-4 h-4 ml-2" />
              افزودن محصول جدید
            </Button>
          </div>

          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {recentProducts.map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium">{product.name}</h3>
                      <p className="text-sm text-gray-600">موجودی: {product.stock} عدد</p>
                      <p className="text-lg text-primary">{formatPrice(product.price)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge {...getStatusBadge(product.status)}>
                        {getStatusBadge(product.status).label}
                      </Badge>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => onEditProduct?.(product.id)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-red-500"
                          onClick={() => onDeleteProduct?.(product.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders Tab */}
        <TabsContent value="orders" className="space-y-6">
          <h2 className="text-2xl">مدیریت سفارشات</h2>
          
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium">سفارش #{order.id}</h3>
                      <p className="text-sm text-gray-600">{order.customer}</p>
                      <p className="text-sm text-gray-500">{order.date}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge {...getStatusBadge(order.status)}>
                        {getStatusBadge(order.status).label}
                      </Badge>
                      <p className="text-lg">{formatPrice(order.total)}</p>
                      <Button variant="outline" size="sm">
                        مشاهده جزئیات
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Articles Tab */}
        <TabsContent value="articles" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl">مدیریت مقالات</h2>
            <Button onClick={onAddArticle}>
              <Plus className="w-4 h-4 ml-2" />
              نوشتن مقاله جدید
            </Button>
          </div>

          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {recentArticles.map((article) => (
                  <div key={article.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium">{article.title}</h3>
                      <p className="text-sm text-gray-600">نویسنده: {article.author}</p>
                      <p className="text-sm text-gray-500">{article.date}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge {...getStatusBadge(article.status)}>
                        {getStatusBadge(article.status).label}
                      </Badge>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => onEditArticle?.(article.id)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <h2 className="text-2xl">تنظیمات سایت</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>تنظیمات عمومی</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm mb-1">نام فروشگاه</label>
                  <input 
                    type="text" 
                    className="w-full p-2 border rounded-md" 
                    defaultValue="فروشگاه آنلاین" 
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">ایمیل تماس</label>
                  <input 
                    type="email" 
                    className="w-full p-2 border rounded-md" 
                    defaultValue="info@example.com" 
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">شماره تلفن</label>
                  <input 
                    type="tel" 
                    className="w-full p-2 border rounded-md" 
                    defaultValue="021-12345678" 
                  />
                </div>
                <Button>ذخیره تغییرات</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>تنظیمات فروش</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm mb-1">حداقل سفارش برای ارسال رایگان</label>
                  <input 
                    type="number" 
                    className="w-full p-2 border rounded-md" 
                    defaultValue="500000" 
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">هزینه ارسال (تومان)</label>
                  <input 
                    type="number" 
                    className="w-full p-2 border rounded-md" 
                    defaultValue="30000" 
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">مالیات (%)</label>
                  <input 
                    type="number" 
                    className="w-full p-2 border rounded-md" 
                    defaultValue="9" 
                  />
                </div>
                <Button>ذخیره تغییرات</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}