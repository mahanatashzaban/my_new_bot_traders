import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Separator } from '../ui/separator';
import { 
  User, 
  ShoppingBag, 
  Heart, 
  MapPin, 
  CreditCard,
  Bell,
  Settings,
  Package,
  Truck,
  CheckCircle,
  Clock,
  Edit
} from 'lucide-react';

interface Order {
  id: string;
  date: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  total: number;
  items: number;
}

interface UserDashboardProps {
  user?: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    memberSince: string;
  };
}

export function UserDashboard({ user }: UserDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const mockOrders: Order[] = [
    { id: '1001', date: '۱۴۰۳/۰۸/۱۵', status: 'delivered', total: 450000, items: 2 },
    { id: '1002', date: '۱۴۰۳/۰۸/۱۰', status: 'shipped', total: 780000, items: 3 },
    { id: '1003', date: '۱۴۰۳/۰۸/۰۵', status: 'processing', total: 320000, items: 1 },
    { id: '1004', date: '۱۴۰۳/۰۷/۲۸', status: 'pending', total: 150000, items: 1 },
  ];

  const getStatusBadge = (status: Order['status']) => {
    const statusMap = {
      pending: { label: 'در انتظار', variant: 'secondary' as const },
      processing: { label: 'در حال پردازش', variant: 'default' as const },
      shipped: { label: 'ارسال شده', variant: 'secondary' as const },
      delivered: { label: 'تحویل شده', variant: 'outline' as const },
      cancelled: { label: 'لغو شده', variant: 'destructive' as const },
    };
    return statusMap[status];
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'processing':
        return <Package className="w-4 h-4" />;
      case 'shipped':
        return <Truck className="w-4 h-4" />;
      case 'delivered':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-10 h-10 text-primary" />
              </div>
              <CardTitle className="text-lg">
                {user?.firstName} {user?.lastName}
              </CardTitle>
              <p className="text-sm text-gray-500">{user?.email}</p>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                variant={activeTab === 'overview' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('overview')}
              >
                <User className="w-4 h-4 ml-2" />
                داشبورد
              </Button>
              <Button
                variant={activeTab === 'orders' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('orders')}
              >
                <ShoppingBag className="w-4 h-4 ml-2" />
                سفارشات
              </Button>
              <Button
                variant={activeTab === 'favorites' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('favorites')}
              >
                <Heart className="w-4 h-4 ml-2" />
                علاقه‌مندی‌ها
              </Button>
              <Button
                variant={activeTab === 'addresses' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('addresses')}
              >
                <MapPin className="w-4 h-4 ml-2" />
                آدرس‌ها
              </Button>
              <Button
                variant={activeTab === 'settings' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('settings')}
              >
                <Settings className="w-4 h-4 ml-2" />
                تنظیمات
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          {/* Overview */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-6 text-center">
                    <ShoppingBag className="w-8 h-8 text-primary mx-auto mb-2" />
                    <h3 className="text-2xl mb-1">{mockOrders.length}</h3>
                    <p className="text-gray-500">کل سفارشات</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <Heart className="w-8 h-8 text-red-500 mx-auto mb-2" />
                    <h3 className="text-2xl mb-1">۱۲</h3>
                    <p className="text-gray-500">علاقه‌مندی‌ها</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <CreditCard className="w-8 h-8 text-green-500 mx-auto mb-2" />
                    <h3 className="text-2xl mb-1">
                      {formatPrice(mockOrders.reduce((sum, order) => sum + order.total, 0))}
                    </h3>
                    <p className="text-gray-500">کل خریدها</p>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Orders */}
              <Card>
                <CardHeader>
                  <CardTitle>آخرین سفارشات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockOrders.slice(0, 3).map((order) => (
                      <div key={order.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(order.status)}
                          <div>
                            <p className="font-medium">سفارش #{order.id}</p>
                            <p className="text-sm text-gray-500">{order.date}</p>
                          </div>
                        </div>
                        <div className="text-left">
                          <Badge {...getStatusBadge(order.status)}>
                            {getStatusBadge(order.status).label}
                          </Badge>
                          <p className="text-sm text-gray-500 mt-1">
                            {formatPrice(order.total)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Orders */}
          {activeTab === 'orders' && (
            <Card>
              <CardHeader>
                <CardTitle>سفارشات من</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockOrders.map((order) => (
                    <div key={order.id}>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 border rounded-lg">
                        <div className="flex items-center gap-4">
                          {getStatusIcon(order.status)}
                          <div>
                            <h3 className="font-medium">سفارش #{order.id}</h3>
                            <p className="text-sm text-gray-500">{order.date}</p>
                            <p className="text-sm text-gray-500">{order.items} محصول</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-left">
                            <Badge {...getStatusBadge(order.status)}>
                              {getStatusBadge(order.status).label}
                            </Badge>
                            <p className="text-lg mt-1">{formatPrice(order.total)}</p>
                          </div>
                          <Button variant="outline" size="sm">
                            مشاهده جزئیات
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Favorites */}
          {activeTab === 'favorites' && (
            <Card>
              <CardHeader>
                <CardTitle>محصولات مورد علاقه</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">هنوز محصولی به علاقه‌مندی‌ها اضافه نکرده‌اید</p>
                  <Button className="mt-4">مشاهده محصولات</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Addresses */}
          {activeTab === 'addresses' && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>آدرس‌های من</CardTitle>
                <Button>
                  <MapPin className="w-4 h-4 ml-2" />
                  افزودن آدرس جدید
                </Button>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">هنوز آدرسی ثبت نکرده‌اید</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Settings */}
          {activeTab === 'settings' && (
            <Card>
              <CardHeader>
                <CardTitle>تنظیمات حساب کاربری</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg">اطلاعات شخصی</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm mb-1">نام</label>
                      <p className="text-gray-700">{user?.firstName}</p>
                    </div>
                    <div>
                      <label className="block text-sm mb-1">نام خانوادگی</label>
                      <p className="text-gray-700">{user?.lastName}</p>
                    </div>
                    <div>
                      <label className="block text-sm mb-1">ایمیل</label>
                      <p className="text-gray-700">{user?.email}</p>
                    </div>
                    <div>
                      <label className="block text-sm mb-1">شماره تلفن</label>
                      <p className="text-gray-700">{user?.phone}</p>
                    </div>
                  </div>
                  <Button variant="outline">
                    <Edit className="w-4 h-4 ml-2" />
                    ویرایش اطلاعات
                  </Button>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg">تنظیمات اعلان‌ها</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>اعلان ایمیل برای سفارشات</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>اعلان پیامک برای سفارشات</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>دریافت خبرنامه</span>
                      <input type="checkbox" />
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg">امنیت</h3>
                  <Button variant="outline">تغییر رمز عبور</Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}