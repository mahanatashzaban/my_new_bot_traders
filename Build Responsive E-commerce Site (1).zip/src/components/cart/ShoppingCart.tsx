import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '../ui/sheet';
import { Button } from '../ui/button';
import { Separator } from '../ui/separator';
import { Badge } from '../ui/badge';
import { Skeleton } from '../ui/skeleton';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';

interface CartItem {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image?: string;
  quantity: number;
  discount?: number;
}

interface ShoppingCartProps {
  open: boolean;
  onClose: () => void;
  items: CartItem[];
  loading?: boolean;
  onUpdateQuantity?: (id: string, quantity: number) => void;
  onRemoveItem?: (id: string) => void;
  onCheckout?: () => void;
}

export function ShoppingCart({
  open,
  onClose,
  items,
  loading = false,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout
}: ShoppingCartProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
  };

  const getTotalPrice = () => {
    return items.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getTotalItems = () => {
    return items.reduce((total, item) => total + item.quantity, 0);
  };

  const getShippingCost = () => {
    const total = getTotalPrice();
    return total >= 500000 ? 0 : 30000; // Free shipping for orders over 500k
  };

  const getFinalTotal = () => {
    return getTotalPrice() + getShippingCost();
  };

  if (loading) {
    return (
      <Sheet open={open} onOpenChange={onClose}>
        <SheetContent className="w-full sm:max-w-lg">
          <SheetHeader>
            <SheetTitle>سبد خرید</SheetTitle>
            <SheetDescription>در حال بارگذاری محصولات...</SheetDescription>
          </SheetHeader>
          <div className="space-y-4 mt-6">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="flex gap-4">
                <Skeleton className="w-16 h-16" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-6 w-20" />
                </div>
              </div>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            سبد خرید ({getTotalItems()} محصول)
          </SheetTitle>
          <SheetDescription>
            مدیریت محصولات انتخابی و تکمیل فرآیند خرید
          </SheetDescription>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <ShoppingBag className="w-16 h-16 text-gray-300 mb-4" />
            <p className="text-gray-500 text-lg mb-2">سبد خرید شما خالی است</p>
            <p className="text-gray-400 text-sm mb-6">
              محصولات مورد نظر خود را به سبد خرید اضافه کنید
            </p>
            <Button onClick={onClose}>مشاهده محصولات</Button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto space-y-4 mt-6">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4 p-4 border rounded-lg">
                  {/* Product Image */}
                  <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Skeleton className="w-full h-full" />
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="flex-1 space-y-2">
                    <h4 className="text-sm line-clamp-2 text-right">{item.title}</h4>
                    
                    {/* Price */}
                    <div className="flex items-center gap-2">
                      <span className="text-primary">
                        {formatPrice(item.price)}
                      </span>
                      {item.originalPrice && item.originalPrice > item.price && (
                        <>
                          <span className="text-sm text-gray-500 line-through">
                            {formatPrice(item.originalPrice)}
                          </span>
                          {item.discount && (
                            <Badge variant="destructive" className="text-xs">
                              {item.discount}%
                            </Badge>
                          )}
                        </>
                      )}
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center border rounded-lg">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8"
                          onClick={() => onUpdateQuantity?.(item.id, Math.max(1, item.quantity - 1))}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="px-3 py-1 text-sm">{item.quantity}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8"
                          onClick={() => onUpdateQuantity?.(item.id, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>

                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 text-red-500 hover:text-red-700"
                        onClick={() => onRemoveItem?.(item.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Cart Summary */}
            <div className="border-t pt-4 space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>جمع محصولات:</span>
                  <span>{formatPrice(getTotalPrice())}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>هزینه ارسال:</span>
                  <span>
                    {getShippingCost() === 0 ? (
                      <span className="text-green-600">رایگان</span>
                    ) : (
                      formatPrice(getShippingCost())
                    )}
                  </span>
                </div>
                {getShippingCost() > 0 && (
                  <p className="text-xs text-gray-500">
                    برای ارسال رایگان {formatPrice(500000 - getTotalPrice())} تومان به خرید خود اضافه کنید
                  </p>
                )}
                <Separator />
                <div className="flex justify-between font-medium">
                  <span>مجموع:</span>
                  <span className="text-primary text-lg">
                    {formatPrice(getFinalTotal())}
                  </span>
                </div>
              </div>

              <Button 
                className="w-full" 
                size="lg"
                onClick={onCheckout}
              >
                ادامه فرآیند خرید
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}