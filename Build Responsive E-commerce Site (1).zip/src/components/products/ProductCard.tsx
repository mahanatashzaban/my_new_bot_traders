import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Skeleton } from '../ui/skeleton';
import { Heart, ShoppingCart, Star, Eye } from 'lucide-react';

interface ProductCardProps {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image?: string;
  rating?: number;
  reviewCount?: number;
  discount?: number;
  isNew?: boolean;
  isFavorite?: boolean;
  onAddToCart?: (id: string) => void;
  onToggleFavorite?: (id: string) => void;
  onViewProduct?: (id: string) => void;
  loading?: boolean;
}

export function ProductCard({
  id,
  title,
  price,
  originalPrice,
  image,
  rating = 0,
  reviewCount = 0,
  discount,
  isNew,
  isFavorite = false,
  onAddToCart,
  onToggleFavorite,
  onViewProduct,
  loading = false
}: ProductCardProps) {
  if (loading) {
    return (
      <Card className="overflow-hidden group">
        <CardContent className="p-0">
          <div className="relative">
            <Skeleton className="w-full h-48" />
          </div>
          <div className="p-4 space-y-3">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-6 w-1/2" />
            <div className="flex gap-2">
              <Skeleton className="h-8 flex-1" />
              <Skeleton className="h-8 w-8" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
  };

  return (
    <Card className="overflow-hidden group hover:shadow-lg transition-all duration-300">
      <CardContent className="p-0">
        {/* Image */}
        <div className="relative overflow-hidden">
          {image ? (
            <img
              src={image}
              alt={title}
              className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <Skeleton className="w-full h-48" />
          )}
          
          {/* Badges */}
          <div className="absolute top-2 right-2 flex flex-col gap-1">
            {isNew && (
              <Badge variant="destructive" className="text-xs">
                جدید
              </Badge>
            )}
            {discount && (
              <Badge variant="secondary" className="text-xs">
                {discount}% تخفیف
              </Badge>
            )}
          </div>

          {/* Quick Actions */}
          <div className="absolute top-2 left-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              size="icon"
              variant="secondary"
              className="w-8 h-8"
              onClick={() => onToggleFavorite?.(id)}
            >
              <Heart 
                className={`w-4 h-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} 
              />
            </Button>
            <Button
              size="icon"
              variant="secondary"
              className="w-8 h-8"
              onClick={() => onViewProduct?.(id)}
            >
              <Eye className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3">
          {/* Rating */}
          {rating > 0 && (
            <div className="flex items-center gap-1">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">({reviewCount})</span>
            </div>
          )}

          {/* Title */}
          <h3 className="text-sm line-clamp-2 hover:text-primary cursor-pointer text-right">
            {title}
          </h3>

          {/* Price */}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-lg text-primary">
                {formatPrice(price)}
              </span>
              {originalPrice && originalPrice > price && (
                <span className="text-sm text-gray-500 line-through">
                  {formatPrice(originalPrice)}
                </span>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button
              className="flex-1"
              onClick={() => onAddToCart?.(id)}
            >
              <ShoppingCart className="w-4 h-4 ml-2" />
              افزودن به سبد
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}