import React from 'react';
import { ProductCard } from './ProductCard';

interface Product {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image?: string;
  rating?: number;
  reviewCount?: number;
  discount?: number;
  isNew?: boolean;
  isFavorite?: boolean;
}

interface ProductGridProps {
  products: Product[];
  loading?: boolean;
  onAddToCart?: (id: string) => void;
  onToggleFavorite?: (id: string) => void;
  onViewProduct?: (id: string) => void;
}

export function ProductGrid({
  products,
  loading = false,
  onAddToCart,
  onToggleFavorite,
  onViewProduct
}: ProductGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {Array.from({ length: 8 }).map((_, index) => (
          <ProductCard
            key={index}
            id=""
            title=""
            price={0}
            loading={true}
          />
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">محصولی یافت نشد</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          {...product}
          onAddToCart={onAddToCart}
          onToggleFavorite={onToggleFavorite}
          onViewProduct={onViewProduct}
        />
      ))}
    </div>
  );
}