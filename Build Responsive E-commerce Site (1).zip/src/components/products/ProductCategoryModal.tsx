import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { ChevronRight, X } from 'lucide-react';
import { CategoryItem } from '../../utils/productCategories';

interface ProductCategoryModalProps {
  open: boolean;
  onClose: () => void;
  categories: CategoryItem[];
  title: string;
  onSelectCategory: (category: CategoryItem) => void;
  breadcrumbs?: CategoryItem[];
  onBreadcrumbClick?: (category: CategoryItem) => void;
  gradientColor?: string;
}

const gradientColors: Record<string, string> = {
  telecom: 'from-blue-500 to-blue-600',
  network: 'from-green-500 to-green-600',
  audio: 'from-purple-500 to-purple-600',
  camera: 'from-orange-500 to-orange-600',
  power: 'from-yellow-500 to-yellow-600',
  video: 'from-pink-500 to-pink-600',
  office: 'from-indigo-500 to-indigo-600',
  alarm: 'from-red-500 to-red-600',
};

export function ProductCategoryModal({
  open,
  onClose,
  categories,
  title,
  onSelectCategory,
  breadcrumbs = [],
  onBreadcrumbClick,
  gradientColor = 'from-blue-500 to-blue-600',
}: ProductCategoryModalProps) {
  const getGradient = () => {
    if (breadcrumbs.length > 0) {
      const rootCategory = breadcrumbs[0];
      return gradientColors[rootCategory.id] || gradientColor;
    }
    return gradientColor;
  };

  const gradient = getGradient();

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden flex flex-col p-0 gap-0 rounded-3xl">
        {/* Header with gradient */}
        <div className={`bg-gradient-to-r ${gradient} px-8 py-6 text-white`}>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-bold text-white m-0">
              {title}
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-xl h-10 w-10"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Breadcrumbs */}
          {breadcrumbs.length > 0 && (
            <div className="flex items-center gap-2 mt-4 flex-wrap">
              <button
                onClick={() => onBreadcrumbClick?.(breadcrumbs[0])}
                className="text-sm text-white/90 hover:text-white hover:underline transition-all"
              >
                محصولات
              </button>
              {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={crumb.id}>
                  <ChevronRight className="w-4 h-4 text-white/70" />
                  <button
                    onClick={() => onBreadcrumbClick?.(crumb)}
                    className={`text-sm transition-all ${
                      index === breadcrumbs.length - 1
                        ? 'text-white font-semibold'
                        : 'text-white/90 hover:text-white hover:underline'
                    }`}
                  >
                    {crumb.label}
                  </button>
                </React.Fragment>
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map((category) => (
              <Button
                key={category.id}
                onClick={() => onSelectCategory(category)}
                variant="outline"
                className="h-auto py-6 px-5 text-base font-medium hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2 hover:border-orange-500 rounded-2xl flex flex-col items-center justify-center text-center whitespace-normal min-h-[80px]"
              >
                <span className="leading-relaxed">{category.label}</span>
              </Button>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
