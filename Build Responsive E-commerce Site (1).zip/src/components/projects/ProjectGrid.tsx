import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Building, Calendar, MapPin, Eye } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Skeleton } from '../ui/skeleton';

interface Project {
  id: string;
  title: string;
  client: string;
  location: string;
  date: string;
  category: string;
  image: string;
  description: string;
}

interface ProjectGridProps {
  projects: Project[];
  loading?: boolean;
  onViewDetails?: (projectId: string) => void;
}

export function ProjectGrid({ projects, loading, onViewDetails }: ProjectGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="overflow-hidden border-0 shadow-lg">
            <Skeleton className="h-56 w-full" />
            <CardContent className="p-6">
              <Skeleton className="h-6 w-3/4 mb-4" />
              <Skeleton className="h-4 w-1/2 mb-2" />
              <Skeleton className="h-4 w-2/3 mb-2" />
              <Skeleton className="h-4 w-1/3" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="bg-gray-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Building className="w-10 h-10 text-gray-400" />
        </div>
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">هیچ پروژه‌ای یافت نشد</h3>
        <p className="text-gray-600">در حال حاضر پروژه‌ای برای نمایش وجود ندارد</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {projects.map((project) => (
        <Card 
          key={project.id}
          className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer bg-white"
          onClick={() => onViewDetails && onViewDetails(project.id)}
        >
          <div className="relative h-56 overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
            <ImageWithFallback
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />
            <div className="absolute top-4 right-4">
              <Badge className="bg-blue-600 text-white">{project.category}</Badge>
            </div>
          </div>
          
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4 group-hover:text-blue-600 transition-colors line-clamp-1">
              {project.title}
            </h3>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Building className="w-4 h-4 text-blue-600" />
                <span className="line-clamp-1">{project.client}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4 text-green-600" />
                <span className="line-clamp-1">{project.location}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="w-4 h-4 text-orange-600" />
                <span>{project.date}</span>
              </div>
            </div>

            <p className="text-sm text-gray-600 leading-relaxed line-clamp-2 mb-4">
              {project.description}
            </p>

            <div className="flex items-center gap-2 text-blue-600 font-medium text-sm group-hover:gap-3 transition-all">
              <Eye className="w-4 h-4" />
              <span>مشاهده جزئیات</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
