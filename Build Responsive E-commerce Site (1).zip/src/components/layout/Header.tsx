import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { 
  Search, 
  ShoppingCart, 
  User, 
  Menu, 
  X,
  Phone,
  Smartphone,
  Headphones,
  Settings,
  Award,
  Users,
  Bell,
  ChevronDown,
  LogOut,
  Heart,
  MapPin,
  Clock,
  MessageCircle,
  Truck,
  Building,
  FileText,
  Briefcase,
  Network,
  Video,
  Camera,
  HardDrive,
  Monitor,
  Printer,
  Eye,
  Shield,
  Zap,
  AlertTriangle,
  Wrench,
  Target,
  History,
  Star,
  Cpu,
  BookOpen,
  Trophy,
  Certificate
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '../ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';

interface HeaderProps {
  cartItemsCount?: number;
  isLoggedIn?: boolean;
  user?: any;
  onLogin?: () => void;
  onLogout?: () => void;
  onCartClick?: () => void;
  onNavigate?: (page: string) => void;
  onOpenProductModal?: () => void;
}

export function Header({ 
  cartItemsCount = 0, 
  isLoggedIn = false,
  user,
  onLogin, 
  onLogout, 
  onCartClick,
  onNavigate,
  onOpenProductModal
}: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isProductsModalOpen, setIsProductsModalOpen] = useState(false);
  const [isServicesModalOpen, setIsServicesModalOpen] = useState(false);
  const [isProjectsModalOpen, setIsProjectsModalOpen] = useState(false);
  const [isCompanyModalOpen, setIsCompanyModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  const handleNavigation = (page: string) => {
    if (onNavigate) {
      onNavigate(page);
    }
    setIsMenuOpen(false);
    // Close all modals
    setIsProductsModalOpen(false);
    setIsServicesModalOpen(false);
    setIsProjectsModalOpen(false);
    setIsCompanyModalOpen(false);
    setIsContactModalOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim() && onNavigate) {
      onNavigate('products');
    }
  };

  const productCategories = [
    { label: 'مخابرات', icon: Phone, page: 'communications' },
    { label: 'شبکه', icon: Network, page: 'network' },
    { label: 'صوت', icon: Headphones, page: 'audio' },
    { label: 'دوربین', icon: Camera, page: 'camera' },
    { label: 'منابع تغذیه', icon: Zap, page: 'power' },
    { label: 'تصویر', icon: Monitor, page: 'video' },
    { label: 'ماشین های اداری', icon: Printer, page: 'office' },
    { label: 'سیستم های تغذیه', icon: HardDrive, page: 'power-systems' },
  ];

  const serviceCategories = [
    { label: 'خدمات فناوری ارتباطات', page: 'communication-services' },
    { label: 'خدمات فناوری اطلاعات', page: 'it-services' },
    { label: 'خدمات سیستم های صوت و تصویر', page: 'av-services' },
    { label: 'خدمات سیستم های نظارت تصویری', page: 'surveillance-services' },
    { label: 'سیستم های منابع تغذیه', page: 'power-services' },
    { label: 'سیستم های هشدار دهنده', page: 'alarm-services' },
    { label: 'خدمات پس از فروش', page: 'after-sales' },
    { label: 'سرویس و تعمیرات', page: 'maintenance' },
    { label: 'حوزه های فعالیت', page: 'activity-areas' },
  ];

  const projectCategories = [
    { label: 'لیست پروژه ها', icon: Briefcase, page: 'project-list' },
    { label: 'رزومه', icon: FileText, page: 'resume' },
  ];

  const companyCategories = [
    { label: 'آشنایی کلی', page: 'company-overview' },
    { label: 'تاریخچه تاسیس', page: 'company-history' },
    { label: 'تجهیزات و ماشین آلات', page: 'equipment' },
    { label: 'چارت سازمانی', page: 'org-chart' },
    { label: 'حوزه های فعالیت', page: 'activity-fields' },
    { label: 'رزومه هوشمند زمان پارت', page: 'smart-resume' },
    { label: 'اهم مشتریان ما', page: 'main-clients' },
    { label: 'گواهی حسن انجام کار', page: 'certificates' },
    { label: 'دستاوردها و افتخارات', page: 'achievements' },
    { label: 'کاتالوگ شرکت', page: 'catalog' },
  ];

  return (
    <header className="bg-white border-b shadow-sm">
      {/* Main Header */}
      <div className="bg-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col lg:flex-row items-center gap-6">
            {/* Logo */}
            <div className="flex items-center gap-4 cursor-pointer" onClick={() => handleNavigation('home')}>
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-4 rounded-2xl shadow-xl">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <div className="text-right">
                <h1 className="text-2xl font-bold text-gray-800">هوشمند زمان پارت</h1>
                <p className="text-sm text-gray-600 mt-1">سیستم‌های تلفنی و ارتباطی</p>
              </div>
            </div>

            {/* Search Bar - Desktop */}
            <div className="hidden lg:flex flex-1 max-w-3xl">
              <form onSubmit={handleSearch} className="relative w-full">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="جستجو در سیستم‌های تلفنی، سنترال، VoIP و لوازم جانبی..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="h-14 pr-6 pl-16 rounded-2xl border-2 border-gray-200 focus:border-blue-500 shadow-sm bg-gray-50 focus:bg-white transition-all text-right text-gray-800 placeholder:text-gray-500"
                  />
                  <div className="absolute left-2 top-2 flex">
                    <Button 
                      type="submit"
                      size="sm"
                      className="h-10 px-6 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl shadow-md transition-all"
                    >
                      <Search className="w-4 h-4 ml-2" />
                      جستجو
                    </Button>
                  </div>
                </div>
              </form>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-4">
              {/* Contact Info */}
              <div className="hidden xl:flex items-center gap-6 text-sm text-gray-600 border-l border-gray-200 pl-6">
                <span className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">۰۲۱-۱۲۳۴۵۶۷۸</span>
                </span>
                <span className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>تهران، خیابان انقلاب</span>
                </span>
              </div>

              {/* User Menu */}
              {isLoggedIn ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="flex items-center gap-3 hover:bg-gray-50 rounded-xl px-4 py-3 border-gray-200">
                      <div className="bg-blue-100 p-2 rounded-lg">
                        <User className="w-4 h-4 text-blue-600" />
                      </div>
                      <div className="hidden sm:block text-right">
                        <span className="text-sm font-medium text-gray-800">
                          {user?.firstName || 'کاربر'}
                        </span>
                        <div className="text-xs text-gray-500">حساب کاربری</div>
                      </div>
                      <ChevronDown className="w-3 h-3 text-gray-400" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 mt-2">
                    <DropdownMenuItem onClick={() => handleNavigation('dashboard')} className="text-right">
                      <User className="w-4 h-4 ml-2" />
                      <span>داشبورد</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleNavigation('orders')} className="text-right">
                      <Bell className="w-4 h-4 ml-2" />
                      <span>سفارشات من</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleNavigation('wishlist')} className="text-right">
                      <Heart className="w-4 h-4 ml-2" />
                      <span>علاقه‌مندی‌ها</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={onLogout} className="text-red-600 text-right">
                      <LogOut className="w-4 h-4 ml-2" />
                      <span>خروج از حساب</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button 
                  onClick={onLogin} 
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl px-6 py-3 shadow-md"
                >
                  <User className="w-4 h-4 ml-2" />
                  <span>ورود / ثبت نام</span>
                </Button>
              )}

              {/* Cart */}
              <Button 
                variant="outline" 
                size="icon"
                className="relative text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl border-gray-200 w-12 h-12"
                onClick={onCartClick}
              >
                <ShoppingCart className="w-5 h-5" />
                {cartItemsCount > 0 && (
                  <Badge 
                    className="absolute -top-2 -right-2 w-5 h-5 rounded-full p-0 flex items-center justify-center text-xs bg-red-500 text-white"
                  >
                    {cartItemsCount}
                  </Badge>
                )}
              </Button>

              {/* Mobile Menu Button */}
              <Button
                variant="outline"
                size="icon"
                className="lg:hidden text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl border-gray-200 w-12 h-12"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="lg:hidden w-full mt-6">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="جستجو در سیستم‌های تلفنی..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 pr-4 pl-16 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white text-right"
              />
              <Button 
                type="submit"
                size="sm"
                className="absolute left-2 top-2 h-8 px-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 rounded-lg text-white"
              >
                <Search className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="bg-gradient-to-l from-gray-50 to-white border-t border-gray-100">
        <div className="container mx-auto px-4">
          {/* Desktop Navigation */}
          <div className="hidden lg:block py-4">
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide pb-2">
              <Button 
                variant="ghost" 
                onClick={() => handleNavigation('home')}
                className="text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium transition-all whitespace-nowrap"
              >
                خانه
              </Button>
              
              <Button 
                variant="ghost" 
                onClick={onOpenProductModal || (() => setIsProductsModalOpen(true))}
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium whitespace-nowrap"
              >
                <Phone className="w-4 h-4" />
                <span>محصولات</span>
                <ChevronDown className="w-3 h-3" />
              </Button>

              <Button 
                variant="ghost" 
                onClick={() => setIsProjectsModalOpen(true)}
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium whitespace-nowrap"
              >
                <Briefcase className="w-4 h-4" />
                <span>پروژه ها</span>
              </Button>

              <Button 
                variant="ghost" 
                onClick={() => setIsServicesModalOpen(true)}
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium whitespace-nowrap"
              >
                <Wrench className="w-4 h-4" />
                <span>خدمات و پشتیبانی</span>
                <ChevronDown className="w-3 h-3" />
              </Button>

              <Button 
                variant="ghost" 
                onClick={() => handleNavigation('articles')}
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="text-center">مقالات و راهنماها</span>
              </Button>

              <Button 
                variant="ghost" 
                onClick={() => setIsCompanyModalOpen(true)}
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium whitespace-nowrap"
              >
                <Building className="w-4 h-4" />
                <span>شرکت در یک نگاه</span>
              </Button>

              <Button 
                variant="ghost" 
                onClick={() => setIsContactModalOpen(true)}
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl px-6 py-3 font-medium whitespace-nowrap"
              >
                <Phone className="w-4 h-4" />
                <span>ارتباط با ما</span>
              </Button>
            </div>

            <div className="flex items-center justify-end gap-4 text-sm text-gray-600 mt-2">
              <div className="flex items-center gap-6">
                <span className="flex items-center gap-2 bg-gradient-to-r from-green-50 to-green-100 text-green-700 px-4 py-2 rounded-xl border border-green-200">
                  <Award className="w-4 h-4" />
                  <span className="font-medium">ضمانت اصالت کالا</span>
                </span>
                <span className="flex items-center gap-2 bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 px-4 py-2 rounded-xl border border-blue-200">
                  <Truck className="w-4 h-4" />
                  <span className="font-medium">ارسال سریع</span>
                </span>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="lg:hidden py-6 space-y-3 bg-white rounded-2xl mt-4 shadow-xl border border-gray-100">
              <Button 
                variant="ghost" 
                onClick={() => handleNavigation('home')}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                خانه
              </Button>
              <Button 
                variant="ghost" 
                onClick={onOpenProductModal || (() => setIsProductsModalOpen(true))}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                <Phone className="w-5 h-5 ml-3" />
                <span>محصولات</span>
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => setIsProjectsModalOpen(true)}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                <Briefcase className="w-5 h-5 ml-3" />
                <span>پروژه ها</span>
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => setIsServicesModalOpen(true)}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                <Wrench className="w-5 h-5 ml-3" />
                <span>خدمات و پشتیبانی</span>
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => handleNavigation('articles')}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                <MessageCircle className="w-5 h-5 ml-3" />
                <span>مقالات و راهنماها</span>
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => setIsCompanyModalOpen(true)}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                <Building className="w-5 h-5 ml-3" />
                <span>شرکت در یک نگاه</span>
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => setIsContactModalOpen(true)}
                className="w-full justify-start text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl p-4 font-medium"
              >
                <Phone className="w-5 h-5 ml-3" />
                <span>ارتباط با ما</span>
              </Button>
              {/* Mobile contact info */}
              <div className="border-t border-gray-100 pt-4 mt-4 space-y-3">
                <div className="flex items-center gap-3 px-4 text-sm text-gray-600">
                  <Phone className="w-4 h-4 text-blue-600" />
                  <span>۰۲۱-۱۲۳۴۵۶۷۸</span>
                </div>
                <div className="flex items-center gap-3 px-4 text-sm text-gray-600">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>تهران، خیابان انقلاب</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Products Modal */}
      <Dialog open={isProductsModalOpen} onOpenChange={setIsProductsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto bg-gradient-to-br from-blue-50 to-indigo-100">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold text-gray-800">محصولات</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-6">
            {productCategories.map((category) => {
              const IconComponent = category.icon;
              return (
                <Button
                  key={category.label}
                  variant="outline"
                  onClick={() => handleNavigation(category.page)}
                  className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-blue-50 hover:border-blue-200 transition-all bg-white/80 backdrop-blur-sm min-h-[120px] text-center"
                >
                  <div className="bg-blue-100 p-4 rounded-xl">
                    <IconComponent className="w-8 h-8 text-blue-600" />
                  </div>
                  <span className="text-center font-medium leading-tight text-sm">{category.label}</span>
                </Button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Services Modal */}
      <Dialog open={isServicesModalOpen} onOpenChange={setIsServicesModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto bg-gradient-to-br from-green-50 to-emerald-100">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold text-gray-800">خدمات و پشتیبانی</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
            {serviceCategories.map((service) => (
              <Button
                key={service.label}
                variant="outline"
                onClick={() => handleNavigation(service.page)}
                className="h-auto p-4 text-center justify-center hover:bg-green-50 hover:border-green-200 transition-all bg-white/80 backdrop-blur-sm min-h-[60px] leading-tight"
              >
                <span className="font-medium text-sm">{service.label}</span>
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Projects Modal */}
      <Dialog open={isProjectsModalOpen} onOpenChange={setIsProjectsModalOpen}>
        <DialogContent className="max-w-2xl bg-gradient-to-br from-purple-50 to-violet-100">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold text-gray-800">پروژه ها</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
            {projectCategories.map((project) => {
              const IconComponent = project.icon;
              return (
                <Button
                  key={project.label}
                  variant="outline"
                  onClick={() => handleNavigation(project.page)}
                  className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-purple-50 hover:border-purple-200 transition-all bg-white/80 backdrop-blur-sm min-h-[120px] text-center"
                >
                  <div className="bg-purple-100 p-4 rounded-xl">
                    <IconComponent className="w-8 h-8 text-purple-600" />
                  </div>
                  <span className="text-center font-medium leading-tight text-sm">{project.label}</span>
                </Button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Company Modal */}
      <Dialog open={isCompanyModalOpen} onOpenChange={setIsCompanyModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto bg-gradient-to-br from-orange-50 to-amber-100">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold text-gray-800">شرکت در یک نگاه</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
            {companyCategories.map((item) => (
              <Button
                key={item.label}
                variant="outline"
                onClick={() => handleNavigation(item.page)}
                className="h-auto p-4 text-center justify-center hover:bg-orange-50 hover:border-orange-200 transition-all bg-white/80 backdrop-blur-sm min-h-[60px] leading-tight"
              >
                <span className="font-medium text-sm">{item.label}</span>
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Contact Modal */}
      <Dialog open={isContactModalOpen} onOpenChange={setIsContactModalOpen}>
        <DialogContent className="max-w-3xl bg-gradient-to-br from-cyan-50 to-blue-100">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold text-gray-800">ارتباط با ما</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
            <Button
              variant="outline"
              onClick={() => handleNavigation('contact-us')}
              className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-cyan-50 hover:border-cyan-200 transition-all bg-white/80 backdrop-blur-sm min-h-[100px] text-center"
            >
              <div className="bg-cyan-100 p-4 rounded-xl">
                <Phone className="w-6 h-6 text-cyan-600" />
              </div>
              <span className="font-medium">تماس با ما</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleNavigation('free-consultation')}
              className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-cyan-50 hover:border-cyan-200 transition-all bg-white/80 backdrop-blur-sm min-h-[100px] text-center"
            >
              <div className="bg-cyan-100 p-4 rounded-xl">
                <MessageCircle className="w-6 h-6 text-cyan-600" />
              </div>
              <span className="font-medium">درخواست مشاوره رایگان</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleNavigation('job-request')}
              className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-cyan-50 hover:border-cyan-200 transition-all bg-white/80 backdrop-blur-sm min-h-[100px] text-center"
            >
              <div className="bg-cyan-100 p-4 rounded-xl">
                <Briefcase className="w-6 h-6 text-cyan-600" />
              </div>
              <span className="font-medium">درخواست استخدام</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleNavigation('faq')}
              className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-cyan-50 hover:border-cyan-200 transition-all bg-white/80 backdrop-blur-sm min-h-[100px] text-center"
            >
              <div className="bg-cyan-100 p-4 rounded-xl">
                <MessageCircle className="w-6 h-6 text-cyan-600" />
              </div>
              <span className="font-medium">پرسش های متداول</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleNavigation('customer-voice')}
              className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-cyan-50 hover:border-cyan-200 transition-all bg-white/80 backdrop-blur-sm min-h-[100px] text-center"
            >
              <div className="bg-cyan-100 p-4 rounded-xl">
                <Star className="w-6 h-6 text-cyan-600" />
              </div>
              <span className="font-medium">صدای مشتری</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleNavigation('survey-form')}
              className="h-auto p-6 flex flex-col items-center gap-4 hover:bg-cyan-50 hover:border-cyan-200 transition-all bg-white/80 backdrop-blur-sm min-h-[100px] text-center"
            >
              <div className="bg-cyan-100 p-4 rounded-xl">
                <FileText className="w-6 h-6 text-cyan-600" />
              </div>
              <span className="font-medium">فرم نظرسنجی</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}