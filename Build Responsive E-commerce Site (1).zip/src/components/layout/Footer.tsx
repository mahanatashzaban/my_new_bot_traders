import React from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Instagram, 
  Twitter, 
  Facebook,
  Send,
  Smartphone,
  Headphones,
  Settings,
  Shield,
  Award,
  Truck,
  Clock,
  Users
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Separator } from '../ui/separator';
import { Card, CardContent } from '../ui/card';

export function Footer() {
  const quickLinks = [
    { label: 'درباره ما', href: '/about' },
    { label: 'تماس با ما', href: '/contact' },
    { label: 'خدمات فنی', href: '/support' },
    { label: 'ضمانت و گارانتی', href: '/warranty' },
    { label: 'راهنمای خرید', href: '/guide' },
    { label: 'پیگیری سفارش', href: '/track-order' },
  ];

  const productCategories = [
    { label: 'سیستم‌های تلفنی', href: '/phones', icon: Phone },
    { label: 'سنترال‌های تلفنی', href: '/centrals', icon: Settings },
    { label: 'تلفن‌های VoIP', href: '/voip', icon: Phone },
    { label: 'لوازم جانبی', href: '/accessories', icon: Headphones },
  ];

  const services = [
    { label: 'نصب سیستم تلفنی', href: '/installation' },
    { label: 'پیکربندی سنترال', href: '/configuration' },
    { label: 'نگهداری و تعمیر', href: '/maintenance' },
    { label: 'پشتیبانی فنی', href: '/support' },
  ];

  return (
    <footer className="bg-slate-900 text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-64 h-64 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-secondary rounded-full blur-3xl"></div>
      </div>

      {/* Newsletter Section */}
      <div className="relative bg-gradient-to-r from-primary to-secondary py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-4 text-center">عضویت در خبرنامه</h3>
            <p className="text-lg text-white/90 mb-8 text-center">
              از آخرین اخبار سیستم‌های تلفنی، تخفیف‌های ویژه و محصولات جدید باخبر شوید
            </p>
            <div className="flex flex-col sm:flex-row max-w-lg mx-auto gap-3">
              <Input
                type="email"
                placeholder="ایمیل خود را وارد کنید"
                className="bg-white/20 border-white/30 text-white placeholder:text-white/70 h-12"
              />
              <Button variant="secondary" size="lg" className="h-12 px-8">
                <Send className="w-4 h-4 ml-2" />
                عضویت
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="relative container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary p-2 rounded-lg">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">هوشمند زمان پارت</h3>
                <p className="text-sm text-gray-400">سیستم‌های تلفنی و ارتباطی</p>
              </div>
            </div>
            
            <p className="text-gray-300 mb-6 leading-relaxed text-right">
              بیش از ۱۰ سال تجربه در زمینه فروش و نصب سیستم‌های تلفنی. 
              ما متعهد به ارائه بهترین راه‌حل‌های ارتباطی و خدمات فنی هستیم.
            </p>

            {/* Trust Indicators */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-slate-800 p-3 rounded-lg text-center">
                <Users className="w-5 h-5 text-primary mx-auto mb-1" />
                <p className="text-xs text-gray-300">+۱۰K مشتری</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg text-center">
                <Award className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
                <p className="text-xs text-gray-300">۱۰ سال تجربه</p>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-orange-400" />
                <span className="text-gray-300">۰۹۱۲۰۲۸۲۸۴۵ - ۰۲۱۴۶۰۵۴۷۵۴</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-orange-400" />
                <span className="text-gray-300">info@hzp.com</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-orange-400" />
                <span className="text-gray-300">تهران، خیابان انقلاب</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-orange-400" />
                <span className="text-gray-300">شنبه تا پنج‌شنبه ۹-۲۱</span>
              </div>
            </div>
          </div>

          {/* Product Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-orange-400">محصولات ما</h4>
            <ul className="space-y-4">
              {productCategories.map((category) => {
                const IconComponent = category.icon;
                return (
                  <li key={category.label}>
                    <a
                      href={category.href}
                      className="flex items-center gap-3 text-gray-300 hover:text-orange-400 transition-colors group"
                    >
                      <IconComponent className="w-4 h-4 group-hover:text-orange-400 transition-colors" />
                      {category.label}
                    </a>
                  </li>
                );
              })}
            </ul>

            <h5 className="text-md font-semibold mb-4 mt-8 text-orange-300 text-center">خدمات فنی</h5>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service.label}>
                  <a
                    href={service.href}
                    className="text-gray-300 hover:text-orange-400 transition-colors text-sm text-right block"
                  >
                    {service.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-orange-400">لینک‌های مفید</h4>
            <ul className="space-y-4">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-orange-400 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>

            {/* Working Hours */}
            <div className="mt-8 bg-slate-800 p-4 rounded-lg">
              <h5 className="font-semibold mb-3 text-orange-300">ساعات کاری</h5>
              <div className="space-y-2 text-sm text-gray-300">
                <div className="flex justify-between">
                  <span>شنبه - پنج‌شنبه:</span>
                  <span>۹:۰۰ - ۲۱:۰۰</span>
                </div>
                <div className="flex justify-between">
                  <span>جمعه:</span>
                  <span>۱۴:۰۰ - ۲۰:۰۰</span>
                </div>
              </div>
            </div>
          </div>

          {/* Social Media & Guarantees */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-orange-400">ما را دنبال کنید</h4>
            <div className="flex gap-4 mb-8">
              <a
                href="#"
                className="bg-slate-800 p-3 rounded-lg hover:bg-orange-500 transition-colors group"
              >
                <Instagram className="w-5 h-5 text-white group-hover:text-white" />
              </a>
              <a
                href="#"
                className="bg-slate-800 p-3 rounded-lg hover:bg-blue-500 transition-colors group"
              >
                <Twitter className="w-5 h-5 text-white group-hover:text-white" />
              </a>
              <a
                href="#"
                className="bg-slate-800 p-3 rounded-lg hover:bg-blue-600 transition-colors group"
              >
                <Facebook className="w-5 h-5 text-white group-hover:text-white" />
              </a>
            </div>

            {/* Guarantees */}
            <div className="space-y-3">
              <div className="bg-gradient-to-r from-green-600/20 to-green-500/20 border border-green-500/30 p-4 rounded-lg">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-green-400" />
                  <div>
                    <p className="font-semibold text-green-300">ضمانت اصالت کالا</p>
                    <p className="text-xs text-green-400">۱۰۰٪ اصل و معتبر</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-600/20 to-blue-500/20 border border-blue-500/30 p-4 rounded-lg">
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-blue-400" />
                  <div className="text-center flex-1">
                    <p className="font-semibold text-blue-300">ارسال سریع</p>
                    <p className="text-xs text-blue-400">حداکثر ۲۴ ساعت</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-orange-600/20 to-orange-500/20 border border-orange-500/30 p-4 rounded-lg">
                <div className="flex items-center gap-3">
                  <Settings className="w-5 h-5 text-orange-400" />
                  <div className="text-center flex-1">
                    <p className="font-semibold text-orange-300">خدمات فنی</p>
                    <p className="text-xs text-orange-400 text-right">نصب، راه‌اندازی و پشتیبانی سیستم‌های تلفنی</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-slate-700" />

      {/* Bottom Bar */}
      <div className="relative container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            © ۱۴۰۳ تله‌کام سنتر. تمامی حقوق محفوظ است.
          </p>
          <div className="flex items-center gap-6 text-sm">
            <a href="/terms" className="text-gray-400 hover:text-orange-400 transition-colors">
              شرایط استفاده
            </a>
            <a href="/privacy" className="text-gray-400 hover:text-orange-400 transition-colors">
              حریم خصوصی
            </a>
            <span className="text-gray-500">طراحی و توسعه با ❤️</span>
          </div>
        </div>
      </div>
    </footer>
  );
}