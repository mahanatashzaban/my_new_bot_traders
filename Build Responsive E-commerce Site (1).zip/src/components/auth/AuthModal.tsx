import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Eye, EyeOff, Mail, Lock, User, Phone } from 'lucide-react';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onLogin?: (email: string, password: string) => void;
  onRegister?: (data: RegisterData) => void;
}

interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
}

export function AuthModal({ open, onClose, onLogin, onRegister }: AuthModalProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin?.(loginData.email, loginData.password);
    onClose();
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (registerData.password !== registerData.confirmPassword) {
      alert('رمز عبور و تکرار آن یکسان نیست');
      return;
    }
    onRegister?.({
      firstName: registerData.firstName,
      lastName: registerData.lastName,
      email: registerData.email,
      phone: registerData.phone,
      password: registerData.password
    });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg p-0 overflow-hidden">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-8 text-white">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold">خوش آمدید</DialogTitle>
            <DialogDescription className="text-center text-blue-100 mt-2">
              به پنل کاربری تله‌کام سنتر وارد شوید
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="p-8">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 h-12 bg-gray-100 rounded-xl p-1">
              <TabsTrigger value="login" className="rounded-lg font-medium data-[state=active]:bg-white data-[state=active]:shadow-md">ورود به حساب</TabsTrigger>
              <TabsTrigger value="register" className="rounded-lg font-medium data-[state=active]:bg-white data-[state=active]:shadow-md">ثبت نام</TabsTrigger>
            </TabsList>

          {/* Login Tab */}
          <TabsContent value="login" className="space-y-6 mt-8">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="email" className="text-gray-700 font-medium">آدرس ایمیل</Label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    placeholder="example@company.com"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                    className="h-12 pl-12 pr-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                    required
                  />
                  <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="password" className="text-gray-700 font-medium">رمز عبور</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="رمز عبور خود را وارد کنید"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    className="h-12 pl-12 pr-12 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                    required
                  />
                  <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 w-8 h-8 hover:bg-gray-100 rounded-lg"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4 text-gray-500" />
                    ) : (
                      <Eye className="w-4 h-4 text-gray-500" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <a href="#" className="text-sm text-blue-600 hover:text-blue-700 hover:underline font-medium">
                  فراموشی رمز عبور؟
                </a>
              </div>

              <Button type="submit" className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl font-medium shadow-md transition-all">
                ورود به حساب کاربری
              </Button>
            </form>
          </TabsContent>

          {/* Register Tab */}
          <TabsContent value="register" className="space-y-6 mt-8">
            <form onSubmit={handleRegister} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3">
                  <Label htmlFor="firstName" className="text-gray-700 font-medium">نام</Label>
                  <div className="relative">
                    <Input
                      id="firstName"
                      placeholder="نام"
                      value={registerData.firstName}
                      onChange={(e) => setRegisterData({ ...registerData, firstName: e.target.value })}
                      className="h-12 pl-12 pr-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                      required
                    />
                    <User className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="lastName" className="text-gray-700 font-medium">نام خانوادگی</Label>
                  <div className="relative">
                    <Input
                      id="lastName"
                      placeholder="نام خانوادگی"
                      value={registerData.lastName}
                      onChange={(e) => setRegisterData({ ...registerData, lastName: e.target.value })}
                      className="h-12 pl-12 pr-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                      required
                    />
                    <User className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="registerEmail" className="text-gray-700 font-medium">آدرس ایمیل</Label>
                <div className="relative">
                  <Input
                    id="registerEmail"
                    type="email"
                    placeholder="example@company.com"
                    value={registerData.email}
                    onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                    className="h-12 pl-12 pr-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                    required
                  />
                  <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="phone" className="text-gray-700 font-medium">شماره تماس</Label>
                <div className="relative">
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    value={registerData.phone}
                    onChange={(e) => setRegisterData({ ...registerData, phone: e.target.value })}
                    className="h-12 pl-12 pr-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                    required
                  />
                  <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="registerPassword" className="text-gray-700 font-medium">رمز عبور</Label>
                <div className="relative">
                  <Input
                    id="registerPassword"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="رمز عبور قوی انتخاب کنید"
                    value={registerData.password}
                    onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                    className="h-12 pl-12 pr-12 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                    required
                  />
                  <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 w-8 h-8 hover:bg-gray-100 rounded-lg"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4 text-gray-500" />
                    ) : (
                      <Eye className="w-4 h-4 text-gray-500" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="confirmPassword" className="text-gray-700 font-medium">تأیید رمز عبور</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="رمز عبور را مجدداً وارد کنید"
                    value={registerData.confirmPassword}
                    onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                    className="h-12 pl-12 pr-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 bg-gray-50 focus:bg-white transition-all"
                    required
                  />
                  <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>

              <Button type="submit" className="w-full h-12 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-xl font-medium shadow-md transition-all">
                ایجاد حساب کاربری
              </Button>
            </form>
          </TabsContent>
        </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}