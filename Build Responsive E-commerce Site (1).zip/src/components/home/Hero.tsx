import React, { useState, useEffect } from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent } from '../ui/card';
import { 
  ArrowLeft, 
  ArrowRight,
  ShoppingBag, 
  Truck, 
  Shield, 
  HeadphonesIcon,
  Star,
  Smartphone,
  Headphones,
  Battery,
  Wifi,
  Zap,
  Award,
  Users,
  Phone,
  Settings,
  CheckCircle,
  Globe,
  CreditCard
} from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface HeroSlide {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  icon: React.ElementType;
  badge?: string;
  buttonText: string;
  buttonAction: () => void;
  bgGradient: string;
}

interface HeroProps {
  onNavigate?: (page: string) => void;
}

export function Hero({ onNavigate }: HeroProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides: HeroSlide[] = [
    {
      id: 1,
      title: "سیستم‌های تلفنی پیشرفته",
      subtitle: "پاناسونیک، زیمنز و VoIP",
      description: "مجموعه کاملی از سیستم‌های تلفنی حرفه‌ای، سنترال‌های دیجیتال و راه‌حل‌های ارتباطی برای شرکت‌ها و مراکز تماس",
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjBwaG9uZSUyMHN5c3RlbXxlbnwxfHx8fDE3NTc1MDA4Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Phone,
      badge: "حرفه‌ای",
      buttonText: "مشاهده سیستم‌ها",
      buttonAction: () => onNavigate?.('phones'),
      bgGradient: "from-blue-900 via-indigo-900 to-purple-900"
    },
    {
      id: 2,
      title: "لوازم جانبی و اکسسوری",
      subtitle: "برای تمام سیستم‌های تلفنی",
      description: "انواع لوازم جانبی شامل هدست، آداپتور، کابل‌ها، میکروفون کنفرانس و تجهیزات شبکه با کیفیت بالا",
      image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjBhY2Nlc3NvcmllcyUyMGhlYWRzZXR8ZW58MXx8fHwxNzU3NTAwODQyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Headphones,
      badge: "باکیفیت",
      buttonText: "مشاهده اکسسوری‌ها",
      buttonAction: () => onNavigate?.('accessories'),
      bgGradient: "from-emerald-700 via-teal-700 to-cyan-700"
    },
    {
      id: 3,
      title: "خدمات نصب و پشتیبانی",
      subtitle: "با متخصصان مجرب",
      description: "نصب، راه‌اندازی و نگهداری سیستم‌های تلفنی با ضمانت کتبی توسط تکنسین‌های مجرب و با تجهیزات مدرن",
      image: "https://images.unsplash.com/photo-1581092921461-eab62e97a780?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobmljaWFuJTIwcGhvbmUlMjBzeXN0ZW18ZW58MXx8fHwxNzU3NTAwODQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Settings,
      badge: "ضمانت",
      buttonText: "خدمات فنی",
      buttonAction: () => onNavigate?.('support'),
      bgGradient: "from-violet-800 via-purple-800 to-indigo-800"
    }
  ];

  // Auto-advance slides
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const currentSlideData = slides[currentSlide];
  const IconComponent = currentSlideData.icon;

  return (
    <section className="relative overflow-hidden">
      {/* Main Hero Slider */}
      <div className={`relative bg-gradient-to-br ${currentSlideData.bgGradient} min-h-[700px] transition-all duration-1000`}>
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-20 w-32 h-32 bg-white rounded-full blur-xl"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-orange-300 rounded-full blur-2xl"></div>
          <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-blue-300 rounded-full blur-xl"></div>
        </div>

        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-black/30 z-10" />
          <ImageWithFallback
            src={currentSlideData.image}
            alt={currentSlideData.title}
            className="w-full h-full object-cover opacity-20"
          />
        </div>

        <div className="relative z-20 container mx-auto px-4 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center min-h-[500px]">
            {/* Content */}
            <div className="space-y-8 text-white text-right">
              {currentSlideData.badge && (
                <Badge className="bg-orange-500 text-white px-6 py-2 text-lg rounded-full">
                  {currentSlideData.badge}
                </Badge>
              )}
              
              <div className="space-y-6">
                <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                  {currentSlideData.title}
                </h1>
                <h2 className="text-2xl lg:text-4xl text-orange-300 font-semibold">
                  {currentSlideData.subtitle}
                </h2>
                <p className="text-xl lg:text-2xl text-gray-200 leading-relaxed max-w-2xl">
                  {currentSlideData.description}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-6">
                <Button 
                  size="lg" 
                  className="text-xl px-10 py-4 bg-orange-500 hover:bg-orange-600 rounded-2xl shadow-2xl transform hover:scale-105 transition-all"
                  onClick={currentSlideData.buttonAction}
                >
                  <ShoppingBag className="ml-3 w-6 h-6" />
                  {currentSlideData.buttonText}
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-xl px-10 py-4 border-2 border-white text-white hover:bg-white hover:text-gray-900 rounded-2xl"
                  onClick={() => onNavigate?.('articles')}
                >
                  راهنمای خرید
                  <ArrowLeft className="mr-3 w-6 h-6" />
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-wrap items-center gap-8 pt-6">
                <div className="flex items-center gap-3 text-lg">
                  <div className="bg-yellow-500 p-2 rounded-full">
                    <Star className="w-5 h-5 text-white fill-current" />
                  </div>
                  <span className="text-gray-200">رضایت ۹۵٪ مشتریان</span>
                </div>
                <div className="flex items-center gap-3 text-lg">
                  <div className="bg-green-500 p-2 rounded-full">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-200">+۱۰ هزار مشتری</span>
                </div>
                <div className="flex items-center gap-3 text-lg">
                  <div className="bg-blue-500 p-2 rounded-full">
                    <Award className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-200">۱۰ سال تجربه</span>
                </div>
              </div>
            </div>

            {/* Visual Element */}
            <div className="relative">
              <div className="relative bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
                <div className="text-center space-y-8">
                  <div className="bg-gradient-to-br from-orange-400 to-orange-600 w-32 h-32 rounded-full flex items-center justify-center mx-auto shadow-2xl">
                    <IconComponent className="w-16 h-16 text-white" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6 text-lg text-gray-200">
                    <div className="flex flex-col items-center gap-3 bg-white/10 p-4 rounded-2xl">
                      <Shield className="w-8 h-8 text-green-400" />
                      <span className="font-semibold">ضمانت اصالت</span>
                    </div>
                    <div className="flex flex-col items-center gap-3 bg-white/10 p-4 rounded-2xl">
                      <Truck className="w-8 h-8 text-blue-400" />
                      <span className="font-semibold">ارسال سریع</span>
                    </div>
                    <div className="flex flex-col items-center gap-3 bg-white/10 p-4 rounded-2xl">
                      <Award className="w-8 h-8 text-yellow-400" />
                      <span className="font-semibold">کیفیت برتر</span>
                    </div>
                    <div className="flex flex-col items-center gap-3 bg-white/10 p-4 rounded-2xl">
                      <Phone className="w-8 h-8 text-purple-400" />
                      <span className="font-semibold">پشتیبانی ۲۴/۷</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Slider Controls */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-30">
          <div className="flex items-center gap-6 bg-white/20 backdrop-blur-md rounded-2xl p-4">
            <Button
              variant="outline"
              size="icon"
              onClick={prevSlide}
              className="bg-white/20 border-white/30 hover:bg-white/40 text-white rounded-xl w-12 h-12"
            >
              <ArrowRight className="w-5 h-5" />
            </Button>
            
            <div className="flex gap-3">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-4 h-4 rounded-full transition-all duration-300 ${
                    index === currentSlide ? 'bg-orange-500 scale-125' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
            
            <Button
              variant="outline"
              size="icon"
              onClick={nextSlide}
              className="bg-white/20 border-white/30 hover:bg-white/40 text-white rounded-xl w-12 h-12"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gradient-to-l from-gray-50 to-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">چرا هوشمند زمان پارت؟</h2>
            <p className="text-xl text-gray-600">مزایای خرید از ما</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group">
              <CardContent className="p-8 text-center space-y-6">
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                  <Truck className="w-10 h-10 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">ارسال سریع</h3>
                <p className="text-gray-600">ارسال رایگان در کمترین زمان ممکن</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group">
              <CardContent className="p-8 text-center space-y-6">
                <div className="bg-gradient-to-br from-green-100 to-green-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                  <Shield className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">ضمانت اصالت</h3>
                <p className="text-gray-600">تضمین ۱۰۰٪ اصالت تمامی محصولات</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group">
              <CardContent className="p-8 text-center space-y-6">
                <div className="bg-gradient-to-br from-purple-100 to-purple-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                  <HeadphonesIcon className="w-10 h-10 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">پشتیبانی ۲۴/۷</h3>
                <p className="text-gray-600">آماده پاسخگویی در تمام ساعات</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group">
              <CardContent className="p-8 text-center space-y-6">
                <div className="bg-gradient-to-br from-orange-100 to-orange-200 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                  <Settings className="w-10 h-10 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">تعمیرات تخصصی</h3>
                <p className="text-gray-600">خدمات تعمیرات با قطعات اصل</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Statistics Section */}
      <div className="bg-gradient-to-l from-orange-500 to-orange-600 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center text-white">
            <div className="space-y-2">
              <div className="text-4xl font-bold">+۱۰K</div>
              <div className="text-orange-100">مشتری راضی</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold">+۵K</div>
              <div className="text-orange-100">محصول</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold">۱۰</div>
              <div className="text-orange-100">سال تجربه</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold">۹۵٪</div>
              <div className="text-orange-100">رضایت</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}