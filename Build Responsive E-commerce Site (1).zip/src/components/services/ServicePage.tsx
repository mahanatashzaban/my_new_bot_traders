import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { 
  CheckCircle, 
  Phone, 
  Settings, 
  Shield, 
  Zap,
  Award,
  Users,
  Wrench
} from 'lucide-react';
import { Badge } from '../ui/badge';

interface ServicePageProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  features?: string[];
  benefits?: string[];
}

export function ServicePage({ title, description, icon, features, benefits }: ServicePageProps) {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-gradient-to-br from-blue-100 to-blue-200 mb-6">
              {icon || <Settings className="w-12 h-12 text-blue-600" />}
            </div>
            <h1 className="text-4xl font-bold text-gray-800 mb-4">{title}</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              {description}
            </p>
          </div>

          {/* Features */}
          {features && features.length > 0 && (
            <Card className="border-0 shadow-lg mb-8">
              <CardHeader>
                <CardTitle className="text-2xl">ویژگی‌های خدمات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Benefits */}
          {benefits && benefits.length > 0 && (
            <Card className="border-0 shadow-lg mb-8">
              <CardHeader>
                <CardTitle className="text-2xl">مزایای استفاده از خدمات ما</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="bg-blue-100 p-2 rounded-lg">
                          <Award className="w-5 h-5 text-blue-600" />
                        </div>
                        <h3 className="font-bold text-gray-800">مزیت {index + 1}</h3>
                      </div>
                      <p className="text-gray-700 text-sm leading-relaxed">{benefit}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Service Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-br from-green-100 to-green-200 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Zap className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">سرعت بالا</h3>
                <p className="text-gray-600 leading-relaxed">
                  اجرای سریع و به موقع پروژه‌ها با تیم متخصص
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Shield className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">ضمانت کیفیت</h3>
                <p className="text-gray-600 leading-relaxed">
                  گارانتی کامل بر روی تمامی خدمات ارائه شده
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-br from-purple-100 to-purple-200 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Users className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">تیم متخصص</h3>
                <p className="text-gray-600 leading-relaxed">
                  کارشناسان با تجربه و آموزش دیده
                </p>
              </CardContent>
            </Card>
          </div>

          {/* CTA Section */}
          <Card className="border-0 shadow-xl bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                آماده همکاری با شما هستیم
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                برای دریافت مشاوره رایگان و اطلاعات بیشتر با ما تماس بگیرید
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 text-white rounded-xl px-8 py-6"
                  onClick={() => window.location.href = 'tel:09120282845'}
                >
                  <Phone className="w-5 h-5 ml-2" />
                  تماس با ما: ۰۹۱۲۰۲۸۲۸۴۵
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-orange-600 text-orange-600 hover:bg-orange-50 rounded-xl px-8 py-6"
                  onClick={() => window.location.href = 'tel:02146054754'}
                >
                  <Phone className="w-5 h-5 ml-2" />
                  تلفن: ۰۲۱-۴۶۰۵۴۷۵۴
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
