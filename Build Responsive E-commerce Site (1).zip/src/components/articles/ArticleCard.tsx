import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Skeleton } from '../ui/skeleton';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Calendar, 
  User, 
  Eye,
  Tag
} from 'lucide-react';

interface ArticleCardProps {
  id: string;
  title: string;
  excerpt: string;
  image?: string;
  author: string;
  publishDate: string;
  readTime: number;
  tags: string[];
  likes: number;
  comments: number;
  views: number;
  isLiked?: boolean;
  onLike?: (id: string) => void;
  onShare?: (id: string) => void;
  onReadMore?: (id: string) => void;
  loading?: boolean;
}

export function ArticleCard({
  id,
  title,
  excerpt,
  image,
  author,
  publishDate,
  readTime,
  tags,
  likes,
  comments,
  views,
  isLiked = false,
  onLike,
  onShare,
  onReadMore,
  loading = false
}: ArticleCardProps) {
  if (loading) {
    return (
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <Skeleton className="w-full h-48" />
          <div className="p-6 space-y-4">
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
            <div className="flex gap-2">
              <Skeleton className="h-6 w-16" />
              <Skeleton className="h-6 w-20" />
            </div>
            <div className="flex justify-between">
              <Skeleton className="h-8 w-24" />
              <Skeleton className="h-8 w-16" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 group">
      <CardContent className="p-0">
        {/* Image */}
        <div className="relative overflow-hidden">
          {image ? (
            <img
              src={image}
              alt={title}
              className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <Skeleton className="w-full h-48" />
          )}
          
          {/* Views Badge */}
          <div className="absolute top-2 right-2">
            <Badge variant="secondary" className="text-xs bg-black/50 text-white">
              <Eye className="w-3 h-3 ml-1" />
              {new Intl.NumberFormat('fa-IR').format(views)}
            </Badge>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                <Tag className="w-3 h-3 ml-1" />
                #{tag}
              </Badge>
            ))}
          </div>

          {/* Title */}
          <h3 
            className="text-lg line-clamp-2 hover:text-primary cursor-pointer transition-colors text-right"
            onClick={() => onReadMore?.(id)}
          >
            {title}
          </h3>

          {/* Excerpt */}
          <p className="text-gray-600 line-clamp-3 text-sm leading-relaxed text-right">
            {excerpt}
          </p>

          {/* Meta Info */}
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <User className="w-4 h-4" />
                <span>{author}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{publishDate}</span>
              </div>
            </div>
            <span>{readTime} دقیقه مطالعه</span>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                className={`gap-2 ${isLiked ? 'text-red-500' : ''}`}
                onClick={() => onLike?.(id)}
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500' : ''}`} />
                {new Intl.NumberFormat('fa-IR').format(likes)}
              </Button>
              
              <Button variant="ghost" size="sm" className="gap-2">
                <MessageCircle className="w-4 h-4" />
                {new Intl.NumberFormat('fa-IR').format(comments)}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onShare?.(id)}
              >
                <Share2 className="w-4 h-4" />
              </Button>
            </div>

            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onReadMore?.(id)}
            >
              ادامه مطلب
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}