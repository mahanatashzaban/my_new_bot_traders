import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Heart, 
  Share2, 
  Eye, 
  MessageCircle,
  Calendar,
  User,
  Clock
} from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface Article {
  id: string;
  title: string;
  excerpt: string;
  content?: string;
  image?: string;
  author: string;
  publishDate: string;
  readTime: number;
  tags: string[];
  likes: number;
  comments: number;
  views: number;
  isLiked?: boolean;
}

interface ArticleDetailModalProps {
  article: Article | null;
  open: boolean;
  onClose: () => void;
  onLike?: (articleId: string) => void;
  onShare?: (articleId: string) => void;
}

export function ArticleDetailModal({ article, open, onClose, onLike, onShare }: ArticleDetailModalProps) {
  if (!article) return null;

  const fullContent = article.content || `
    <p>${article.excerpt}</p>
    <br/>
    <h2>مقدمه</h2>
    <p>در این مقاله به بررسی جامع ${article.title} می‌پردازیم. سیستم‌های تلفنی مدرن یکی از اصلی‌ترین نیازهای هر سازمان و شرکتی است که به دنبال برقراری ارتباطات موثر و کارآمد است.</p>
    <br/>
    <h2>ویژگی‌های اصلی</h2>
    <p>سیستم‌های تلفنی امروزی دارای قابلیت‌های پیشرفته‌ای هستند که شامل مواردی چون مدیریت تماس‌ها، ضبط مکالمات، انتقال تماس هوشمند، و یکپارچه‌سازی با سیستم‌های CRM می‌شود.</p>
    <br/>
    <h2>مزایا و کاربردها</h2>
    <p>استفاده از سیستم‌های تلفنی حرفه‌ای می‌تواند به افزایش بهره‌وری، کاهش هزینه‌های ارتباطی، و بهبود خدمات مشتریان کمک کند. این سیستم‌ها در صنایع مختلف از جمله بانکداری، بیمارستان‌ها، مراکز تماس، و شرکت‌های بزرگ کاربرد دارند.</p>
    <br/>
    <h2>نتیجه‌گیری</h2>
    <p>با توجه به پیشرفت‌های تکنولوژی در حوزه ارتباطات، انتخاب یک سیستم تلفنی مناسب می‌تواند تاثیر قابل توجهی بر موفقیت کسب و کار شما داشته باشد. مشاوره با کارشناسان این حوزه برای انتخاب بهترین راهکار توصیه می‌شود.</p>
  `;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-right">{article.title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Article Header */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 border-b pb-4">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>{article.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{article.publishDate}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>{article.readTime} دقیقه مطالعه</span>
            </div>
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              <span>{article.views.toLocaleString('fa-IR')} بازدید</span>
            </div>
          </div>

          {/* Featured Image */}
          {article.image && (
            <div className="relative h-96 rounded-2xl overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
              <ImageWithFallback
                src={article.image}
                alt={article.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {article.tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="text-sm">
                {tag}
              </Badge>
            ))}
          </div>

          {/* Article Content */}
          <div 
            className="prose prose-lg max-w-none text-right leading-relaxed"
            style={{ direction: 'rtl' }}
            dangerouslySetInnerHTML={{ __html: fullContent }}
          />

          {/* Actions */}
          <div className="flex items-center gap-4 pt-6 border-t">
            <Button
              variant={article.isLiked ? 'default' : 'outline'}
              onClick={() => onLike && onLike(article.id)}
              className="flex items-center gap-2"
            >
              <Heart className={`w-4 h-4 ${article.isLiked ? 'fill-current' : ''}`} />
              <span>{article.likes.toLocaleString('fa-IR')} پسندیدن</span>
            </Button>
            
            <Button
              variant="outline"
              onClick={() => onShare && onShare(article.id)}
              className="flex items-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              <span>اشتراک‌گذاری</span>
            </Button>
            
            <div className="flex items-center gap-2 text-gray-600 mr-auto">
              <MessageCircle className="w-4 h-4" />
              <span>{article.comments.toLocaleString('fa-IR')} نظر</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
