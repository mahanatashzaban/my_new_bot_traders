import React from 'react';
import { ArticleCard } from './ArticleCard';

interface Article {
  id: string;
  title: string;
  excerpt: string;
  image?: string;
  author: string;
  publishDate: string;
  readTime: number;
  tags: string[];
  likes: number;
  comments: number;
  views: number;
  isLiked?: boolean;
}

interface ArticleGridProps {
  articles: Article[];
  loading?: boolean;
  onLike?: (id: string) => void;
  onShare?: (id: string) => void;
  onReadMore?: (id: string) => void;
}

export function ArticleGrid({
  articles,
  loading = false,
  onLike,
  onShare,
  onReadMore
}: ArticleGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, index) => (
          <ArticleCard
            key={index}
            id=""
            title=""
            excerpt=""
            author=""
            publishDate=""
            readTime={0}
            tags={[]}
            likes={0}
            comments={0}
            views={0}
            loading={true}
          />
        ))}
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">مقاله‌ای یافت نشد</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles.map((article) => (
        <ArticleCard
          key={article.id}
          {...article}
          onLike={onLike}
          onShare={onShare}
          onReadMore={onReadMore}
        />
      ))}
    </div>
  );
}