import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Label } from '../ui/label';
import { Send, MessageSquare, Phone, Mail, User } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Message {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  date: string;
}

export function SurveyForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !email || !message) {
      toast.error('لطفا تمام فیلدهای ضروری را پر کنید');
      return;
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      name,
      email,
      phone,
      message,
      date: new Date().toLocaleDateString('fa-IR'),
    };

    setMessages([newMessage, ...messages]);
    
    // Reset form
    setName('');
    setEmail('');
    setPhone('');
    setMessage('');
    
    toast.success('پیام شما با موفقیت ارسال شد');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">فرم نظرسنجی</h1>
            <p className="text-xl text-gray-600">
              نظرات و پیشنهادات شما برای ما ارزشمند است
            </p>
          </div>

          {/* Contact Form */}
          <Card className="border-0 shadow-lg mb-12">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-xl">
              <CardTitle className="text-2xl text-white">ارسال پیام</CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-right block">
                      نام و نام خانوادگی <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="name"
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="نام خود را وارد کنید"
                        className="h-12 pr-12 rounded-xl border-2 text-right"
                        required
                      />
                      <User className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-right block">
                      ایمیل <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="ایمیل خود را وارد کنید"
                        className="h-12 pr-12 rounded-xl border-2 text-right"
                        required
                      />
                      <Mail className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-right block">
                    شماره تماس
                  </Label>
                  <div className="relative">
                    <Input
                      id="phone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="شماره تماس خود را وارد کنید"
                      className="h-12 pr-12 rounded-xl border-2 text-right"
                    />
                    <Phone className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message" className="text-right block">
                    پیام شما <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Textarea
                      id="message"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="نظرات و پیشنهادات خود را بنویسید..."
                      className="min-h-[150px] pr-12 rounded-xl border-2 text-right resize-none"
                      required
                    />
                    <MessageSquare className="absolute right-4 top-4 text-gray-400 w-5 h-5" />
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 rounded-xl h-14 shadow-lg"
                >
                  <Send className="w-5 h-5 ml-2" />
                  ارسال پیام
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-white">
              <CardContent className="p-8 text-center">
                <div className="bg-orange-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">تماس با ما</h3>
                <p className="text-gray-600 mb-2">۰۹۱۲۰۲۸۲۸۴۵</p>
                <p className="text-gray-600">۰۲۱۴۶۰۵۴۷۵۴</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-white">
              <CardContent className="p-8 text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">ایمیل</h3>
                <p className="text-gray-600">info@hzp.com</p>
              </CardContent>
            </Card>
          </div>

          {/* Submitted Messages */}
          {messages.length > 0 && (
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-gray-800 text-center mb-8">پیام‌های ارسال شده</h2>
              {messages.map((msg) => (
                <Card key={msg.id} className="border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-800">{msg.name}</h3>
                        <p className="text-sm text-gray-500">{msg.email}</p>
                        {msg.phone && <p className="text-sm text-gray-500">{msg.phone}</p>}
                      </div>
                      <span className="text-sm text-gray-500">{msg.date}</span>
                    </div>
                    <p className="text-gray-600 leading-relaxed">{msg.message}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
