// WARNING: In production, API credentials should be stored securely on a backend server
// This is a demo implementation - DO NOT expose credentials in frontend code in production

const API_CONFIG = {
  applicationId: 'pg3kr',
  accessPassword: 'xpS5696lAUWjbuLjFjJG4lxfp8nJ4YthOBEKy8rjwqVgHGPolb',
  refreshToken: 'C9L3ISgdGrUMuk415pVj5Xgr2iMAZolvm4S1OieBmoy6foqeOmm1C18v85G7gLWaxVLy2Lt3mhJvY1aw8qKLiEhXzL7pUjqGSSsi',
};

let currentApiKey = 'MBMpuXxJfC0WlvgSBgGc9h3MZkWMmnffDeRM2zxL9FZjCebLTL37LVgjbdyQaAjGOLtNg8Nl3MDoHh99xyptSj9npGMmTRXGzaob';
let isInitialized = false;

// Initialize and refresh token on first use
export async function initializeApi() {
  if (isInitialized) return { success: true };
  
  console.log('🚀 Initializing API...');
  const result = await refreshApiKey();
  
  if (result.success) {
    isInitialized = true;
    console.log('✅ API initialized successfully');
  } else {
    console.warn('⚠️ API initialization failed, will try on first request');
  }
  
  return result;
}

export async function refreshApiKey() {
  try {
    console.log('🔄 Refreshing API key...');
    console.log('📤 Request payload:', {
      application_id: API_CONFIG.applicationId,
      access_password: API_CONFIG.accessPassword.substring(0, 10) + '...',
      refresh_token: API_CONFIG.refreshToken.substring(0, 10) + '...',
    });

    const response = await fetch('https://core.paystar.ir/api/open-banking/application/refresh-api-key', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        application_id: API_CONFIG.applicationId,
        access_password: API_CONFIG.accessPassword,
        refresh_token: API_CONFIG.refreshToken,
      }),
    });

    console.log('📥 Response status:', response.status, response.statusText);

    if (!response.ok) {
      console.error('❌ HTTP Error:', response.status, response.statusText);
      const errorText = await response.text();
      console.error('Error body:', errorText);
      return { success: false, message: `خطای HTTP: ${response.status}` };
    }

    const data = await response.json();
    console.log('📥 Refresh response:', data);
    
    if (data.status === 1 && data.data && data.data.api_key) {
      currentApiKey = data.data.api_key;
      console.log('✅ New API key set successfully');
      return { success: true, apiKey: data.data.api_key };
    }
    
    console.error('❌ Failed to refresh token:', data);
    return { success: false, message: data.message || 'خطا در دریافت توکن جدید' };
  } catch (error: any) {
    console.error('❌ Exception during token refresh:', error);
    console.error('Error details:', {
      message: error.message,
      name: error.name,
      stack: error.stack
    });
    return { success: false, message: `خطا: ${error.message || 'خطا در برقراری ارتباط با سرور'}` };
  }
}

export async function validateIban(iban: string) {
  try {
    // Try to initialize API if not already done
    if (!isInitialized) {
      console.log('⚙️ API not initialized, initializing now...');
      await initializeApi();
    }

    console.log('🔍 Validating IBAN:', iban);
    console.log('🔑 Using API Key:', currentApiKey.substring(0, 20) + '...');

    const response = await fetch('https://core.paystar.ir/api/open-banking/service/bank-inquiry/iban-inquiry', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${currentApiKey}`,
      },
      body: JSON.stringify({
        application_id: API_CONFIG.applicationId,
        access_password: API_CONFIG.accessPassword,
        iban: iban,
      }),
    });

    console.log('📥 IBAN validation response status:', response.status);

    const data = await response.json();
    console.log('📥 IBAN validation data:', data);
    
    // Check for token expiry (status 5 or message contains expired token)
    if (data.status === 5 || (data.message && data.message.includes('منقضی'))) {
      console.log('⚠️ Token expired, refreshing...');
      const refreshResult = await refreshApiKey();
      if (refreshResult.success) {
        console.log('✅ Token refreshed successfully, retrying IBAN validation...');
        return validateIban(iban);
      } else {
        console.error('❌ Failed to refresh token:', refreshResult.message);
        return { status: 0, message: 'خطا در بازیابی توکن. لطفا دوباره تلاش کنید.' };
      }
    }
    
    return data;
  } catch (error: any) {
    console.error('❌ IBAN validation error:', error);
    return { status: 0, message: `خطا: ${error.message || 'خطا در برقراری ارتباط با سرور'}` };
  }
}

export async function transferMoney(transferData: {
  deposit: string;
  destination_account: string;
  destination_firstname: string;
  destination_lastname: string;
  amount: number;
  pay_id?: string;
  description?: string;
  purpose?: string;
}) {
  try {
    const track_id = `TRK${Date.now()}${Math.random().toString(36).substr(2, 9)}`;
    
    const response = await fetch('https://core.paystar.ir/api/bank-transfer/v2/settlement', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${currentApiKey}`,
      },
      body: JSON.stringify({
        application_id: API_CONFIG.applicationId,
        access_password: API_CONFIG.accessPassword,
        transfers: [{
          amount: transferData.amount,
          deposit: transferData.deposit,
          destination_account: transferData.destination_account,
          destination_firstname: transferData.destination_firstname,
          destination_lastname: transferData.destination_lastname,
          track_id: track_id,
          pay_id: transferData.pay_id || '',
        }],
      }),
    });

    const data = await response.json();
    
    if (data.status === 5) {
      // Token expired, refresh and retry
      const refreshResult = await refreshApiKey();
      if (refreshResult.success) {
        return transferMoney(transferData);
      }
    }
    
    return { ...data, track_id };
  } catch (error) {
    return { status: 'fail', message: 'خطا در برقراری ارتباط با سرور' };
  }
}

export async function getTransactions(limit?: number, skip?: number) {
  try {
    const params = new URLSearchParams({
      application_id: API_CONFIG.applicationId,
      access_password: API_CONFIG.accessPassword,
    });
    
    if (limit) params.append('limit', limit.toString());
    if (skip) params.append('skip', skip.toString());

    const response = await fetch(`https://core.paystar.ir/api/bank-transfer/settlement-requests?${params}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${currentApiKey}`,
      },
    });

    const data = await response.json();
    
    if (data.status === 5) {
      // Token expired, refresh and retry
      const refreshResult = await refreshApiKey();
      if (refreshResult.success) {
        return getTransactions(limit, skip);
      }
    }
    
    return data;
  } catch (error) {
    return { status: 'fail', message: 'خطا در برقراری ارتباط با سرور' };
  }
}

export function exportToCSV(transactions: any[]) {
  const headers = ['تاریخ', 'مبلغ', 'حساب مقصد', 'نام', 'نام خانوادگی', 'وضعیت', 'کد رهگیری'];
  
  const rows = transactions.map(t => [
    t.created_at || '',
    t.amount || '',
    t.destination_account || '',
    t.destination_firstname || '',
    t.destination_lastname || '',
    t.status || '',
    t.track_id || '',
  ]);
  
  const csvContent = [
    '\uFEFF' + headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `transactions_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
