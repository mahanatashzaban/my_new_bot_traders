import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TransferForm } from './components/TransferForm';
import { TransactionHistory } from './components/TransactionHistory';
import { SplashScreen } from './components/SplashScreen';
import { ApiDebug } from './components/ApiDebug';
import { Toaster } from './components/ui/sonner';
import { Card, CardContent } from './components/ui/card';
import { Banknote, AlertTriangle, Info, TrendingUp, Shield } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from './components/ui/alert';
import { initializeApi } from './utils/api';

export default function App() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [showSplash, setShowSplash] = useState(true);
  const [apiInitialized, setApiInitialized] = useState(false);

  useEffect(() => {
    // Initialize API in background
    initializeApi().then(result => {
      setApiInitialized(result.success);
      if (!result.success) {
        console.warn('⚠️ API initialization failed, will retry on first request');
      }
    });

    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  const handleTransferComplete = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <>
      <AnimatePresence>
        {showSplash && <SplashScreen />}
      </AnimatePresence>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: showSplash ? 0 : 1 }}
        className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 p-3 sm:p-6 md:p-8"
      >
        <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
          {/* Header */}
          <motion.div 
            className="text-center space-y-3 pt-4 sm:pt-0"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div 
              className="flex items-center justify-center gap-3 mb-4"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="p-3 sm:p-4 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl shadow-lg">
                <Banknote className="h-8 w-8 sm:h-10 sm:w-10 text-white" />
              </div>
            </motion.div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl bg-gradient-to-l from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              پنل مدیریت انتقال وجه
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground">
              مدیریت انتقال وجه به حساب‌های مقصد
            </p>
          </motion.div>

        {/* API Status Info */}
        {!apiInitialized && !showSplash && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Alert className="border-2 border-blue-500 bg-blue-50">
              <Info className="h-5 w-5 text-blue-600" />
              <AlertTitle className="text-base sm:text-lg text-blue-900">🔄 در حال اتصال به سرویس</AlertTitle>
              <AlertDescription className="text-sm sm:text-base text-blue-800">
                اتصال اولیه برقرار نشد. هنگام وارد کردن شماره شبا، سیستم مجددا تلاش خواهد کرد. برای دیدن جزئیات، Console مرورگر (F12) را باز کنید.
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        {/* Security Warning */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Alert variant="destructive" className="border-2">
            <AlertTriangle className="h-5 w-5" />
            <AlertTitle className="text-base sm:text-lg">⚠️ هشدار مهم</AlertTitle>
            <AlertDescription className="text-sm sm:text-base">
              این برنامه به حساب بانکی واقعی متصل است و انتقال وجه واقعی انجام می‌دهد. لطفا با احتیاط استفاده کنید.
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Stats Cards */}
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="pt-6 text-center">
              <Shield className="h-8 w-8 mx-auto mb-2 text-blue-600" />
              <p className="text-sm text-blue-800">امن و معتبر</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="pt-6 text-center">
              <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <p className="text-sm text-green-800">سریع و آسان</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="pt-6 text-center">
              <Info className="h-8 w-8 mx-auto mb-2 text-purple-600" />
              <p className="text-sm text-purple-800">پشتیبانی 24/7</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Transaction History Button */}
        <motion.div 
          className="flex justify-end"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <TransactionHistory refreshTrigger={refreshTrigger} />
        </motion.div>

        {/* Transfer Form */}
        <TransferForm onTransferComplete={handleTransferComplete} />

        {/* Footer Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="bg-white/80 backdrop-blur-sm border-2">
            <CardContent className="pt-6">
              <div className="space-y-3 text-sm sm:text-base text-muted-foreground">
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0"></div>
                  <p>
                    <strong className="text-foreground">شماره شبا:</strong> باید 26 کاراکتر و با IR شروع شود
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-2 h-2 rounded-full bg-teal-500 flex-shrink-0"></div>
                  <p>
                    <strong className="text-foreground">اعتبارسنجی خودکار:</strong> با وارد کردن شماره شبا، صحت آن بررسی و نام صاحب حساب به صورت خودکار پر می‌شود
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-2 h-2 rounded-full bg-cyan-500 flex-shrink-0"></div>
                  <p>
                    <strong className="text-foreground">تاریخچه:</strong> تمام تراکنش‌های انجام شده در بخش تاریخچه قابل مشاهده و خروجی هستند
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0"></div>
                  <p>
                    <strong className="text-foreground">خروجی CSV:</strong> امکان دانلود تاریخچه تراکنش‌ها در قالب فایل CSV
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Footer */}
        <motion.div 
          className="text-center text-xs sm:text-sm text-muted-foreground py-4 pb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          <p className="flex items-center justify-center gap-2 flex-wrap">
            <span>پشتیبانی از Paystar API</span>
            <span>•</span>
            <span>نسخه 1.0.0</span>
          </p>
        </motion.div>
      </div>

      <Toaster position="top-center" richColors />
      </motion.div>

      {/* Debug Panel */}
      <ApiDebug />
    </>
  );
}
