# 🔧 خلاصه رفع خطای "خطا در بازیابی توکن"

## ❌ خطای فعلی

```
خطا در بازیابی توکن: خطا در برقراری ارتباط با سرور
```

---

## ✅ تغییرات اعمال شده

### 1. افزودن Console Logging دقیق

همه عملیات API حالا log می‌شوند:

```javascript
🚀 Initializing API...
📤 Request payload: ...
📥 Response status: 200 OK
✅ New API key set successfully
```

یا در صورت خطا:

```javascript
❌ HTTP Error: 401
❌ Exception during token refresh
Error details: { message: "...", ... }
```

### 2. Initialize خودکار در App

برنامه هنگام شروع، خودکار سعی می‌کند API را initialize کند:

```typescript
// در App.tsx
useEffect(() => {
  initializeApi().then(result => {
    setApiInitialized(result.success);
  });
}, []);
```

### 3. نمایش وضعیت API به کاربر

اگر initialize موفق نباشد، یک Alert آبی نمایش داده می‌شود:

```
🔄 در حال اتصال به سرویس
اتصال اولیه برقرار نشد. هنگام وارد کردن شماره شبا، 
سیستم مجددا تلاش خواهد کرد.
```

### 4. افزودن Debug Panel

یک دکمه Debug در گوشه پایین چپ اضافه شده که:
- ✅ API را به صورت دستی تست می‌کند
- ✅ نتیجه را با جزئیات نمایش می‌دهد
- ✅ راهنمای عیب‌یابی ارائه می‌دهد

### 5. مستندات کامل عیب‌یابی

سه فایل جدید اضافه شده:
- **TROUBLESHOOTING.md** - راهنمای کامل عیب‌یابی
- **TEST_API.md** - تست دستی API در Console
- **ERROR_FIX_SUMMARY.md** - این فایل!

---

## 🔍 نحوه عیب‌یابی

### گام 1: باز کردن Console

کلید `F12` را بزنید و به tab "Console" بروید.

### گام 2: بررسی خطاها

دنبال این‌ها بگردید:

#### ✅ خروجی موفق:
```
🚀 Initializing API...
📤 Request payload: ...
📥 Response status: 200 OK
✅ New API key set successfully
✅ API initialized successfully
```

#### ❌ خطای CORS:
```
Access to fetch at 'https://core.paystar.ir/...' 
has been blocked by CORS policy
```
**دلیل:** مرورگر اجازه نمی‌دهد  
**راه‌حل:** نیاز به backend proxy یا تنظیمات CORS از سمت Paystar

#### ❌ خطای 401 (Unauthorized):
```
📥 Response status: 401 Unauthorized
```
**دلیل:** Credentials نادرست یا منقضی شده  
**راه‌حل:** از پنل Paystar credentials جدید بگیرید

#### ❌ خطای Network:
```
❌ Exception: TypeError: Failed to fetch
```
**دلیل:** اتصال اینترنت یا دسترسی به سرور  
**راه‌حل:** VPN، اتصال اینترنت، firewall

### گام 3: استفاده از Debug Panel

1. دکمه **Debug** در گوشه پایین چپ را بزنید
2. دکمه **"تست اتصال API"** را بزنید
3. نتیجه را مشاهده کنید

### گام 4: تست دستی

فایل **TEST_API.md** را باز کنید و کدهای تست را در Console اجرا کنید.

---

## 🎯 احتمالات و راه‌حل‌ها

### احتمال 1: CORS Issue (بیشترین احتمال)

**علائم:**
- Console: `blocked by CORS policy`
- درخواست حتی ارسال نمی‌شود

**توضیح:**
مرورگر به دلایل امنیتی اجازه نمی‌دهد که frontend مستقیماً با API سرور دیگری ارتباط برقرار کند، مگر اینکه سرور اجازه دهد (CORS headers).

**راه‌حل‌ها:**

1. **Backend Proxy (توصیه شده برای production)**
   ```
   Frontend → Backend شما → Paystar API
   ```
   مزایا:
   - ✅ امن
   - ✅ Credentials مخفی می‌مانند
   - ✅ مشکل CORS حل می‌شود

2. **درخواست از Paystar**
   - با پشتیبانی Paystar تماس بگیرید
   - بگویید که CORS را برای domain شما فعال کنند
   - Origin شما را اعلام کنید (مثلاً `http://localhost:5173` برای development)

3. **Browser Extension (فقط برای تست!)**
   - نصب extension برای disable کردن CORS
   - ⚠️ فقط برای development/test
   - ⚠️ هرگز برای production استفاده نکنید

### احتمال 2: Credentials منقضی شده

**علائم:**
- Response status: 401
- Message: "توکن احراز هویت منقضی شده است"

**راه‌حل:**
1. به پنل Paystar بروید
2. Credentials جدید بگیرید:
   - `application_id`
   - `access_password`
   - `refresh_token`
   - `api_key` (اولیه)
3. در فایل `/utils/api.ts` به‌روز کنید

### احتمال 3: مشکل شبکه

**علائم:**
- `Failed to fetch`
- `Network error`

**راه‌حل:**
1. اتصال اینترنت را بررسی کنید
2. VPN را امتحان کنید
3. Firewall/Antivirus را چک کنید
4. با browser دیگری تست کنید

### احتمال 4: Endpoint اشتباه

**علائم:**
- Response status: 404
- "Not Found"

**راه‌حل:**
1. مستندات Paystar را بخوانید
2. Endpoint را بررسی کنید:
   ```
   https://core.paystar.ir/api/open-banking/application/refresh-api-key
   ```

---

## 📋 چک‌لیست عیب‌یابی

انجام دادم:

- [ ] Console (F12) را باز کردم
- [ ] خطاها را خواندم و یادداشت کردم
- [ ] Debug Panel را امتحان کردم
- [ ] TEST_API.md را دنبال کردم
- [ ] اتصال اینترنت را بررسی کردم
- [ ] با VPN امتحان کردم
- [ ] با browser دیگری تست کردم
- [ ] Credentials را بررسی کردم
- [ ] TROUBLESHOOTING.md را خواندم

اگر همه را امتحان کردم:

- [ ] Screenshot از Console گرفتم
- [ ] با پشتیبانی Paystar تماس گرفتم
- [ ] درخواست فعال‌سازی CORS دادم
- [ ] در مورد backend proxy فکر کردم

---

## 🚀 راه‌حل سریع (اگر CORS است)

### نصب و راه‌اندازی Backend Proxy ساده

**Option 1: Node.js/Express**

```bash
npm install express cors node-fetch
```

```javascript
// server.js
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/refresh', async (req, res) => {
  try {
    const response = await fetch('https://core.paystar.ir/api/open-banking/application/refresh-api-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3001, () => console.log('Proxy running on :3001'));
```

در `/utils/api.ts` تغییر دهید:
```typescript
// از این:
const response = await fetch('https://core.paystar.ir/api/...');

// به این:
const response = await fetch('http://localhost:3001/api/refresh');
```

---

## 💡 نکات مهم

1. **Console همیشه باز باشد**
   - تمام اطلاعات مفید در Console است
   - هر خطایی را یادداشت کنید

2. **با مبلغ کم تست کنید**
   - حتی اگر کار کرد، با 1000 ریال شروع کنید

3. **Screenshot بگیرید**
   - از Console
   - از Network tab
   - از خطاها

4. **با پشتیبانی Paystar صحبت کنید**
   - آن‌ها می‌توانند کمک کنند
   - شاید نیاز به تنظیمات خاصی باشد

---

## 📞 اطلاعات تماس

**Paystar:**
- سایت: https://paystar.ir
- مستندات: https://paystar.ir/docs
- پشتیبانی: support@paystar.ir

---

## ✅ بعد از حل مشکل

وقتی کار کرد:

1. یادداشت کنید چه کاری انجام دادید
2. Screenshot از Console موفق بگیرید
3. با شماره IBAN تست بگیرید
4. تاریخچه را بررسی کنید
5. با مبلغ کم transfer کنید

---

## 📁 فایل‌های مرتبط

- 📖 **TROUBLESHOOTING.md** - راهنمای کامل و دقیق
- 🧪 **TEST_API.md** - تست دستی در Console
- 🚀 **QUICK_START.md** - راهنمای شروع سریع
- 📋 **FIXES_APPLIED.md** - تغییرات قبلی
- 📄 **README.md** - مستندات اصلی

---

**به‌روزرسانی:** 2 نوامبر 2025  
**وضعیت:** منتظر تست توسط کاربر  
**مرحله بعدی:** عیب‌یابی بر اساس خطاهای Console
