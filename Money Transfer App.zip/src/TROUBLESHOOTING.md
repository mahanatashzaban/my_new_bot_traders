# 🔧 راهنمای عیب‌یابی - خطای اتصال به سرور

## 🔴 خطا: "خطا در بازیابی توکن: خطا در برقراری ارتباط با سرور"

این خطا می‌تواند دلایل مختلفی داشته باشد:

---

## 1️⃣ بررسی Console مرورگر

### چگونه Console را باز کنیم؟
- **Chrome/Edge:** کلید `F12` یا `Ctrl+Shift+J` (Windows) / `Cmd+Option+J` (Mac)
- **Firefox:** کلید `F12` یا `Ctrl+Shift+K`
- **Safari:** `Cmd+Option+C`

### چه چیزهایی را باید بررسی کنیم؟

```
✅ موارد مثبت:
🚀 Initializing API...
📤 Request payload: ...
📥 Response status: 200 OK
✅ New API key set successfully

❌ موارد منفی:
❌ HTTP Error: 400/401/403/500
❌ CORS error
❌ Network error
❌ Failed to fetch
```

---

## 2️⃣ مشکلات احتمالی و راه‌حل‌ها

### مشکل A: خطای CORS

**علائم:**
```
Access to fetch at 'https://core.paystar.ir/...' from origin '...' 
has been blocked by CORS policy
```

**دلیل:** مرورگر اجازه نمی‌دهد درخواست به API ارسال شود.

**راه‌حل:**
1. این یک محدودیت امنیتی مرورگر است
2. باید از طریق یک backend/proxy ارسال شود
3. یا Paystar باید CORS را فعال کند
4. یا استفاده از browser extension برای disable کردن CORS (فقط برای تست!)

---

### مشکل B: خطای HTTP 401 (Unauthorized)

**علائم:**
```
📥 Response status: 401 Unauthorized
```

**دلیل:** Credentials نادرست هستند.

**راه‌حل:**
1. بررسی کنید که `application_id`, `access_password`, و `refresh_token` صحیح هستند
2. در فایل `/utils/api.ts` بررسی کنید:
   ```typescript
   const API_CONFIG = {
     applicationId: 'pg3kr',  // ✅ صحیح باشد
     accessPassword: '...',    // ✅ صحیح باشد
     refreshToken: '...',      // ✅ صحیح باشد
   };
   ```
3. اگر نامشخص است، از پنل Paystar credentials جدید بگیرید

---

### مشکل C: خطای HTTP 400 (Bad Request)

**علائم:**
```
📥 Response status: 400 Bad Request
```

**دلیل:** فرمت درخواست نادرست است.

**راه‌حل:**
1. بررسی کنید که endpoint صحیح است:
   ```
   https://core.paystar.ir/api/open-banking/application/refresh-api-key
   ```
2. بررسی کنید که body درخواست صحیح است:
   ```json
   {
     "application_id": "pg3kr",
     "access_password": "...",
     "refresh_token": "..."
   }
   ```

---

### مشکل D: خطای Network/Connection

**علائم:**
```
❌ Exception during token refresh
Error: Failed to fetch
```

**دلیل:** اتصال اینترنت قطع است یا سرور Paystar در دسترس نیست.

**راه‌حل:**
1. ✅ اتصال اینترنت را بررسی کنید
2. ✅ VPN را امتحان کنید (ممکن است IP شما بلاک شده باشد)
3. ✅ سرور Paystar را ping کنید:
   ```bash
   ping core.paystar.ir
   ```
4. ✅ با browser دیگری امتحان کنید

---

### مشکل E: Refresh Token منقضی شده

**علائم:**
```
📥 Refresh response: { status: 0, message: "..." }
```

**دلیل:** `refresh_token` خود منقضی شده است.

**راه‌حل:**
1. باید از پنل Paystar یک `refresh_token` جدید بگیرید
2. در فایل `/utils/api.ts` آن را به‌روز کنید
3. همچنین `api_key` جدید هم نیاز است

---

## 3️⃣ تست دستی API

برای اطمینان از اینکه API کار می‌کند، می‌توانید با `curl` یا Postman تست کنید:

### تست Refresh Token

```bash
curl -X POST https://core.paystar.ir/api/open-banking/application/refresh-api-key \
  -H "Content-Type: application/json" \
  -d '{
    "application_id": "pg3kr",
    "access_password": "xpS5696lAUWjbuLjFjJG4lxfp8nJ4YthOBEKy8rjwqVgHGPolb",
    "refresh_token": "C9L3ISgdGrUMuk415pVj5Xgr2iMAZolvm4S1OieBmoy6foqeOmm1C18v85G7gLWaxVLy2Lt3mhJvY1aw8qKLiEhXzL7pUjqGSSsi"
  }'
```

**پاسخ موفق:**
```json
{
  "status": 1,
  "data": {
    "api_key": "NEW_API_KEY_HERE..."
  }
}
```

**پاسخ ناموفق:**
```json
{
  "status": 0,
  "message": "دلیل خطا..."
}
```

---

## 4️⃣ راه‌حل موقت: استفاده از API Key جدید

اگر `refresh_token` کار نمی‌کند، می‌توانید یک `api_key` معتبر مستقیماً از پنل Paystar بگیرید و در کد قرار دهید:

1. به پنل Paystar بروید
2. یک `api_key` جدید بگیرید
3. در فایل `/utils/api.ts`:
   ```typescript
   let currentApiKey = 'API_KEY_JADID_SHOMA';
   ```

**⚠️ نکته:** این راه‌حل موقت است چون API key بعد از مدتی منقضی می‌شود.

---

## 5️⃣ بررسی مستندات Paystar

لینک‌های مفید:
- 📚 مستندات Paystar: https://paystar.ir/docs
- 📧 پشتیبانی Paystar: support@paystar.ir
- 💬 تلگرام پشتیبانی: (اگر دارد)

سوالات برای پشتیبانی:
1. آیا CORS برای frontend requests فعال است؟
2. آیا `refresh_token` من هنوز معتبر است؟
3. آیا IP من بلاک شده است؟
4. آیا endpoint‌ها تغییر کرده‌اند؟

---

## 6️⃣ راه‌حل حرفه‌ای: استفاده از Backend Proxy

برای production، بهتر است از یک backend استفاده کنید:

```
Frontend (React) 
    ↓
Backend (Node.js/Express)
    ↓
Paystar API
```

مزایا:
- ✅ Credentials امن می‌مانند
- ✅ مشکل CORS حل می‌شود
- ✅ کنترل بهتر روی errors
- ✅ Rate limiting
- ✅ Logging و monitoring

---

## 7️⃣ چک‌لیست کامل عیب‌یابی

- [ ] Console مرورگر را باز کنم و خطاها را بخوانم
- [ ] اتصال اینترنت را بررسی کنم
- [ ] Credentials را در `/utils/api.ts` بررسی کنم
- [ ] با curl یا Postman API را تست کنم
- [ ] با browser دیگری امتحان کنم
- [ ] VPN را امتحان کنم
- [ ] با پشتیبانی Paystar تماس بگیرم
- [ ] مستندات Paystar را دوباره بخوانم

---

## 8️⃣ کدهای وضعیت HTTP

| کد | معنی | راه‌حل |
|----|------|--------|
| 200 | OK | ✅ همه چیز خوب است |
| 400 | Bad Request | ❌ فرمت درخواست اشتباه است |
| 401 | Unauthorized | ❌ Credentials نادرست است |
| 403 | Forbidden | ❌ دسترسی ندارید |
| 404 | Not Found | ❌ Endpoint اشتباه است |
| 429 | Too Many Requests | ⚠️ خیلی زیاد درخواست فرستادید |
| 500 | Server Error | 🔥 مشکل از سمت Paystar است |

---

## 🆘 نیاز به کمک بیشتر؟

اگر همچنان مشکل دارید:

1. **Screenshot بگیرید از:**
   - Console errors (F12)
   - Network tab (F12 → Network)
   - خطای روی صفحه

2. **اطلاعات سیستم:**
   - مرورگر: Chrome/Firefox/Safari و نسخه
   - سیستم عامل: Windows/Mac/Linux
   - آیا از VPN استفاده می‌کنید؟

3. **تماس با پشتیبانی:**
   - از screenshot‌ها استفاده کنید
   - خطاهای دقیق Console را کپی کنید
   - بگویید چه کارهایی انجام داده‌اید

---

## ✅ پس از حل مشکل

وقتی مشکل حل شد:

1. Console را بررسی کنید، باید ببینید:
   ```
   ✅ API initialized successfully
   ```

2. هنگام وارد کردن IBAN:
   ```
   🔍 Validating IBAN: IR...
   📥 IBAN validation response status: 200
   📥 IBAN validation data: { status: 1, ... }
   ```

3. اگر همه چیز کار کرد:
   - ✅ تیک سبز ظاهر می‌شود
   - ✅ نام بانک نمایش داده می‌شود
   - ✅ نام صاحب حساب خودکار پر می‌شود

---

**موفق باشید! 🚀**

اگر مشکل حل شد، لطفاً در مستندات یادداشت کنید که چه کاری انجام دادید تا بعداً به درد بخورد.
