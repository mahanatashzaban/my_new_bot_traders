import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Loader2, CheckCircle2, AlertCircle, Send } from 'lucide-react';
import { validateIban, transferMoney } from '../utils/api';
import { toast } from 'sonner@2.0.3';
import { ConfirmTransferDialog } from './ConfirmTransferDialog';
import { SuccessAnimation } from './SuccessAnimation';

interface TransferFormProps {
  onTransferComplete: () => void;
}

export function TransferForm({ onTransferComplete }: TransferFormProps) {
  const [formData, setFormData] = useState({
    destinationAccount: '',
    firstName: '',
    lastName: '',
    amount: '',
    payId: '',
    description: '',
    purpose: '',
  });

  const [validatingIban, setValidatingIban] = useState(false);
  const [ibanValid, setIbanValid] = useState<boolean | null>(null);
  const [ibanInfo, setIbanInfo] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successAmount, setSuccessAmount] = useState('');

  const handleDestinationAccountChange = async (value: string) => {
    // Update destination account
    setFormData({ ...formData, destinationAccount: value, firstName: '', lastName: '' });
    setIbanValid(null);
    setIbanInfo(null);

    // Validate IBAN if it's 26 characters (Iranian IBAN format)
    if (value.length === 26 && value.toUpperCase().startsWith('IR')) {
      setValidatingIban(true);
      console.log('Validating IBAN:', value);
      const result = await validateIban(value.toUpperCase());
      console.log('Validation result:', result);
      setValidatingIban(false);

      if (result.status === 1 && result.data) {
        setIbanValid(true);
        setIbanInfo(result.data);
        
        // Auto-fill name fields
        if (result.data.owners_info && result.data.owners_info.length > 0) {
          const owner = result.data.owners_info[0];
          setFormData(prev => ({
            ...prev,
            firstName: owner.firstName || owner.first_name || '',
            lastName: owner.lastName || owner.last_name || '',
          }));
          toast.success(`شماره شبا معتبر است - ${owner.firstName || owner.first_name} ${owner.lastName || owner.last_name}`);
        } else {
          toast.success('شماره شبا معتبر است');
        }
      } else {
        setIbanValid(false);
        toast.error(result.message || 'شماره شبا نامعتبر است');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.destinationAccount || !formData.firstName || !formData.lastName || !formData.amount) {
      toast.error('لطفا تمام فیلدهای الزامی را پر کنید');
      return;
    }

    if (!ibanValid) {
      toast.error('لطفا ابتدا شماره شبا معتبر وارد کنید');
      return;
    }

    const amount = parseInt(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('مبلغ وارد شده نامعتبر است');
      return;
    }

    // Show confirmation dialog
    setShowConfirmDialog(true);
  };

  const handleConfirmTransfer = async () => {
    setShowConfirmDialog(false);
    setSubmitting(true);

    const amount = parseInt(formData.amount);

    const result = await transferMoney({
      deposit: '', // Empty since Paystar API uses admin's connected account
      destination_account: formData.destinationAccount,
      destination_firstname: formData.firstName,
      destination_lastname: formData.lastName,
      amount: amount,
      pay_id: formData.payId,
      description: formData.description,
      purpose: formData.purpose,
    });

    setSubmitting(false);

    if (result.status === 'ok' || result.status === 1) {
      setSuccessAmount(formData.amount);
      setShowSuccess(true);
      
      // Reset form after a delay
      setTimeout(() => {
        setFormData({
          destinationAccount: '',
          firstName: '',
          lastName: '',
          amount: '',
          payId: '',
          description: '',
          purpose: '',
        });
        setIbanValid(null);
        setIbanInfo(null);
      }, 1000);
      
      onTransferComplete();
    } else {
      toast.error(result.message || 'خطا در انجام انتقال وجه');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full shadow-xl border-2">
        <CardHeader className="bg-gradient-to-l from-emerald-50 to-teal-50 border-b">
          <CardTitle className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500 rounded-lg">
              <Send className="h-5 w-5 text-white" />
            </div>
            انتقال وجه
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-5">
          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Label htmlFor="destinationAccount" className="text-base">شماره شبا مقصد *</Label>
            <div className="relative">
              <Input
                id="destinationAccount"
                value={formData.destinationAccount}
                onChange={(e) => handleDestinationAccountChange(e.target.value)}
                placeholder="مثال: IR123456789012345678901234"
                className="h-12 text-base pr-12"
                required
                maxLength={26}
              />
              {validatingIban && (
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                >
                  <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
                </motion.div>
              )}
              {!validatingIban && ibanValid === true && (
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                >
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                </motion.div>
              )}
              {!validatingIban && ibanValid === false && (
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                >
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </motion.div>
              )}
            </div>
            {ibanInfo && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg"
              >
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <p className="text-sm text-green-800">
                  بانک: {ibanInfo.bank_title}
                </p>
              </motion.div>
            )}
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="space-y-2">
              <Label htmlFor="firstName" className="text-base flex items-center gap-2">
                نام صاحب حساب مقصد *
                {ibanValid && formData.firstName && (
                  <span className="text-xs text-green-600">(خودکار)</span>
                )}
              </Label>
              <Input
                id="firstName"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="نام"
                className={`h-12 text-base ${ibanValid && formData.firstName ? 'bg-green-50' : ''}`}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName" className="text-base flex items-center gap-2">
                نام خانوادگی صاحب حساب *
                {ibanValid && formData.lastName && (
                  <span className="text-xs text-green-600">(خودکار)</span>
                )}
              </Label>
              <Input
                id="lastName"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="نام خانوادگی"
                className={`h-12 text-base ${ibanValid && formData.lastName ? 'bg-green-50' : ''}`}
                required
              />
            </div>
          </motion.div>

          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Label htmlFor="amount" className="text-base">مبلغ تراکنش به ریال *</Label>
            <Input
              id="amount"
              type="number"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              placeholder="مبلغ به ریال"
              className="h-12 text-base"
              required
            />
            {formData.amount && (
              <p className="text-sm text-muted-foreground">
                {new Intl.NumberFormat('fa-IR').format(parseInt(formData.amount))} ریال
              </p>
            )}
          </motion.div>

          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Label htmlFor="payId" className="text-base">شناسه واریز (اختیاری)</Label>
            <Input
              id="payId"
              value={formData.payId}
              onChange={(e) => setFormData({ ...formData, payId: e.target.value })}
              placeholder="شناسه واریز"
              className="h-12 text-base"
            />
          </motion.div>

          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Label htmlFor="description" className="text-base">توضیحات (اختیاری)</Label>
            <Input
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="توضیحات"
              className="h-12 text-base"
            />
          </motion.div>

          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Label htmlFor="purpose" className="text-base">بابت (اختیاری)</Label>
            <Input
              id="purpose"
              value={formData.purpose}
              onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
              placeholder="بابت"
              className="h-12 text-base"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Button 
              type="submit" 
              className="w-full h-14 text-lg bg-gradient-to-l from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-lg" 
              disabled={submitting}
            >
              {submitting ? (
                <>
                  <Loader2 className="ml-2 h-5 w-5 animate-spin" />
                  در حال ارسال...
                </>
              ) : (
                <>
                  <Send className="ml-2 h-5 w-5" />
                  انتقال وجه
                </>
              )}
            </Button>
          </motion.div>
        </form>
      </CardContent>
    </Card>

    <ConfirmTransferDialog
      open={showConfirmDialog}
      onOpenChange={setShowConfirmDialog}
      onConfirm={handleConfirmTransfer}
      amount={formData.amount}
      destinationAccount={formData.destinationAccount}
      firstName={formData.firstName}
      lastName={formData.lastName}
    />

    <SuccessAnimation
      open={showSuccess}
      onOpenChange={setShowSuccess}
      amount={successAmount}
    />
    </motion.div>
  );
}
