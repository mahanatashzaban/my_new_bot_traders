import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { AlertTriangle } from 'lucide-react';

interface ConfirmTransferDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  amount: string;
  destinationAccount: string;
  firstName: string;
  lastName: string;
}

export function ConfirmTransferDialog({
  open,
  onOpenChange,
  onConfirm,
  amount,
  destinationAccount,
  firstName,
  lastName,
}: ConfirmTransferDialogProps) {
  const formattedAmount = new Intl.NumberFormat('fa-IR').format(parseInt(amount));

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="h-6 w-6" />
            <AlertDialogTitle className="text-xl">تایید انتقال وجه</AlertDialogTitle>
          </div>
          <AlertDialogDescription className="space-y-4 pt-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 space-y-3">
              <p className="text-amber-900 text-base">
                آیا از انتقال وجه اطمینان دارید؟
              </p>
              
              <div className="space-y-2 text-sm text-amber-800">
                <div className="flex justify-between">
                  <span className="font-medium">مبلغ:</span>
                  <span className="font-bold">{formattedAmount} ریال</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">حساب مقصد:</span>
                  <span className="font-mono text-xs">{destinationAccount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">گیرنده:</span>
                  <span>{firstName} {lastName}</span>
                </div>
              </div>
            </div>

            <p className="text-sm text-red-600 font-medium">
              ⚠️ این عملیات قابل برگشت نیست!
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="gap-2">
          <AlertDialogCancel className="flex-1">انصراف</AlertDialogCancel>
          <AlertDialogAction 
            onClick={onConfirm}
            className="flex-1 bg-emerald-600 hover:bg-emerald-700"
          >
            تایید و ارسال
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
