import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Bug, RefreshCw, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { refreshApiKey } from '../utils/api';

export function ApiDebug() {
  const [isOpen, setIsOpen] = useState(false);
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<any>(null);

  const testApi = async () => {
    setTesting(true);
    setResult(null);
    
    console.log('🧪 Starting manual API test...');
    const testResult = await refreshApiKey();
    
    setResult(testResult);
    setTesting(false);
    
    console.log('🧪 Manual test result:', testResult);
  };

  if (!isOpen) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 left-4 gap-2 bg-white shadow-lg z-50"
      >
        <Bug className="h-4 w-4" />
        Debug
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-4 left-4 w-96 shadow-2xl z-50 border-2">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2">
            <Bug className="h-5 w-5" />
            API Debug
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(false)}
            className="h-8 w-8 p-0"
          >
            ✕
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button
          onClick={testApi}
          disabled={testing}
          className="w-full gap-2"
        >
          {testing ? (
            <>
              <RefreshCw className="h-4 w-4 animate-spin" />
              در حال تست...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4" />
              تست اتصال API
            </>
          )}
        </Button>

        {result && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              {result.success ? (
                <>
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <Badge className="bg-green-100 text-green-800">موفق</Badge>
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-600" />
                  <Badge variant="destructive">ناموفق</Badge>
                </>
              )}
            </div>

            {result.success ? (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-sm">
                <div className="space-y-1">
                  <p className="text-green-900">✅ توکن با موفقیت refresh شد</p>
                  <p className="text-xs text-green-700 font-mono break-all">
                    {result.apiKey?.substring(0, 40)}...
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm">
                <div className="space-y-2">
                  <p className="text-red-900 flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{result.message}</span>
                  </p>
                  <div className="text-xs text-red-700 space-y-1">
                    <p>راهنمای عیب‌یابی:</p>
                    <ul className="list-disc list-inside space-y-1 pr-2">
                      <li>Console را بررسی کنید (F12)</li>
                      <li>فایل TROUBLESHOOTING.md را بخوانید</li>
                      <li>فایل TEST_API.md را امتحان کنید</li>
                      <li>اتصال اینترنت را چک کنید</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="pt-2 border-t text-xs text-muted-foreground space-y-1">
          <p>💡 نکته: Console (F12) را باز کنید</p>
          <p>📖 راهنمای کامل در TROUBLESHOOTING.md</p>
        </div>
      </CardContent>
    </Card>
  );
}
