import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { ScrollArea } from './ui/scroll-area';
import { Download, History, Loader2, RefreshCw } from 'lucide-react';
import { getTransactions, exportToCSV } from '../utils/api';
import { toast } from 'sonner@2.0.3';

interface TransactionHistoryProps {
  refreshTrigger: number;
}

export function TransactionHistory({ refreshTrigger }: TransactionHistoryProps) {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  const loadTransactions = async () => {
    setLoading(true);
    const result = await getTransactions(100, 0);
    setLoading(false);

    if (result.status === 'ok' || result.status === 1) {
      setTransactions(result.data || []);
    } else {
      toast.error(result.message || 'خطا در دریافت تراکنش‌ها');
    }
  };

  useEffect(() => {
    if (open) {
      loadTransactions();
    }
  }, [open, refreshTrigger]);

  const handleExport = () => {
    if (transactions.length === 0) {
      toast.error('هیچ تراکنشی برای خروجی وجود ندارد');
      return;
    }
    exportToCSV(transactions);
    toast.success('فایل با موفقیت دانلود شد');
  };

  const getStatusBadge = (status: string) => {
    const statusMap: { [key: string]: { label: string; className: string } } = {
      'success': { label: 'موفق', className: 'bg-green-100 text-green-800' },
      'pending': { label: 'در انتظار', className: 'bg-yellow-100 text-yellow-800' },
      'failed': { label: 'ناموفق', className: 'bg-red-100 text-red-800' },
      'processing': { label: 'در حال پردازش', className: 'bg-blue-100 text-blue-800' },
    };

    const statusInfo = statusMap[status?.toLowerCase()] || { label: status, className: 'bg-gray-100 text-gray-800' };

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs ${statusInfo.className}`}>
        {statusInfo.label}
      </span>
    );
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fa-IR').format(amount);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <History className="h-4 w-4" />
          تاریخچه تراکنش‌ها
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>تاریخچه تراکنش‌ها</span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={loadTransactions}
                disabled={loading}
                className="gap-2"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                بروزرسانی
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                disabled={transactions.length === 0}
                className="gap-2"
              >
                <Download className="h-4 w-4" />
                خروجی CSV
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="h-[600px] w-full">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : transactions.length === 0 ? (
            <div className="flex items-center justify-center h-64 text-muted-foreground">
              هیچ تراکنشی یافت نشد
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>تاریخ</TableHead>
                  <TableHead>مبلغ (ریال)</TableHead>
                  <TableHead>حساب مقصد</TableHead>
                  <TableHead>نام</TableHead>
                  <TableHead>نام خانوادگی</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead>کد رهگیری</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction, index) => (
                  <TableRow key={index}>
                    <TableCell className="whitespace-nowrap">
                      {transaction.created_at || '-'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {transaction.amount ? formatAmount(transaction.amount) : '-'}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{transaction.destination_account || '-'}</TableCell>
                    <TableCell>{transaction.destination_firstname || '-'}</TableCell>
                    <TableCell>{transaction.destination_lastname || '-'}</TableCell>
                    <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                    <TableCell className="font-mono text-xs">
                      {transaction.track_id || '-'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
