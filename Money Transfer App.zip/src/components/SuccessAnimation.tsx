import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
} from './ui/dialog';

interface SuccessAnimationProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  amount: string;
}

export function SuccessAnimation({ open, onOpenChange, amount }: SuccessAnimationProps) {
  const formattedAmount = new Intl.NumberFormat('fa-IR').format(parseInt(amount || '0'));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm border-0 bg-transparent shadow-none">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-3xl p-8 text-center space-y-6 shadow-2xl"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{
              type: 'spring',
              stiffness: 260,
              damping: 20,
              delay: 0.1,
            }}
            className="mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              <CheckCircle2 className="h-12 w-12 text-white" />
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-2"
          >
            <h2 className="text-2xl text-green-600">انتقال موفق!</h2>
            <p className="text-muted-foreground">
              مبلغ {formattedAmount} ریال با موفقیت منتقل شد
            </p>
          </motion.div>

          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: [0, 1.2, 1] }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: [0, 1, 0], scale: [0, 1.5, 2] }}
                transition={{
                  duration: 1.5,
                  delay: 0.6 + i * 0.2,
                  repeat: Infinity,
                  repeatDelay: 1,
                }}
                className="absolute inset-0 rounded-full border-2 border-green-400"
              />
            ))}
          </motion.div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
