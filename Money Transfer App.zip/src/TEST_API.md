# 🧪 تست دستی API در Console

## روش استفاده

1. مرورگر را باز کنید
2. Console را باز کنید (F12)
3. کدهای زیر را کپی و paste کنید

---

## تست 1: بررسی اتصال به سرور

```javascript
fetch('https://core.paystar.ir/api/open-banking/application/refresh-api-key', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    application_id: 'pg3kr',
    access_password: 'xpS5696lAUWjbuLjFjJG4lxfp8nJ4YthOBEKy8rjwqVgHGPolb',
    refresh_token: 'C9L3ISgdGrUMuk415pVj5Xgr2iMAZolvm4S1OieBmoy6foqeOmm1C18v85G7gLWaxVLy2Lt3mhJvY1aw8qKLiEhXzL7pUjqGSSsi',
  }),
})
.then(res => {
  console.log('✅ Response Status:', res.status, res.statusText);
  return res.json();
})
.then(data => {
  console.log('✅ Response Data:', data);
  if (data.status === 1) {
    console.log('🎉 موفق! API Key:', data.data.api_key.substring(0, 30) + '...');
  } else {
    console.error('❌ خطا:', data.message);
  }
})
.catch(error => {
  console.error('❌ Exception:', error);
});
```

---

## تست 2: بررسی IBAN Validation

ابتدا باید یک API key معتبر داشته باشید (از تست 1).

```javascript
// جایگزین کنید با API key معتبر
const API_KEY = 'YOUR_API_KEY_HERE';

fetch('https://core.paystar.ir/api/open-banking/service/bank-inquiry/iban-inquiry', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${API_KEY}`,
  },
  body: JSON.stringify({
    application_id: 'pg3kr',
    access_password: 'xpS5696lAUWjbuLjFjJG4lxfp8nJ4YthOBEKy8rjwqVgHGPolb',
    iban: 'IR120120000000000123456789', // شماره IBAN تست
  }),
})
.then(res => {
  console.log('✅ Response Status:', res.status, res.statusText);
  return res.json();
})
.then(data => {
  console.log('✅ Response Data:', data);
  if (data.status === 1) {
    console.log('🎉 IBAN معتبر است!');
    console.log('🏦 بانک:', data.data.bank_name);
    console.log('👤 صاحب حساب:', data.data.owners_info);
  } else {
    console.error('❌ خطا:', data.message);
  }
})
.catch(error => {
  console.error('❌ Exception:', error);
});
```

---

## تفسیر نتایج

### ✅ حالت موفق

```javascript
✅ Response Status: 200 OK
✅ Response Data: { status: 1, data: {...} }
🎉 موفق! API Key: MBMpuXxJfC0WlvgSBgGc9h3MZkWMmnf...
```

**معنی:** همه چیز خوب است! ✅

---

### ❌ حالت خطا - CORS

```javascript
Access to fetch at 'https://core.paystar.ir/...' 
from origin 'http://localhost:5173' has been blocked by CORS policy
```

**معنی:** مرورگر اجازه نمی‌دهد درخواست ارسال شود.

**راه‌حل:**
1. از backend proxy استفاده کنید
2. با پشتیبانی Paystar تماس بگیرید
3. از browser extension برای disable کردن CORS استفاده کنید (فقط تست!)

---

### ❌ حالت خطا - Unauthorized (401)

```javascript
✅ Response Status: 401 Unauthorized
✅ Response Data: { status: 0, message: "..." }
❌ خطا: توکن احراز هویت منقضی شده است
```

**معنی:** Credentials نادرست یا منقضی شده است.

**راه‌حل:**
1. از پنل Paystar credentials جدید بگیرید
2. در فایل `/utils/api.ts` به‌روز کنید

---

### ❌ حالت خطا - Bad Request (400)

```javascript
✅ Response Status: 400 Bad Request
✅ Response Data: { status: 0, message: "..." }
```

**معنی:** فرمت درخواست اشتباه است.

**راه‌حل:**
1. بررسی کنید که endpoint صحیح است
2. بررسی کنید که body صحیح است
3. مستندات Paystar را بخوانید

---

### ❌ حالت خطا - Network Error

```javascript
❌ Exception: TypeError: Failed to fetch
```

**معنی:** اتصال اینترنت قطع است یا سرور در دسترس نیست.

**راه‌حل:**
1. اتصال اینترنت را بررسی کنید
2. VPN را امتحان کنید
3. با browser دیگری امتحان کنید

---

## تست 3: بررسی اتصال ساده

```javascript
fetch('https://core.paystar.ir', { mode: 'no-cors' })
  .then(() => console.log('✅ سرور در دسترس است'))
  .catch(err => console.error('❌ سرور در دسترس نیست:', err));
```

---

## تست 4: بررسی تمام اطلاعات

```javascript
console.log('🔍 اطلاعات سیستم:');
console.log('Browser:', navigator.userAgent);
console.log('Online:', navigator.onLine);
console.log('Language:', navigator.language);
console.log('Platform:', navigator.platform);

// تست DNS
fetch('https://core.paystar.ir', { mode: 'no-cors' })
  .then(() => console.log('✅ DNS works'))
  .catch(() => console.error('❌ DNS failed'));
```

---

## 🎯 نتیجه‌گیری

بعد از اجرای تست‌ها:

1. اگر **تست 1 موفق بود** → API key جدید را کپی کنید و در `/utils/api.ts` قرار دهید
2. اگر **خطای CORS گرفتید** → باید از backend استفاده کنید یا با Paystar تماس بگیرید
3. اگر **401/403 گرفتید** → Credentials را بررسی کنید
4. اگر **Network error گرفتید** → اتصال اینترنت/VPN را بررسی کنید

---

## 📋 چک‌لیست

- [ ] تست 1 را اجرا کردم
- [ ] نتایج را در Console دیدم
- [ ] Screenshot از Console گرفتم
- [ ] خطاها را یادداشت کردم
- [ ] با TROUBLESHOOTING.md مقایسه کردم

---

**موفق باشید! 🚀**
