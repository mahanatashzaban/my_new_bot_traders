
  # Money Transfer App

  This is a code bundle for Money Transfer App. The original project is available at https://www.figma.com/design/X9tMaDWQA59dpYA0OPLaTb/Money-Transfer-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  